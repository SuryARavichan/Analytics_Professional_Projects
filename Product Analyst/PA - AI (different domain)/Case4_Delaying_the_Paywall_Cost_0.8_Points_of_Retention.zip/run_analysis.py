"""
CASE 04 — Gaming A/B Test: Paywall Gate Placement (Cookie Cats)
Real player-level data from the real mobile game Cookie Cats (Tactile
Entertainment), 90,189 real players. A/B test: does moving the first hard
progression gate from level 30 to level 40 change day-1 / day-7 retention?
Loads the data into SQLite, runs gaming_analysis.sql, runs two-proportion
z-tests, builds the behavioral segments, and produces 3 charts.
"""
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import json
from statsmodels.stats.proportion import proportions_ztest, proportion_confint

plt.rcParams["font.family"] = "DejaVu Sans"
BLUE = "#2a78d6"; ORANGE = "#eb6834"; AQUA = "#1baf7a"; RED = "#e34948"; GOOD = "#0ca30c"
INK = "#0b0b0b"; INK2 = "#52514e"; MUTED = "#898781"; GRID = "#e1e0d9"; SURFACE = "#fcfcfb"

OUTLIER_USERID = 6390605  # 49,854 rounds in 14 days -- not credible human play

# ---------------------------------------------------------------------------
# Load into SQLite
# ---------------------------------------------------------------------------
df = pd.read_csv("../data/cookie_cats.csv")
df["retention_1"] = df["retention_1"].astype(int)
df["retention_7"] = df["retention_7"].astype(int)

conn = sqlite3.connect(":memory:")
df.to_sql("players", conn, index=False, if_exists="replace")

with open("gaming_analysis.sql") as f:
    sql_lines = f.readlines()
# strip full-line SQL comments before splitting on ';' so a "SELECT" mentioned
# inside a comment doesn't get parsed as (part of) a query
sql_text = "\n".join(l for l in sql_lines if not l.strip().startswith("--"))
queries = [q.strip() for q in sql_text.split(";") if q.strip() and "SELECT" in q.upper()]
labels = ["01_retention_by_gate", "02_rounds_distribution_excl_outlier",
          "03_behavioral_segments", "04_segment_by_gate"]

sql_results = {}
for label, q in zip(labels, queries):
    res = pd.read_sql_query(q, conn)
    sql_results[label] = res.to_dict(orient="records")
    print("\n===", label, "===")
    print(res.to_string(index=False))

# ---------------------------------------------------------------------------
# Two-proportion z-tests: gate_30 vs gate_40, for retention_1 and retention_7
# ---------------------------------------------------------------------------
g30 = df[df.version == "gate_30"]
g40 = df[df.version == "gate_40"]

ztests = {}
for outcome in ["retention_1", "retention_7"]:
    x30, n30 = int(g30[outcome].sum()), len(g30)
    x40, n40 = int(g40[outcome].sum()), len(g40)
    z, p = proportions_ztest([x30, x40], [n30, n40])
    ci30 = proportion_confint(x30, n30, alpha=0.05, method="wilson")
    ci40 = proportion_confint(x40, n40, alpha=0.05, method="wilson")
    p30, p40 = x30 / n30, x40 / n40
    ztests[outcome] = {
        "n_gate_30": n30, "x_gate_30": x30, "p_gate_30": round(p30, 4),
        "ci_gate_30": [round(float(c), 4) for c in ci30],
        "n_gate_40": n40, "x_gate_40": x40, "p_gate_40": round(p40, 4),
        "ci_gate_40": [round(float(c), 4) for c in ci40],
        "z_stat": round(float(z), 3), "p_value": float(p),
        "diff_pp": round((p30 - p40) * 100, 3),
        "significant_at_05": bool(p < 0.05),
        "better_arm": "gate_30" if p30 > p40 else "gate_40",
    }

print("\n=== Z-TESTS ===")
print(json.dumps(ztests, indent=2))

# ---------------------------------------------------------------------------
# Behavioral segments (rebuilt in pandas for chart/persona use)
# ---------------------------------------------------------------------------
def tier(x):
    if x == 0: return "non-starters"
    elif x <= 15: return "light players"
    elif x <= 50: return "core players"
    else: return "power players"

df["segment"] = df["sum_gamerounds"].apply(tier)
seg_order = ["non-starters", "light players", "core players", "power players"]

seg_stats = df.groupby("segment").agg(
    players=("userid", "count"),
    avg_rounds=("sum_gamerounds", "mean"),
    retention_1_pct=("retention_1", "mean"),
    retention_7_pct=("retention_7", "mean"),
).reindex(seg_order)
seg_stats["retention_1_pct"] *= 100
seg_stats["retention_7_pct"] *= 100
seg_stats["pct_of_base"] = 100 * seg_stats["players"] / len(df)

# within-segment, which arm retains better (day-7, the more reliable metric)
seg_arm = {}
for s in seg_order:
    sub = df[df.segment == s]
    r7 = sub.groupby("version")["retention_7"].mean()
    better = r7.idxmax() if len(r7) == 2 else None
    seg_arm[s] = {"gate_30_ret7_pct": round(float(r7.get("gate_30", np.nan)) * 100, 2),
                  "gate_40_ret7_pct": round(float(r7.get("gate_40", np.nan)) * 100, 2),
                  "better_arm": better}

segments_out = []
for s in seg_order:
    row = seg_stats.loc[s]
    segments_out.append({
        "segment": s,
        "players": int(row["players"]),
        "pct_of_base": round(float(row["pct_of_base"]), 1),
        "avg_rounds": round(float(row["avg_rounds"]), 1),
        "retention_1_pct": round(float(row["retention_1_pct"]), 2),
        "retention_7_pct": round(float(row["retention_7_pct"]), 2),
        "gate_30_ret7_pct": seg_arm[s]["gate_30_ret7_pct"],
        "gate_40_ret7_pct": seg_arm[s]["gate_40_ret7_pct"],
        "better_arm_ret7": seg_arm[s]["better_arm"],
    })

# ---------------------------------------------------------------------------
# sum_gamerounds distribution stats (outlier excluded, documented)
# ---------------------------------------------------------------------------
clean = df[df.userid != OUTLIER_USERID]["sum_gamerounds"]
dist_stats = {
    "n_excl_outlier": int(len(clean)),
    "outlier_userid": OUTLIER_USERID,
    "outlier_rounds": int(df.loc[df.userid == OUTLIER_USERID, "sum_gamerounds"].iloc[0]),
    "median": float(clean.median()),
    "q1": float(clean.quantile(0.25)),
    "q3": float(clean.quantile(0.75)),
    "mean": round(float(clean.mean()), 2),
    "max_excl_outlier": int(clean.max()),
}

results = {
    "n_total": int(len(df)),
    "n_gate_30": int(len(g30)),
    "n_gate_40": int(len(g40)),
    "outlier_userid": OUTLIER_USERID,
    "outlier_rounds": dist_stats["outlier_rounds"],
    "sql_query_results": sql_results,
    "ztests": ztests,
    "segments": segments_out,
    "rounds_distribution": dist_stats,
}
with open("gaming_results.json", "w") as f:
    json.dump(results, f, indent=2)

# ---------------------------------------------------------------------------
# CHART 1 — Retention by gate (grouped bars), day-1 & day-7, p-values annotated
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.2, 4.6), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)

labels_x = ["Day-1 retention", "Day-7 retention"]
vals_30 = [ztests["retention_1"]["p_gate_30"] * 100, ztests["retention_7"]["p_gate_30"] * 100]
vals_40 = [ztests["retention_1"]["p_gate_40"] * 100, ztests["retention_7"]["p_gate_40"] * 100]
x = np.arange(len(labels_x))
w = 0.32
b1 = ax.bar(x - w/2, vals_30, width=w, color=BLUE, label="gate_30 (gate at level 30)", zorder=3)
b2 = ax.bar(x + w/2, vals_40, width=w, color=ORANGE, label="gate_40 (gate at level 40)", zorder=3)
for b, v in zip(b1, vals_30):
    ax.text(b.get_x() + b.get_width()/2, v + 0.6, f"{v:.1f}%", ha="center", fontsize=10, color=INK, fontweight="bold")
for b, v in zip(b2, vals_40):
    ax.text(b.get_x() + b.get_width()/2, v + 0.6, f"{v:.1f}%", ha="center", fontsize=10, color=INK, fontweight="bold")

def p_annot(p):
    return "p < 0.001" if p < 0.001 else f"p = {p:.3f}"

ax.text(0, max(vals_30[0], vals_40[0]) + 4.5, p_annot(ztests["retention_1"]["p_value"]) + "\n(not significant)"
        if ztests["retention_1"]["p_value"] >= 0.05 else p_annot(ztests["retention_1"]["p_value"]),
        ha="center", fontsize=9, color=INK2)
ax.text(1, max(vals_30[1], vals_40[1]) + 4.5, p_annot(ztests["retention_7"]["p_value"]) + "\n(significant)"
        if ztests["retention_7"]["p_value"] < 0.05 else p_annot(ztests["retention_7"]["p_value"]),
        ha="center", fontsize=9, color=INK2)

ax.set_xticks(x); ax.set_xticklabels(labels_x, fontsize=11, color=INK2)
ax.set_ylim(0, max(vals_30 + vals_40) * 1.35)
ax.set_ylabel("Retention rate", fontsize=10, color=INK2)
ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax.set_title("Gate at level 30 out-retains gate at level 40 on both horizons",
             fontsize=12.5, color=INK, loc="left", pad=14, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)
ax.legend(loc="upper right", frameon=False, fontsize=9.5)
plt.tight_layout()
plt.savefig("chart_retention_by_gate.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------------------
# CHART 2 — Segment funnel: player counts + retention rates across tiers
# ---------------------------------------------------------------------------
fig, ax1 = plt.subplots(figsize=(7.4, 4.6), dpi=200)
fig.patch.set_facecolor(SURFACE); ax1.set_facecolor(SURFACE)

seg_labels = [s["segment"].title() for s in segments_out]
counts = [s["players"] for s in segments_out]
r1 = [s["retention_1_pct"] for s in segments_out]
r7 = [s["retention_7_pct"] for s in segments_out]

bar_colors = [MUTED, BLUE, AQUA, GOOD]
bars = ax1.bar(seg_labels, counts, color=bar_colors, width=0.55, zorder=3)
for b, c, pct in zip(bars, counts, [s["pct_of_base"] for s in segments_out]):
    ax1.text(b.get_x() + b.get_width()/2, c + 900, f"{c:,}\n({pct:.0f}% of base)",
              ha="center", fontsize=9, color=INK, zorder=6,
              bbox=dict(facecolor=SURFACE, edgecolor="none", alpha=0.85, pad=1.5))
ax1.set_ylabel("Players", fontsize=10, color=INK2)
ax1.set_ylim(0, max(counts) * 1.45)
ax1.spines[["top", "right", "left"]].set_visible(False)
ax1.spines["bottom"].set_color(GRID)
ax1.tick_params(axis="x", length=0, labelsize=10.5, colors=INK2)
ax1.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax1.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)

ax2 = ax1.twinx()
ax2.plot(seg_labels, r7, color=RED, marker="o", markersize=7, linewidth=2.3, zorder=4, label="Day-7 retention")
ax2.plot(seg_labels, r1, color=INK2, marker="o", markersize=6, linewidth=1.8, linestyle="--", zorder=4, label="Day-1 retention")
for i, (v1, v7) in enumerate(zip(r1, r7)):
    ax2.annotate(f"{v7:.0f}%", (i, v7), textcoords="offset points", xytext=(10, 6), fontsize=9, color=RED,
                 fontweight="bold", zorder=6,
                 bbox=dict(facecolor=SURFACE, edgecolor="none", alpha=0.85, pad=1))
ax2.set_ylabel("Retention rate", fontsize=10, color=INK2)
ax2.set_ylim(0, 100)
ax2.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax2.spines[["top", "left"]].set_visible(False)
ax2.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax2.legend(loc="upper left", frameon=False, fontsize=9.5)

ax1.set_title("More rounds played early = dramatically higher retention",
              fontsize=12.5, color=INK, loc="left", pad=14, fontweight="bold")
plt.tight_layout()
plt.savefig("chart_segment_funnel.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------------------
# CHART 3 — Engagement distribution (log-scale), segment cutoffs marked
# ---------------------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.6, 4.6), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)

plot_data = clean[clean > 0]  # log scale needs > 0; non-starters called out separately
bins = np.logspace(0, np.log10(plot_data.max()), 50)
ax.hist(plot_data, bins=bins, color=BLUE, alpha=0.85, zorder=3)
ax.set_xscale("log")
ax.set_ylim(0, 6000)
for cutoff, label, color in [(15, "Light | Core cutoff (15)", ORANGE), (50, "Core | Power cutoff (50)", RED)]:
    ax.axvline(cutoff, color=color, linestyle="--", linewidth=1.6, zorder=4)
    ax.text(cutoff, 5750, label, rotation=90, va="top", ha="right",
            fontsize=8.5, color=color, fontweight="bold")
ax.set_xlabel("sum_gamerounds, first 14 days (log scale) -- players with 0 rounds (n=3,994) excluded from this log axis",
              fontsize=9.5, color=INK2)
ax.set_ylabel("Players", fontsize=10, color=INK2)
ax.set_title(f"Right-skewed engagement: median {dist_stats['median']:.0f} rounds, one outlier at\n"
             f"{dist_stats['outlier_rounds']:,} rounds excluded as not credible human play",
             fontsize=12, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0, labelsize=9, colors=INK2)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig("chart_engagement_distribution.png", facecolor=SURFACE)
plt.close()

print("\nCharts saved. Results written to gaming_results.json.")
