-- ============================================================================
-- CASE 04 — Gaming A/B Test: Paywall Gate Placement (Cookie Cats)
-- Real player-level data, 90,189 players, from the real mobile game
-- Cookie Cats (Tactile Entertainment). version = which A/B arm the player
-- was randomized into: gate_30 (first "hard" progression gate at level 30,
-- the pre-existing design) vs. gate_40 (gate moved back to level 40, the
-- test variant).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 01. Retention rate by A/B arm (day-1 and day-7)
-- The core experiment readout: does moving the gate later change how many
-- players come back the next day / a week later?
-- ----------------------------------------------------------------------------
SELECT
    version,
    COUNT(*)                                         AS players,
    ROUND(100.0 * SUM(retention_1) / COUNT(*), 2)     AS retention_1_pct,
    ROUND(100.0 * SUM(retention_7) / COUNT(*), 2)     AS retention_7_pct
FROM players
GROUP BY version;

-- ----------------------------------------------------------------------------
-- 02. Overall sum_gamerounds distribution — median / quartiles
-- NOTE ON THE KNOWN OUTLIER: one userid (6390605) logged 49,854 rounds in the
-- first 14 days — roughly 3,560 rounds/day, a value that is not credible for
-- normal human play (likely a bot, QA/test account, or logging artifact) and
-- is a well-documented anomaly in this public dataset. It is excluded from
-- this distribution query (and from the engagement-distribution chart) so it
-- doesn't distort the summary stats; it is NOT dropped from the retention /
-- A/B queries below, since it is one real row out of 90,189 and has
-- negligible effect on a proportion test at this sample size.
-- ----------------------------------------------------------------------------
SELECT
    COUNT(*)                                         AS players_excl_outlier,
    MIN(sum_gamerounds)                               AS min_rounds,
    -- SQLite has no native PERCENTILE_CONT; quartiles are computed in pandas
    -- (see run_analysis.py) using this same outlier-excluded frame. This
    -- query documents the exclusion and reports the simple bounds.
    MAX(sum_gamerounds)                               AS max_rounds,
    ROUND(AVG(sum_gamerounds), 1)                     AS mean_rounds
FROM players
WHERE userid != 6390605;

-- ----------------------------------------------------------------------------
-- 03. Behavioral segmentation — 4 tiers by sum_gamerounds
-- Cutoffs are the dataset's own quartile breakpoints (25th / 50th / 75th
-- percentile = 5 / 16 / 51 rounds), with the zero-rounds group split out on
-- its own because "installed and never played a single round" is a
-- meaningfully different (and very common: 3,994 players / 4.4%) behavior
-- from "played a handful of rounds then stopped" — collapsing them into one
-- bucket would hide the most extreme churn-risk group inside "light".
--   non-starters : 0 rounds            (never played after install)
--   light players: 1-15 rounds         (below the dataset median)
--   core players : 16-50 rounds        (median up to the 75th percentile)
--   power players: 51+ rounds          (top quartile of engagement)
-- ----------------------------------------------------------------------------
SELECT
    CASE
        WHEN sum_gamerounds = 0 THEN 'non-starters'
        WHEN sum_gamerounds <= 15 THEN 'light players'
        WHEN sum_gamerounds <= 50 THEN 'core players'
        ELSE 'power players'
    END AS segment,
    COUNT(*)                                          AS players,
    ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM players), 1) AS pct_of_base,
    ROUND(AVG(sum_gamerounds), 1)                      AS avg_rounds,
    ROUND(100.0 * SUM(retention_1) / COUNT(*), 2)      AS retention_1_pct,
    ROUND(100.0 * SUM(retention_7) / COUNT(*), 2)      AS retention_7_pct
FROM players
GROUP BY segment
ORDER BY avg_rounds;

-- ----------------------------------------------------------------------------
-- 04. Within-segment retention by A/B arm
-- Does the gate_30-vs-gate_40 effect hold consistently across behavioral
-- segments, or is it concentrated in one type of player?
-- ----------------------------------------------------------------------------
SELECT
    CASE
        WHEN sum_gamerounds = 0 THEN 'non-starters'
        WHEN sum_gamerounds <= 15 THEN 'light players'
        WHEN sum_gamerounds <= 50 THEN 'core players'
        ELSE 'power players'
    END AS segment,
    version,
    COUNT(*)                                          AS players,
    ROUND(100.0 * SUM(retention_1) / COUNT(*), 2)      AS retention_1_pct,
    ROUND(100.0 * SUM(retention_7) / COUNT(*), 2)      AS retention_7_pct
FROM players
GROUP BY segment, version
ORDER BY AVG(sum_gamerounds), version;
