"""
CASE 05 -- AI Content Performance Modeling (YouTube US Trending, 2017)
Deterministic analysis stage:
  1. Dedupes the raw trending-snapshot CSV to one row per unique video
     (some videos trended on multiple days; we keep the max-views snapshot
     for each, which is also each video's final/highest observed count).
  2. Loads the deduped table into SQLite and runs content_analysis.sql.
  3. Reads llm_theme_tags.json (the genuine, per-title LLM/human theme
     coding done on the 180-video stratified sample) and computes
     theme-level performance stats + hypothesis tests.
  4. Produces the three report charts and content_results.json.
"""
import json
import sqlite3
from collections import defaultdict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from scipy import stats

plt.rcParams["font.family"] = "DejaVu Sans"

BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
RED = "#e34948"
GOOD = "#0ca30c"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
SURFACE = "#fcfcfb"

# ---------------------------------------------------------------
# 1. Load + dedupe
# ---------------------------------------------------------------
raw = pd.read_csv("../data/youtube_us_videos.csv")
raw_rows = len(raw)
raw_unique = raw["video_id"].nunique()

# Some videos appear on multiple trending-day snapshots. Dedupe to one row
# per video_id by keeping the row with the max `views` for that video
# (its most recent/highest observed snapshot).
idx = raw.groupby("video_id")["views"].idxmax()
videos = raw.loc[idx].reset_index(drop=True)
n_videos = len(videos)
print(f"Raw rows: {raw_rows} | unique video_ids: {raw_unique} | deduped rows: {n_videos}")
assert n_videos == raw_unique

# quartile split on views -> "high performer" (top quartile) vs "typical" (rest)
q1, median_views, q3 = videos["views"].quantile([0.25, 0.5, 0.75]).tolist()
videos["is_top_quartile"] = (videos["views"] >= q3).astype(int)
videos["engagement_rate"] = (videos["likes"] + videos["comment_total"]) / videos["views"]
videos["like_ratio"] = videos["likes"] / (videos["likes"] + videos["dislikes"]).replace(0, np.nan)

n_top = int(videos["is_top_quartile"].sum())
n_rest = n_videos - n_top

# ---------------------------------------------------------------
# 2. SQLite layer -- run content_analysis.sql for real
# ---------------------------------------------------------------
conn = sqlite3.connect(":memory:")
videos.to_sql("videos", conn, index=False, if_exists="replace")

with open("content_analysis.sql") as f:
    sql_text = f.read()
sql_nocomments = "\n".join(l for l in sql_text.splitlines() if not l.strip().startswith("--"))
queries = [q.strip() for q in sql_nocomments.split(";") if q.strip() and "SELECT" in q.upper()]

query_labels = [
    "01_video_level_engagement",
    "02_summary_by_category",
    "03_overall_engagement_summary",
    "04_views_distribution_context",
    "05_performer_group_comparison",
]
sql_results = {}
for label, q in zip(query_labels, queries):
    res = pd.read_sql_query(q, conn)
    sql_results[label] = res.to_dict(orient="records")
    print(f"\n=== {label} ===")
    print(res.head(12).to_string(index=False))

# ---------------------------------------------------------------
# 3. Theme coding (genuine per-title LLM/human reading, 180-video sample)
# ---------------------------------------------------------------
coded = json.load(open("llm_theme_tags.json"))
taxonomy = coded["taxonomy"]
sample_records = coded["videos"]
n_sample = len(sample_records)
sample_df = pd.DataFrame(sample_records)
sample_df["engagement_rate"] = (sample_df["likes"] + sample_df["comment_total"]) / sample_df["views"]

true_top_pct = round(n_top / n_videos * 100, 1)
true_rest_pct = round(n_rest / n_videos * 100, 1)

# per-theme performance: tagged vs untagged, within the 180-video sample
theme_stats = []
for code, desc in taxonomy.items():
    is_tagged = sample_df["themes"].apply(lambda ts: code in ts)
    tagged = sample_df[is_tagged]
    untagged = sample_df[~is_tagged]
    if len(tagged) == 0:
        continue
    theme_stats.append({
        "theme_code": code,
        "theme_label": desc,
        "n_tagged": int(len(tagged)),
        "n_untagged": int(len(untagged)),
        "mean_views_tagged": float(tagged["views"].mean()),
        "median_views_tagged": float(tagged["views"].median()),
        "mean_views_untagged": float(untagged["views"].mean()),
        "median_views_untagged": float(untagged["views"].median()),
        "mean_engagement_tagged": float(tagged["engagement_rate"].mean()),
        "mean_engagement_untagged": float(untagged["engagement_rate"].mean()),
        "pct_top_quartile_tagged": round(float(tagged["is_top_quartile"].mean()) * 100, 1),
        "views_lift_ratio": float(tagged["views"].mean() / untagged["views"].mean()) if untagged["views"].mean() > 0 else None,
    })
theme_df = pd.DataFrame(theme_stats).sort_values("mean_views_tagged", ascending=False).reset_index(drop=True)

# ---------------------------------------------------------------
# 4. Hypothesis tests -- Mann-Whitney U on views (heavily right-skewed,
#    so a rank-based test is more appropriate than a t-test on raw views).
#    Tested for every theme with n_tagged >= 8 so untested/underpowered
#    themes aren't silently implied to be significant; report highlights
#    the top few by |effect|.
# ---------------------------------------------------------------
test_rows = []
for _, row in theme_df.iterrows():
    code = row["theme_code"]
    if row["n_tagged"] < 8:
        continue
    is_tagged = sample_df["themes"].apply(lambda ts: code in ts)
    tagged_views = sample_df.loc[is_tagged, "views"].values
    untagged_views = sample_df.loc[~is_tagged, "views"].values
    tagged_eng = sample_df.loc[is_tagged, "engagement_rate"].values
    untagged_eng = sample_df.loc[~is_tagged, "engagement_rate"].values
    u_views, p_views = stats.mannwhitneyu(tagged_views, untagged_views, alternative="two-sided")
    u_eng, p_eng = stats.mannwhitneyu(tagged_eng, untagged_eng, alternative="two-sided")
    test_rows.append({
        "theme_code": code,
        "theme_label": taxonomy[code],
        "n_tagged": int(row["n_tagged"]),
        "n_untagged": int(row["n_untagged"]),
        "mann_whitney_u_views": float(u_views),
        "p_value_views": float(p_views),
        "significant_views_p05": bool(p_views < 0.05),
        "mann_whitney_u_engagement": float(u_eng),
        "p_value_engagement": float(p_eng),
        "significant_engagement_p05": bool(p_eng < 0.05),
        "median_views_tagged": float(row["median_views_tagged"]),
        "median_views_untagged": float(row["median_views_untagged"]),
        "mean_engagement_tagged": float(row["mean_engagement_tagged"]),
        "mean_engagement_untagged": float(row["mean_engagement_untagged"]),
    })
test_df = pd.DataFrame(test_rows).sort_values("p_value_views")

# pick the themes actually annotated/discussed in the report: the most
# significant on views, honestly including one that looked promising by
# raw means but did NOT hold up under the test
top3_by_significance = test_df.nsmallest(3, "p_value_views")["theme_code"].tolist()

# ---------------------------------------------------------------
# 5. Save results JSON
# ---------------------------------------------------------------
hist_counts, hist_edges = np.histogram(np.log10(videos["views"]), bins=32)
views_histogram = {
    "bin_edges_log10": [float(x) for x in hist_edges],
    "counts": [int(x) for x in hist_counts],
    "note": "np.histogram(log10(views), bins=32) over all deduped videos; bin_edges_log10 has len(counts)+1 edges.",
}

results = {
    "dataset": {
        "raw_rows": int(raw_rows),
        "unique_video_ids": int(raw_unique),
        "deduped_rows": int(n_videos),
        "dedup_method": "one row per video_id, keeping the max-views snapshot",
    },
    "views_distribution": {
        "q1": float(q1), "median": float(median_views), "q3": float(q3),
        "min": float(videos["views"].min()), "max": float(videos["views"].max()),
        "mean": float(videos["views"].mean()),
    },
    "performer_split": {
        "n_top_quartile": n_top, "n_rest": n_rest,
        "pct_top_quartile": true_top_pct, "pct_rest": true_rest_pct,
    },
    "sample": {
        "n_sample": n_sample,
        "n_top_quartile_in_sample": int(sample_df["is_top_quartile"].sum()),
        "n_rest_in_sample": int((sample_df["is_top_quartile"] == 0).sum()),
        "sampling_note": (
            f"Stratified: 90 titles drawn from the {n_top}-video top-quartile-views group and 90 from "
            f"the {n_rest}-video 'rest' group (random_state=42) -- an intentional 50/50 oversample of "
            f"top performers vs. their {true_top_pct}% true share of the population, for a tractable, "
            "informative comparison set."
        ),
    },
    "taxonomy": taxonomy,
    "theme_performance": theme_df.to_dict(orient="records"),
    "hypothesis_tests": test_df.to_dict(orient="records"),
    "top3_tested_themes": top3_by_significance,
    "views_histogram": views_histogram,
    "sql_query_results": sql_results,
}
with open("content_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("\n=== theme performance (sorted by mean views tagged) ===")
print(theme_df[["theme_code", "n_tagged", "mean_views_tagged", "mean_engagement_tagged"]].to_string(index=False))
print("\n=== hypothesis tests (sorted by p-value on views) ===")
print(test_df[["theme_code", "n_tagged", "p_value_views", "significant_views_p05",
                "p_value_engagement", "significant_engagement_p05"]].to_string(index=False))

# ---------------------------------------------------------------
# CHART 1 -- mean views by theme, sorted, sample-size labels
# ---------------------------------------------------------------
plot_theme = theme_df.sort_values("mean_views_tagged", ascending=True)
fig, ax = plt.subplots(figsize=(10.5, 6.4), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
overall_mean = sample_df["views"].mean()
colors_bar = [AQUA if v >= overall_mean else MUTED for v in plot_theme["mean_views_tagged"]]
bars = ax.barh(plot_theme["theme_code"], plot_theme["mean_views_tagged"], color=colors_bar, height=0.62, zorder=3)
for b, (v, n) in zip(bars, zip(plot_theme["mean_views_tagged"], plot_theme["n_tagged"])):
    ax.text(v + plot_theme["mean_views_tagged"].max() * 0.012, b.get_y() + b.get_height() / 2,
            f"{v/1e6:.2f}M  (n={n})", va="center", fontsize=8.8, color=INK)
ax.axvline(overall_mean, color=RED, linewidth=1.2, linestyle="--", zorder=4)
ax.text(overall_mean, len(plot_theme) - 0.3, f" sample mean {overall_mean/1e6:.2f}M",
        color=RED, fontsize=8.5, va="bottom")
ax.set_title("Mean views by title/content theme (180-video coded sample)",
             fontsize=13, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_xlabel("Mean views (tagged videos)", fontsize=9.5, color=INK2)
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="y", length=0, labelsize=9, colors=INK2)
ax.tick_params(axis="x", length=0, labelsize=9, colors=MUTED)
ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
ax.set_xlim(0, plot_theme["mean_views_tagged"].max() * 1.22)
plt.tight_layout()
plt.savefig("chart_theme_performance.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------
# CHART 2 -- views distribution (log-scaled histogram) w/ top-quartile cutoff
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(10.5, 5.8), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
log_views = np.log10(videos["views"])
bins = np.linspace(log_views.min(), log_views.max(), 32)
ax.hist(log_views, bins=bins, color=BLUE, alpha=0.85, zorder=3, edgecolor=SURFACE, linewidth=0.4)
ax.axvline(np.log10(q3), color=RED, linewidth=1.6, linestyle="--", zorder=4)
ax.set_title(
    f"Views are heavily right-skewed\n{n_top} of {n_videos} videos ({true_top_pct}%) clear the top-quartile cutoff of {q3:,.0f} views",
    fontsize=12.5, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_xlabel("Views (log10 scale)", fontsize=9.5, color=INK2)
ax.set_ylabel("Number of videos", fontsize=9.5, color=INK2)
tick_vals = [4, 5, 6, 7]
ax.set_xticks(tick_vals)
ax.set_xticklabels([f"{10**t:,.0f}" for t in tick_vals], fontsize=9)
ax.spines[["top", "right"]].set_visible(False)
ax.spines[["left", "bottom"]].set_color(GRID)
ax.tick_params(axis="both", length=0, labelsize=9, colors=INK2)
ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
ymax = ax.get_ylim()[1]
ax.annotate(f"Q3 cutoff\n{q3:,.0f} views", xy=(np.log10(q3), ymax * 0.92),
            xytext=(np.log10(q3) + 0.15, ymax * 0.92),
            fontsize=9, color=RED, va="top")
plt.tight_layout()
plt.savefig("chart_views_distribution.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------
# CHART 3 -- significance test comparison for the top tested themes
# ---------------------------------------------------------------
sig_rows = test_df[test_df["theme_code"].isin(top3_by_significance)].copy()
sig_rows = sig_rows.set_index("theme_code").loc[top3_by_significance].reset_index()

fig, axes = plt.subplots(1, len(sig_rows), figsize=(5.0 * len(sig_rows), 5.6), dpi=200)
fig.patch.set_facecolor(SURFACE)
if len(sig_rows) == 1:
    axes = [axes]
for ax, (_, row) in zip(axes, sig_rows.iterrows()):
    ax.set_facecolor(SURFACE)
    code = row["theme_code"]
    is_tagged = sample_df["themes"].apply(lambda ts: code in ts)
    tagged_views = sample_df.loc[is_tagged, "views"].values
    untagged_views = sample_df.loc[~is_tagged, "views"].values
    means = [tagged_views.mean(), untagged_views.mean()]
    sems = [tagged_views.std(ddof=1) / np.sqrt(len(tagged_views)),
            untagged_views.std(ddof=1) / np.sqrt(len(untagged_views))]
    sig = row["significant_views_p05"]
    bar_colors = [GOOD if sig else MUTED, INK2]
    bars = ax.bar(["Tagged", "Not tagged"], means, yerr=sems, capsize=6,
                   color=bar_colors, width=0.55, zorder=3,
                   error_kw={"ecolor": INK, "linewidth": 1.2})
    for b, v in zip(bars, means):
        ax.text(b.get_x() + b.get_width() / 2, v * 1.03, f"{v/1e6:.2f}M", ha="center", fontsize=9.5, color=INK)
    p = row["p_value_views"]
    p_text = f"p = {p:.3f}" if p >= 0.001 else "p < 0.001"
    sig_text = "significant (p<0.05)" if sig else "not significant"
    ax.set_title(f"{code}\n(n={int(row['n_tagged'])} tagged / n={int(row['n_untagged'])} not)",
                 fontsize=10.5, color=INK, loc="left", fontweight="bold")
    ax.text(0.5, 0.96, f"Mann-Whitney U on views\n{p_text} -- {sig_text}",
            transform=ax.transAxes, ha="center", va="top", fontsize=8.8,
            color=GOOD if sig else MUTED)
    ax.spines[["top", "right"]].set_visible(False)
    ax.spines[["left", "bottom"]].set_color(GRID)
    ax.tick_params(axis="x", length=0, labelsize=9.5, colors=INK2)
    ax.tick_params(axis="y", length=0, labelsize=8.5, colors=MUTED)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{x/1e6:.1f}M"))
    ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
    ax.set_ylim(0, max(means) * 1.35)
fig.suptitle("Mean views, tagged vs. not tagged -- the three most-significant themes tested",
             fontsize=12.5, color=INK, x=0.02, ha="left", fontweight="bold", y=1.02)
plt.tight_layout()
plt.savefig("chart_theme_significance.png", facecolor=SURFACE, bbox_inches="tight")
plt.close()

print("\nCharts and content_results.json saved.")
