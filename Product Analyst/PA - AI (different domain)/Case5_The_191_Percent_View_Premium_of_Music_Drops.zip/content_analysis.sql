-- ============================================================================
-- CASE 05 — YouTube Content Performance Analysis
-- SQL layer: run against the `videos` table (one deduped row per video_id,
-- the max-views snapshot for videos that appeared on multiple trending days).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 01. Engagement rate and like ratio per video
--     engagement_rate  = (likes + comment_total) / views
--     like_ratio       = likes / (likes + dislikes)   [NULL if likes+dislikes=0]
-- ----------------------------------------------------------------------------
SELECT
    video_id,
    title,
    category_id,
    views,
    likes,
    dislikes,
    comment_total,
    ROUND(1.0 * (likes + comment_total) / NULLIF(views, 0), 5)      AS engagement_rate,
    ROUND(1.0 * likes / NULLIF(likes + dislikes, 0), 4)             AS like_ratio
FROM videos
ORDER BY views DESC;

-- ----------------------------------------------------------------------------
-- 02. Summary stats by category_id: count, avg views, avg engagement rate,
--     avg like ratio. category_id is the raw numeric YouTube category code
--     (no lookup table shipped with this dataset, so codes are reported as-is).
-- ----------------------------------------------------------------------------
SELECT
    category_id,
    COUNT(*)                                                         AS n_videos,
    ROUND(AVG(views), 0)                                             AS avg_views,
    ROUND(AVG(1.0 * (likes + comment_total) / NULLIF(views, 0)), 5)  AS avg_engagement_rate,
    ROUND(AVG(1.0 * likes / NULLIF(likes + dislikes, 0)), 4)         AS avg_like_ratio
FROM videos
GROUP BY category_id
ORDER BY n_videos DESC;

-- ----------------------------------------------------------------------------
-- 03. Overall engagement-rate summary (platform-wide mean, for reference)
-- ----------------------------------------------------------------------------
SELECT
    COUNT(*)                                                          AS n_videos,
    ROUND(AVG(1.0 * (likes + comment_total) / NULLIF(views, 0)), 5)   AS mean_engagement_rate,
    ROUND(AVG(1.0 * likes / NULLIF(likes + dislikes, 0)), 4)          AS mean_like_ratio
FROM videos;

-- ----------------------------------------------------------------------------
-- 04. Distribution of views — used to define "high performer" (top quartile)
--     vs. "typical performer" (bottom three quartiles). SQLite has no native
--     PERCENTILE_CONT, so quartile cutoffs are computed in pandas
--     (df['views'].quantile(...)) in run_analysis.py; this query supplies the
--     raw min/max/avg/count context that accompanies that split in the report.
-- ----------------------------------------------------------------------------
SELECT
    COUNT(*)      AS n_videos,
    MIN(views)    AS min_views,
    MAX(views)    AS max_views,
    ROUND(AVG(views), 0) AS mean_views
FROM videos;

-- ----------------------------------------------------------------------------
-- 05. High performer (top quartile by views) vs. typical performer split —
--     the `is_top_quartile` flag is added in pandas before load (1/0) using
--     the Q3 cutoff from query 04's quantile calc; this compares the two
--     groups on engagement rate and like ratio.
-- ----------------------------------------------------------------------------
SELECT
    CASE WHEN is_top_quartile = 1 THEN 'top_quartile_views' ELSE 'rest' END AS performer_group,
    COUNT(*)                                                          AS n_videos,
    ROUND(AVG(views), 0)                                              AS avg_views,
    ROUND(AVG(1.0 * (likes + comment_total) / NULLIF(views, 0)), 5)   AS avg_engagement_rate,
    ROUND(AVG(1.0 * likes / NULLIF(likes + dislikes, 0)), 4)          AS avg_like_ratio
FROM videos
GROUP BY performer_group;
