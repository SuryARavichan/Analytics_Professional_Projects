-- ============================================================================
-- CASE 06 — NYC Airbnb Demand & Pricing Analysis
-- Real queries run against the "listings" table loaded from
-- airbnb_nyc_2019.csv (48,895 real NYC Airbnb listings, 2019 snapshot).
--
-- Note on cleaning: these queries run against the RAW table so the
-- data-quality counts below are honest measurements of the source data,
-- not counts on an already-cleaned copy. Downstream steps (sample
-- construction, theme analysis) drop $0-price and null-name rows and
-- impute null reviews_per_month as 0 — documented inline where relevant.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 01. Data-quality issue counts (measured before any cleaning)
-- ----------------------------------------------------------------------------
SELECT
    (SELECT COUNT(*) FROM listings)                              AS total_rows,
    (SELECT COUNT(*) FROM listings WHERE price = 0)               AS zero_price_rows,
    (SELECT COUNT(*) FROM listings WHERE name IS NULL)             AS null_name_rows,
    (SELECT COUNT(*) FROM listings WHERE reviews_per_month IS NULL) AS null_reviews_per_month_rows;

-- ----------------------------------------------------------------------------
-- 02. Median price and median reviews_per_month by room_type
-- SQLite has no native MEDIAN() function -- implemented via a percentile window
-- over the ordered values within each room_type group. reviews_per_month
-- NULLs are imputed to 0 here (no reviews = no measured demand yet),
-- matching the imputation used everywhere else in this analysis.
-- ----------------------------------------------------------------------------
WITH cleaned AS (
    SELECT
        room_type,
        price,
        COALESCE(reviews_per_month, 0.0) AS rpm
    FROM listings
    WHERE price > 0
),
price_ranked AS (
    SELECT room_type, price,
           PERCENT_RANK() OVER (PARTITION BY room_type ORDER BY price) AS pr
    FROM cleaned
),
rpm_ranked AS (
    SELECT room_type, rpm,
           PERCENT_RANK() OVER (PARTITION BY room_type ORDER BY rpm) AS pr
    FROM cleaned
)
SELECT
    c.room_type,
    COUNT(*)                                                                AS n_listings,
    (SELECT AVG(price) FROM (
        SELECT price FROM price_ranked p WHERE p.room_type = c.room_type
        ORDER BY ABS(p.pr - 0.5) LIMIT 2
    ))                                                                       AS median_price,
    ROUND(AVG(c.price), 2)                                                   AS mean_price,
    (SELECT AVG(rpm) FROM (
        SELECT rpm FROM rpm_ranked r WHERE r.room_type = c.room_type
        ORDER BY ABS(r.pr - 0.5) LIMIT 2
    ))                                                                       AS median_reviews_per_month,
    ROUND(AVG(c.rpm), 3)                                                     AS mean_reviews_per_month
FROM cleaned c
GROUP BY c.room_type
ORDER BY median_price DESC;

-- ----------------------------------------------------------------------------
-- 03. Median price and median reviews_per_month by neighbourhood_group (borough)
-- ----------------------------------------------------------------------------
WITH cleaned AS (
    SELECT
        neighbourhood_group,
        price,
        COALESCE(reviews_per_month, 0.0) AS rpm
    FROM listings
    WHERE price > 0
),
price_ranked AS (
    SELECT neighbourhood_group, price,
           PERCENT_RANK() OVER (PARTITION BY neighbourhood_group ORDER BY price) AS pr
    FROM cleaned
),
rpm_ranked AS (
    SELECT neighbourhood_group, rpm,
           PERCENT_RANK() OVER (PARTITION BY neighbourhood_group ORDER BY rpm) AS pr
    FROM cleaned
)
SELECT
    c.neighbourhood_group,
    COUNT(*)                                                                AS n_listings,
    (SELECT AVG(price) FROM (
        SELECT price FROM price_ranked p WHERE p.neighbourhood_group = c.neighbourhood_group
        ORDER BY ABS(p.pr - 0.5) LIMIT 2
    ))                                                                       AS median_price,
    ROUND(AVG(c.price), 2)                                                   AS mean_price,
    (SELECT AVG(rpm) FROM (
        SELECT rpm FROM rpm_ranked r WHERE r.neighbourhood_group = c.neighbourhood_group
        ORDER BY ABS(r.pr - 0.5) LIMIT 2
    ))                                                                       AS median_reviews_per_month,
    ROUND(AVG(c.rpm), 3)                                                     AS mean_reviews_per_month
FROM cleaned c
GROUP BY c.neighbourhood_group
ORDER BY median_price DESC;

-- ----------------------------------------------------------------------------
-- 04. Price-vs-demand summary: bucket listings into price quartiles and
-- compare mean reviews_per_month across buckets (does higher price mean
-- lower demand, all else pooled together?)
-- ----------------------------------------------------------------------------
WITH cleaned AS (
    SELECT price, COALESCE(reviews_per_month, 0.0) AS rpm
    FROM listings
    WHERE price > 0
),
quartiled AS (
    SELECT price, rpm, NTILE(4) OVER (ORDER BY price) AS price_quartile
    FROM cleaned
)
SELECT
    price_quartile,
    COUNT(*)               AS n_listings,
    MIN(price)              AS price_min,
    MAX(price)              AS price_max,
    ROUND(AVG(price), 2)    AS mean_price,
    ROUND(AVG(rpm), 3)      AS mean_reviews_per_month,
    ROUND(SUM(CASE WHEN rpm = 0 THEN 1.0 ELSE 0 END) / COUNT(*) * 100, 1) AS pct_zero_demand
FROM quartiled
GROUP BY price_quartile
ORDER BY price_quartile;

-- ----------------------------------------------------------------------------
-- 05. Reviews-per-month quartile cutoffs on the cleaned universe
-- (used downstream to define "high demand" / "low-or-no demand" for the
-- stratified 200-listing sample fed into the LLM title-theme step)
-- ----------------------------------------------------------------------------
WITH cleaned AS (
    SELECT COALESCE(reviews_per_month, 0.0) AS rpm
    FROM listings
    WHERE price > 0 AND name IS NOT NULL
),
ranked AS (
    SELECT rpm, PERCENT_RANK() OVER (ORDER BY rpm) AS pr FROM cleaned
)
SELECT
    (SELECT AVG(rpm) FROM (SELECT rpm FROM ranked ORDER BY ABS(pr - 0.25) LIMIT 2)) AS p25_reviews_per_month,
    (SELECT AVG(rpm) FROM (SELECT rpm FROM ranked ORDER BY ABS(pr - 0.50) LIMIT 2)) AS p50_reviews_per_month,
    (SELECT AVG(rpm) FROM (SELECT rpm FROM ranked ORDER BY ABS(pr - 0.75) LIMIT 2)) AS p75_reviews_per_month,
    (SELECT COUNT(*) FROM cleaned) AS n_cleaned_universe;
