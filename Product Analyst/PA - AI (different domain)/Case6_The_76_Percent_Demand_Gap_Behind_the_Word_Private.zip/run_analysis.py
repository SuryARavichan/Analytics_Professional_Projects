"""
CASE 06 — NYC Airbnb Demand & Pricing + AI Title-Theme Analysis
Deterministic analysis stage: loads the real NYC Airbnb CSV into SQLite,
runs listing_analysis.sql, loads the genuine LLM/analyst title-theme
coding (llm_title_themes.json), computes theme-level demand stats both
raw and room_type-controlled, runs Mann-Whitney U hypothesis tests, and
produces the 3 report charts + listing_results.json.
"""
import json
import sqlite3
from collections import defaultdict

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from scipy.stats import mannwhitneyu

plt.rcParams["font.family"] = "DejaVu Sans"

BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
RED = "#e34948"
GOOD = "#0ca30c"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
SURFACE = "#fcfcfb"

RANDOM_STATE = 42

# ============================================================================
# 1. SQL layer — load raw CSV into SQLite, run listing_analysis.sql
# ============================================================================
df_raw = pd.read_csv("../data/airbnb_nyc_2019.csv")
conn = sqlite3.connect(":memory:")
df_raw.to_sql("listings", conn, index=False, if_exists="replace")

with open("listing_analysis.sql") as f:
    sql_lines = f.readlines()

# strip full-line comments before splitting on ';' (comment text can itself
# contain a semicolon, e.g. "SQLite has no native MEDIAN();"), then split
# into individual SELECT statements
sql_text_nocomments = "\n".join(
    line for line in sql_lines if not line.strip().startswith("--")
)
raw_blocks = [b.strip() for b in sql_text_nocomments.split(";") if b.strip()]
queries = [b for b in raw_blocks if "SELECT" in b.upper()]

sql_labels = [
    "01_data_quality_counts",
    "02_median_price_demand_by_room_type",
    "03_median_price_demand_by_borough",
    "04_price_quartile_vs_demand",
    "05_reviews_per_month_quartile_cutoffs",
]
sql_results = {}
for label, q in zip(sql_labels, queries):
    res = pd.read_sql_query(q, conn)
    sql_results[label] = res.to_dict(orient="records")
    print("\n===", label, "===")
    print(res.to_string(index=False))

# ============================================================================
# 2. Clean universe (mirrors build_sample.py's cleaning rule)
# ============================================================================
clean = df_raw[(df_raw["price"] > 0) & (df_raw["name"].notnull())].copy()
clean["reviews_per_month"] = clean["reviews_per_month"].fillna(0.0)
full_n = len(df_raw)
clean_n = len(clean)
n_zero_price = int((df_raw["price"] == 0).sum())
n_null_name = int(df_raw["name"].isnull().sum())
n_null_rpm = int(df_raw["reviews_per_month"].isnull().sum())

# ============================================================================
# 3. Load the genuine LLM/analyst title-theme coding
# ============================================================================
theme_data = json.load(open("llm_title_themes.json"))
listings = theme_data["listings"]
taxonomy = theme_data["taxonomy"]
n_sample = len(listings)
sample_df = pd.DataFrame(listings)

all_theme_codes = sorted(taxonomy.keys())

# ----------------------------------------------------------------------------
# Theme-level demand stats, RAW (unadjusted)
# ----------------------------------------------------------------------------
theme_stats = []
for code in all_theme_codes:
    tagged_mask = sample_df["themes"].apply(lambda ts: code in ts)
    tagged = sample_df.loc[tagged_mask, "reviews_per_month"]
    untagged = sample_df.loc[~tagged_mask, "reviews_per_month"]
    if len(tagged) == 0:
        continue
    theme_stats.append({
        "theme_code": code,
        "theme_description": taxonomy[code],
        "n_tagged": int(len(tagged)),
        "n_untagged": int(len(untagged)),
        "mean_rpm_tagged": round(float(tagged.mean()), 3),
        "median_rpm_tagged": round(float(tagged.median()), 3),
        "mean_rpm_untagged": round(float(untagged.mean()), 3),
        "median_rpm_untagged": round(float(untagged.median()), 3),
        "mean_diff": round(float(tagged.mean() - untagged.mean()), 3),
    })
theme_stats_df = pd.DataFrame(theme_stats).sort_values("mean_diff", ascending=False)

# ----------------------------------------------------------------------------
# Pick top-3 candidate themes to test rigorously: themes with n_tagged >= 15
# (enough for a meaningful within-room_type breakdown), ranked by absolute
# raw mean-difference in reviews_per_month -- the themes with the largest
# apparent effect on the surface, which is exactly what deserves scrutiny.
# ----------------------------------------------------------------------------
eligible = theme_stats_df[theme_stats_df["n_tagged"] >= 15].copy()
eligible["abs_diff"] = eligible["mean_diff"].abs()
top_candidates = eligible.sort_values("abs_diff", ascending=False).head(3)["theme_code"].tolist()
print("\nTop candidate themes for controlled testing:", top_candidates)

# Also test LOCATION_ANCHOR (the single most common theme, present in the
# majority of titles) purely for narrative context even though its raw
# effect size did not make the top-3 cut -- readers will want to know
# whether the "obvious" language dimension matters, and it doesn't.
NARRATIVE_EXTRA_THEME = "LOCATION_ANCHOR"

# ============================================================================
# 4. Room-type-controlled comparison + Mann-Whitney U tests
# ============================================================================
ROOM_TYPES_FOR_CONTROL = ["Entire home/apt", "Private room"]  # Shared room n=3, excluded from controlled test

themes_to_test = top_candidates + (
    [NARRATIVE_EXTRA_THEME] if NARRATIVE_EXTRA_THEME not in top_candidates else []
)

hypothesis_tests = []
controlled_detail = []
for code in themes_to_test:
    tagged_mask = sample_df["themes"].apply(lambda ts: code in ts)
    tagged = sample_df.loc[tagged_mask, "reviews_per_month"]
    untagged = sample_df.loc[~tagged_mask, "reviews_per_month"]

    u_stat, p_val = mannwhitneyu(tagged, untagged, alternative="two-sided")

    row = {
        "theme_code": code,
        "unadjusted": {
            "n_tagged": int(len(tagged)),
            "n_untagged": int(len(untagged)),
            "mean_rpm_tagged": round(float(tagged.mean()), 3),
            "mean_rpm_untagged": round(float(untagged.mean()), 3),
            "median_rpm_tagged": round(float(tagged.median()), 3),
            "median_rpm_untagged": round(float(untagged.median()), 3),
            "u_statistic": round(float(u_stat), 1),
            "p_value": round(float(p_val), 4),
            "significant_p05": bool(p_val < 0.05),
        },
        "room_type_controlled": {},
    }

    survives_any = False
    for rt in ROOM_TYPES_FOR_CONTROL:
        rt_df = sample_df[sample_df["room_type"] == rt]
        rt_tagged_mask = rt_df["themes"].apply(lambda ts: code in ts)
        rt_tagged = rt_df.loc[rt_tagged_mask, "reviews_per_month"]
        rt_untagged = rt_df.loc[~rt_tagged_mask, "reviews_per_month"]
        if len(rt_tagged) < 5 or len(rt_untagged) < 5:
            row["room_type_controlled"][rt] = {
                "n_tagged": int(len(rt_tagged)), "n_untagged": int(len(rt_untagged)),
                "note": "too few observations for a reliable test (n<5 in one group)"
            }
            continue
        rt_u, rt_p = mannwhitneyu(rt_tagged, rt_untagged, alternative="two-sided")
        sig = bool(rt_p < 0.05)
        if sig:
            survives_any = True
        row["room_type_controlled"][rt] = {
            "n_tagged": int(len(rt_tagged)),
            "n_untagged": int(len(rt_untagged)),
            "mean_rpm_tagged": round(float(rt_tagged.mean()), 3),
            "mean_rpm_untagged": round(float(rt_untagged.mean()), 3),
            "median_rpm_tagged": round(float(rt_tagged.median()), 3),
            "median_rpm_untagged": round(float(rt_untagged.median()), 3),
            "u_statistic": round(float(rt_u), 1),
            "p_value": round(float(rt_p), 4),
            "significant_p05": sig,
        }
        controlled_detail.append({
            "theme_code": code, "room_type": rt,
            "mean_rpm_tagged": float(rt_tagged.mean()), "mean_rpm_untagged": float(rt_untagged.mean()),
        })

    row["verdict"] = (
        "Survives room_type control (significant within at least one room type)"
        if survives_any else
        "Does NOT survive room_type control (raw difference looks like a room-type effect in disguise)"
    )
    row["is_top3_candidate"] = code in top_candidates
    hypothesis_tests.append(row)
    print(f"\n{code}: unadjusted p={p_val:.4f}, verdict: {row['verdict']}")

# ============================================================================
# 5. Save listing_results.json
# ============================================================================
results = {
    "data_summary": {
        "full_dataset_n": int(full_n),
        "clean_universe_n": int(clean_n),
        "n_zero_price_dropped": n_zero_price,
        "n_null_name_dropped": n_null_name,
        "n_null_reviews_per_month_imputed_zero": n_null_rpm,
    },
    "sql_results": sql_results,
    "sample_construction": {
        "n_sample": n_sample,
        "random_state": RANDOM_STATE,
        "note": "100 from top quartile of reviews_per_month (high demand) + 100 from bottom "
                "half (low/no demand) -- a deliberate oversample of the high-demand tail, not "
                "representative of the true ~25%/50% split.",
    },
    "theme_frequency_and_raw_demand": theme_stats_df.to_dict(orient="records"),
    "top_candidate_themes": top_candidates,
    "hypothesis_tests": hypothesis_tests,
}
with open("listing_results.json", "w") as f:
    json.dump(results, f, indent=2, default=str)

print("\nlisting_results.json saved.")

# ============================================================================
# CHART 1 — theme_theme_demand.png: mean reviews_per_month by theme, sorted
# ============================================================================
plot_df = theme_stats_df.sort_values("mean_rpm_tagged", ascending=True)
overall_mean = sample_df["reviews_per_month"].mean()

fig, ax = plt.subplots(figsize=(9.8, 5.6), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
colors_bar = [AQUA if v >= overall_mean else MUTED for v in plot_df["mean_rpm_tagged"]]
bars = ax.barh(plot_df["theme_code"].str.replace("_", " ").str.title(), plot_df["mean_rpm_tagged"],
                color=colors_bar, height=0.6, zorder=3)
for b, v, n in zip(bars, plot_df["mean_rpm_tagged"], plot_df["n_tagged"]):
    ax.text(v + 0.05, b.get_y() + b.get_height() / 2, f"{v:.2f}  (n={n})",
            va="center", fontsize=9, color=INK)
ax.axvline(overall_mean, color=RED, linestyle="--", linewidth=1.2, zorder=2)
ax.text(overall_mean, len(plot_df) - 0.2, f" sample mean {overall_mean:.2f}",
        color=RED, fontsize=9, va="bottom")
ax.set_title("Mean reviews/month by title theme (200-listing coded sample)",
              fontsize=12.5, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_xlabel("Mean reviews per month (tagged listings)", fontsize=9.5, color=INK2)
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="y", length=0, labelsize=10, colors=INK2)
ax.tick_params(axis="x", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
ax.set_xlim(0, plot_df["mean_rpm_tagged"].max() * 1.32)
plt.tight_layout()
plt.savefig("chart_theme_demand.png", facecolor=SURFACE)
plt.close()

# ============================================================================
# CHART 2 — chart_price_vs_demand.png: price vs reviews_per_month scatter,
# colored by room_type, log-scale on price (full clean universe, subsampled
# for plot legibility since n=48,868)
# ============================================================================
plot_universe = clean.sample(n=6000, random_state=RANDOM_STATE)
room_colors = {"Entire home/apt": BLUE, "Private room": ORANGE, "Shared room": AQUA}

fig, ax = plt.subplots(figsize=(9.6, 5.8), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
for rt, color in room_colors.items():
    sub = plot_universe[plot_universe["room_type"] == rt]
    ax.scatter(sub["price"], sub["reviews_per_month"], s=9, alpha=0.35, color=color,
               label=rt, edgecolors="none", zorder=3)
ax.set_xscale("log")
ax.set_xlim(10, 2000)
ax.set_ylim(-0.5, 20)
ax.set_title("Price vs. demand: higher price does not buy more reviews",
              fontsize=12.5, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_xlabel("Price per night (log scale, $)", fontsize=9.5, color=INK2)
ax.set_ylabel("Reviews per month (demand proxy)", fontsize=9.5, color=INK2)
ax.spines[["top", "right"]].set_visible(False)
ax.spines[["bottom", "left"]].set_color(GRID)
ax.tick_params(length=0, labelsize=9, colors=MUTED)
ax.grid(color=GRID, linewidth=0.7, zorder=0)
leg = ax.legend(frameon=False, fontsize=9.5, loc="upper right", labelcolor=INK2, title="Room type")
leg.get_title().set_fontsize(9.5)
leg.get_title().set_color(INK2)
plt.tight_layout()
plt.savefig("chart_price_vs_demand.png", facecolor=SURFACE)
plt.close()

# ============================================================================
# CHART 3 — chart_theme_controlled.png: before/after controlling for room_type,
# for the top tested themes
# ============================================================================
fig, ax = plt.subplots(figsize=(9.8, 5.2), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)

group_labels = []
raw_diffs = []
controlled_avg_diffs = []
verdicts = []
for row in hypothesis_tests:
    if not row["is_top3_candidate"]:
        continue  # chart shows only the top-3 rigorously tested themes
    code = row["theme_code"]
    raw_diff = row["unadjusted"]["mean_rpm_tagged"] - row["unadjusted"]["mean_rpm_untagged"]
    # average the within-room_type diffs (weighted by n_tagged) as the "controlled" effect
    diffs, weights = [], []
    for rt, d in row["room_type_controlled"].items():
        if "mean_rpm_tagged" in d:
            diffs.append(d["mean_rpm_tagged"] - d["mean_rpm_untagged"])
            weights.append(d["n_tagged"])
    controlled_diff = float(np.average(diffs, weights=weights)) if diffs else 0.0
    group_labels.append(code.replace("_", " ").title())
    raw_diffs.append(raw_diff)
    controlled_avg_diffs.append(controlled_diff)
    verdicts.append("Survives" in row["verdict"])

y = np.arange(len(group_labels))
h = 0.34
b1 = ax.barh(y + h / 2, raw_diffs, height=h, color=MUTED, label="Raw (unadjusted) difference", zorder=3)
b2 = ax.barh(y - h / 2, controlled_avg_diffs,
             color=[GOOD if v else RED for v in verdicts], height=h,
             label="Room-type-controlled difference", zorder=3)
for bars in (b1, b2):
    for b in bars:
        w = b.get_width()
        ax.text(w + (0.03 if w >= 0 else -0.03), b.get_y() + b.get_height() / 2, f"{w:+.2f}",
                va="center", ha="left" if w >= 0 else "right", fontsize=9, color=INK)
ax.axvline(0, color=INK2, linewidth=0.9, zorder=2)
ax.set_yticks(y)
ax.set_yticklabels(group_labels, fontsize=10.5, color=INK2)
ax.set_xlabel("Difference in mean reviews/month (tagged minus untagged)", fontsize=9.5, color=INK2)
ax.set_title("Does the theme's demand edge survive controlling for room type?",
              fontsize=12.5, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="y", length=0)
ax.tick_params(axis="x", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
ax.set_xlim(min(min(raw_diffs), min(controlled_avg_diffs)) * 1.25,
            max(max(raw_diffs), max(controlled_avg_diffs)) * 1.45)
ax.legend(frameon=False, fontsize=9, loc="upper right", labelcolor=INK2)
plt.tight_layout()
plt.savefig("chart_theme_controlled.png", facecolor=SURFACE)
plt.close()

print("\nCharts saved: chart_theme_demand.png, chart_price_vs_demand.png, chart_theme_controlled.png")
print("\nTop candidate themes tested:", top_candidates)
for row in hypothesis_tests:
    print(json.dumps(row, indent=2, default=str))
