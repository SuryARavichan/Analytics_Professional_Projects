"""
trust_score.py — computes a composite, interpretable Trust Score (0-100)
from CHEAP, always-available behavioral signals (does the user accept the
AI's output as-is, edit it, regenerate it, or give explicit feedback) --
the signal a real product monitors continuously at scale, as opposed to
the EXPENSIVE LLM-as-judge score (llm_judge.py) that can only be computed
on a small sample.

Composite weights (documented, not hidden): 40% accept-as-is rate + 25%
(1 - regenerate rate) + 20% (1 - edit penalty, where edit penalty =
edit rate x mean edit extent when edited) + 15% net thumbs sentiment
among users who gave explicit feedback. Acceptance is weighted highest
because it's the strongest revealed-preference signal (no friction, no
subjective feedback threshold) that a response needed zero correction.
"""
import numpy as np
import pandas as pd
from scipy import stats


def compute_trust_score(df: pd.DataFrame) -> dict:
    accept_rate = df.accepted_as_is.mean()
    regen_rate = df.regenerated.mean()
    edited = df[df.edited]
    mean_edit_extent = edited.edit_extent.mean() if len(edited) else 0.0
    edit_penalty = df.edited.mean() * mean_edit_extent

    fb = df[df.feedback != "none"]
    thumbs_net = (fb.feedback.eq("up").sum() - fb.feedback.eq("down").sum()) / len(fb) if len(fb) else 0.0

    score = 100 * (0.40 * accept_rate + 0.25 * (1 - regen_rate) + 0.20 * (1 - edit_penalty) + 0.15 * ((thumbs_net + 1) / 2))
    return {
        "trust_score": round(score, 1), "n": len(df), "accept_rate": round(accept_rate, 3),
        "regen_rate": round(regen_rate, 3), "edit_penalty": round(edit_penalty, 3),
        "thumbs_net": round(thumbs_net, 3), "feedback_rate": round(len(fb) / len(df), 3) if len(df) else 0.0,
    }


def trust_score_by_group(df: pd.DataFrame, group_cols: list[str]) -> pd.DataFrame:
    rows = []
    for keys, sub in df.groupby(group_cols):
        keys = keys if isinstance(keys, tuple) else (keys,)
        row = dict(zip(group_cols, keys))
        row.update(compute_trust_score(sub))
        rows.append(row)
    return pd.DataFrame(rows)


def compare_versions(df: pd.DataFrame, task_type: str, metric_col: str = "accepted_as_is") -> dict:
    """Two-proportion z-test comparing v1 vs v2 on a binary behavioral
    metric (default: accept-as-is rate), for one task type."""
    sub = df[df.task_type == task_type]
    v1, v2 = sub[sub.model_version == "v1"], sub[sub.model_version == "v2"]
    n1, n2 = len(v1), len(v2)
    x1, x2 = v1[metric_col].sum(), v2[metric_col].sum()
    p1, p2 = x1 / n1, x2 / n2
    p_pool = (x1 + x2) / (n1 + n2)
    se = np.sqrt(p_pool * (1 - p_pool) * (1 / n1 + 1 / n2))
    z = (p2 - p1) / se if se > 0 else 0.0
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"task_type": task_type, "metric": metric_col, "v1_rate": round(p1, 3), "v2_rate": round(p2, 3),
            "delta_pp": round((p2 - p1) * 100, 2), "z": round(z, 2), "p_value": p_value}
