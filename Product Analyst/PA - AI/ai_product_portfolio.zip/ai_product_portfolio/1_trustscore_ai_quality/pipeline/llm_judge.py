"""
llm_judge.py — the EXPENSIVE evaluation path: send a real prompt/response
pair to an LLM judge and get back a 0-100 quality score with a rationale.
This does not scale to every generation (cost, latency), which is exactly
why trust_score.py's cheap behavioral proxy exists -- the point of this
module, paired with validate.py, is to confirm the cheap proxy is a
trustworthy stand-in for this expensive one, using a carefully-read small
sample as ground truth.
"""
from __future__ import annotations
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "shared"))
from llm_client import LLMClient  # noqa: E402

JUDGE_SYSTEM_PROMPT = (
    "You are an expert quality reviewer for an AI writing/coding assistant (Cortex Copilot). "
    "You will be given a user prompt and the AI's response. Score the response's quality from 0-100 "
    "based on correctness, completeness, and whether it's actually usable as-is. Be especially strict "
    "about factual/hallucinated claims not supported by the input, and about code that would not "
    "actually run. Respond in the exact format:\nSCORE: <0-100>/100\nRATIONALE: <one or two sentences>"
)


def judge_sample(sample: dict, client: LLMClient) -> dict:
    prompt = f"USER PROMPT:\n{sample['prompt']}\n\nAI RESPONSE:\n{sample['ai_response']}"
    resp = client.complete(prompt=prompt, system=JUDGE_SYSTEM_PROMPT, prompt_id=f"judge_{sample['sample_id']}")
    match = re.search(r"SCORE:\s*(\d+)", resp.text)
    score = int(match.group(1)) if match else None
    return {"sample_id": sample["sample_id"], "task_type": sample["task_type"],
            "model_version": sample["model_version"], "judge_score": score, "rationale_text": resp.text}


def judge_all_samples(samples: list[dict], client: LLMClient) -> "pd.DataFrame":
    import pandas as pd
    return pd.DataFrame([judge_sample(s, client) for s in samples])
