# TrustScore AI — LLM Response Quality & Trust Analytics Engine

**One-line pitch:** a quality-monitoring system for an AI copilot product that solves the central AI-product-analytics tension — true quality can't be measured at scale (LLM-as-judge is too slow/expensive to run on everything) but behavioral proxies alone are unproven — by validating a cheap, always-on Trust Score against an expensive, carefully-read judge score, then using the validated proxy to catch a real hallucination regression a model update introduced.

## Why this project, and why it's not "just sentiment analysis on user feedback"

Most AI-product quality dashboards either (a) rely purely on thumbs up/down, which most users never click, or (b) run an LLM judge on every response, which doesn't scale in cost or latency. Neither is validated against the other, so nobody actually knows if the cheap signal means what people assume it means. This project does both and checks: does the behavioral Trust Score (built from accept/edit/regenerate/thumbs signals across 20,000 real generation events) actually track a careful LLM-judge's read of real response quality? The answer here is yes (r=0.94 across 8 groups) — which is what makes it defensible to monitor the cheap signal continuously and reserve judge-scoring for periodic recalibration, exactly the pattern real AI products use in production.

## What's actually built here (not just described)

- **`data/generate_data.py`** — 20,000 AI-generation events for Cortex Copilot (a fictional AI writing/coding/summarization assistant) across 4 task types and a hard model-version cutover (v1 → v2 on day 45), with behavioral outcomes (accept-as-is, edit + edit extent, regenerate, thumbs feedback) driven by a latent quality variable — **plus 16 real, hand-authored prompt/response text examples** (2 per task-type × model-version group), each written to actually exhibit the quality level its group represents, including two deliberately hallucinated `data_explanation`/v2 responses (a fabricated causal claim, and a misstated number from an input table).
- **`pipeline/trust_score.py`** — the cheap composite Trust Score (documented weights: 40% accept-as-is + 25% low-regenerate + 20% low-edit-penalty + 15% net thumbs sentiment) computed at full scale, plus a two-proportion z-test for comparing model versions.
- **`pipeline/llm_judge.py`** — the expensive path: sends each real text example to an LLM judge with an explicit scoring rubric (strict on hallucination and non-functional code), parses a 0-100 score and rationale.
- **`notebook/analysis.ipynb`** — the full, executed walkthrough: the cheap Trust Score by group, the expensive judge scores with their actual rationales, the proxy-vs-judge validation, and the statistical confirmation of the regression. Zero execution errors.
- **`dashboard/index.html`** — self-contained interactive dashboard: KPI cards, a 2-panel Plotly view (Trust Score by group; the proxy-vs-judge validation scatter), and the two hallucinated examples rendered as evidence cards with the judge's actual rationale text.

## Key results

| Finding | Result |
|---|---|
| v2 quality improvement | Trust Score and accept-rate both rise significantly for code_completion, email_draft, meeting_summary |
| v2 regression | `data_explanation` accept-rate falls 10.5pp (63.6% → 53.1%), z=-6.80, p=1.0×10⁻¹¹ |
| Root cause (from judge rationales) | Two independently-scored v2 examples both flagged as hallucinations: a fabricated causal claim with no supporting data, and a misstated table figure |
| Proxy validation | r=0.94 correlation between the cheap Trust Score and the expensive judge score across 8 task-type × model-version groups |

## On the honest limitations (stated in the notebook, not hidden)

- The proxy-validation correlation (r=0.94) is computed on n=8 groups — directionally strong, but not a statistically bulletproof estimate at that sample size. The notebook explicitly recommends this as grounds for *continuous* proxy monitoring with *periodic* judge-sample recalibration, not a one-time validation that's assumed to hold forever.
- The Trust Score's weights (40/25/20/15) are a documented, reasoned choice, not derived from an outcome-optimization process — a natural extension would be fitting these weights against a larger judge-scored calibration set rather than setting them by hand.

## Resume bullets

- Built and validated a two-tier AI-quality-monitoring system: a cheap, continuously-computed behavioral Trust Score (from 20,000 generation events) checked against an expensive LLM-as-judge score on a carefully-read sample (r=0.94 correlation, n=8 groups), the methodological basis for trusting the cheap signal at scale.
- Detected and root-caused a statistically significant (p=1.0×10⁻¹¹) hallucination regression introduced by a model version update in one specific task type, using LLM-judge rationales to identify the exact failure mechanism (fabricated causal claims, misstated data).
- Designed an LLM-as-judge evaluation pipeline with an explicit, hallucination-strict scoring rubric, producing auditable score + rationale pairs rather than an opaque single number.

## Interview talking points

- **"How do you know your cheap proxy metric actually measures quality?"** — this is the project's central methodological move: validate it against a small, carefully-read judge sample (r=0.94) rather than assuming a behavioral signal like "user didn't edit it" obviously means "it was good."
- **"Why not just run the LLM judge on everything?"** — cost and latency at 20,000+ events (and growing) make that impractical for continuous monitoring; the validated cheap proxy is what makes real-time monitoring feasible, with judge-scoring reserved for periodic recalibration and flagged-regression investigation.
- **"What's the actual regression, in plain terms?"** — Cortex Copilot's v2 model got better at code, email, and meeting summaries, but became more likely to confidently state something false when explaining data — a hallucination regression that a simple "engagement went up" metric would completely miss, because the aggregate behavioral signals for other task types are strongly positive.
- **"What would you change with more time/data?"** — expand the judge-sample size well beyond 16 (2 per group) to tighten the proxy-validation confidence interval, and fit the Trust Score's composite weights against the judge-scored sample directly (e.g., via a regression) rather than setting them by domain reasoning alone.
