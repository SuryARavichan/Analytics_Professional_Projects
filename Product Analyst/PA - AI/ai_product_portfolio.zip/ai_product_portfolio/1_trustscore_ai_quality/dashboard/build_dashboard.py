"""
Builds TrustScore AI's self-contained HTML dashboard: KPI cards, a
2-panel Plotly view (Trust Score by group, and the proxy-vs-judge
validation scatter), and the two hallucinated data_explanation/v2 judge
examples rendered as evidence cards.
"""
import sys, json
sys.path.insert(0, "../../shared")
sys.path.insert(0, "../pipeline")
import pandas as pd
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
from trust_score import trust_score_by_group, compare_versions
from llm_judge import judge_all_samples
from llm_client import get_client

generations = pd.read_csv("../data/generations.csv")
tscore = trust_score_by_group(generations, ["task_type", "model_version"])

client = get_client(cache_file="../cached_responses.json")
samples = json.load(open("../data/judge_samples.json"))
judged = judge_all_samples(samples, client)
judge_group = judged.groupby(["task_type", "model_version"]).judge_score.mean().reset_index()
validation = tscore.merge(judge_group, on=["task_type", "model_version"])
corr = validation.trust_score.corr(validation.judge_score)

de_regression = compare_versions(generations, "data_explanation", metric_col="accepted_as_is")

fig = make_subplots(rows=1, cols=2, subplot_titles=(
    "Trust Score by Task Type & Model Version", f"Cheap Proxy vs. Expensive Judge (r={corr:.2f}, n=8 groups)"))

pivot = tscore.pivot(index="task_type", columns="model_version", values="trust_score")
fig.add_trace(go.Bar(x=pivot.index, y=pivot["v1"], name="v1", marker_color="#95A5A6"), row=1, col=1)
fig.add_trace(go.Bar(x=pivot.index, y=pivot["v2"], name="v2", marker_color="#2E86AB"), row=1, col=1)

colors_v = {"v1": "#95A5A6", "v2": "#2E86AB"}
for v in ["v1", "v2"]:
    sub = validation[validation.model_version == v]
    fig.add_trace(go.Scatter(x=sub.judge_score, y=sub.trust_score, mode="markers+text",
                              text=sub.task_type.str[:2].str.upper(), textposition="top center",
                              marker=dict(size=14, color=colors_v[v]), name=f"{v} (judge vs proxy)"), row=1, col=2)

fig.update_yaxes(title_text="Trust Score (0-100)", row=1, col=1)
fig.update_xaxes(title_text="Mean judge score", row=1, col=2)
fig.update_yaxes(title_text="Trust Score", row=1, col=2)
fig.update_layout(
    height=480, barmode="group",
    font=dict(family="Inter, Segoe UI, Arial", size=11.5),
    plot_bgcolor="white", paper_bgcolor="#FAFAFA", margin=dict(t=60, l=60, r=30, b=50),
)
html_chart = pio.to_html(fig, include_plotlyjs="inline", full_html=False, config={"displaylogo": False})

hallucination_1 = judged.loc[judged.sample_id == "de_v2_a"].iloc[0]
hallucination_2 = judged.loc[judged.sample_id == "de_v2_b"].iloc[0]

page = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>TrustScore AI — Response Quality Dashboard</title>
<style>
  body {{ font-family: Inter, 'Segoe UI', Arial, sans-serif; margin:0; background:#FAFAFA; color:#1a1a1a; }}
  .wrap {{ max-width: 1300px; margin: 0 auto; padding: 24px; }}
  h1 {{ font-size: 22px; margin-bottom:2px; }}
  .sub {{ color:#666; font-size:14px; margin-bottom: 18px; }}
  .kpis {{ display:flex; gap:16px; margin-bottom: 18px; flex-wrap: wrap; }}
  .kpi {{ background:white; border-radius:10px; padding:16px 22px; box-shadow:0 1px 4px rgba(0,0,0,0.08); flex:1; min-width:200px; }}
  .kpi .val {{ font-size:24px; font-weight:700; color:#2E86AB; }}
  .kpi .lbl {{ font-size:12px; color:#666; text-transform:uppercase; letter-spacing:0.03em; margin-top:2px; }}
  .panel {{ background:white; border-radius:12px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:8px 16px; margin-bottom:20px; }}
  .cards {{ display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin: 20px 0; }}
  .card {{ background:white; border-radius:10px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:16px 18px; font-size:13px; line-height:1.6; }}
  .card h3 {{ margin:0 0 8px; font-size:14px; }}
  .card .badge {{ display:inline-block; background:#C0392B; color:white; font-size:11px; font-weight:700; padding:2px 8px; border-radius:8px; margin-bottom:8px; }}
  .card pre {{ background:#1e1e2e; color:#cdd6f4; padding:10px 12px; border-radius:6px; font-size:12px; overflow-x:auto; white-space:pre-wrap; }}
  .card .rationale {{ background:#FFF7E6; border-left:4px solid #E8A33D; padding:8px 12px; border-radius:6px; margin-top:8px; }}
  footer {{ font-size:12px; color:#888; text-align:center; padding: 24px 0; }}
  @media (max-width: 900px) {{ .cards {{ grid-template-columns: 1fr; }} }}
</style></head>
<body><div class="wrap">
  <h1>🎯 TrustScore AI — LLM Response Quality &amp; Trust Analytics Engine</h1>
  <div class="sub">A cheap, always-on behavioral Trust Score, validated against an expensive LLM-as-judge score on a carefully-read sample — used together to catch a real hallucination regression a model update introduced.</div>
  <div class="kpis">
    <div class="kpi"><div class="val">r={corr:.2f}</div><div class="lbl">Proxy-vs-Judge Correlation (n=8 groups)</div></div>
    <div class="kpi"><div class="val">{de_regression['delta_pp']:.1f}pp</div><div class="lbl">data_explanation Accept-Rate Regression (v1→v2)</div></div>
    <div class="kpi"><div class="val">20,000</div><div class="lbl">Generation Events Monitored</div></div>
    <div class="kpi"><div class="val">16</div><div class="lbl">Real Judge-Scored Examples</div></div>
  </div>
  <div class="panel">{html_chart}</div>
  <h2 style="font-size:16px;">The Regression, In the Model's Own Words</h2>
  <div class="cards">
    <div class="card">
      <span class="badge">SCORE: 12/100</span>
      <h3>{hallucination_1.sample_id} — data_explanation / v2</h3>
      <pre>{hallucination_1.rationale_text.split(chr(10),1)[0]}</pre>
      <div class="rationale">{hallucination_1.rationale_text.split(chr(10),1)[1].replace('RATIONALE: ','')}</div>
    </div>
    <div class="card">
      <span class="badge">SCORE: 25/100</span>
      <h3>{hallucination_2.sample_id} — data_explanation / v2</h3>
      <pre>{hallucination_2.rationale_text.split(chr(10),1)[0]}</pre>
      <div class="rationale">{hallucination_2.rationale_text.split(chr(10),1)[1].replace('RATIONALE: ','')}</div>
    </div>
  </div>
  <footer>Cached-mode demo (see README) — Trust Score is computed from real behavioral simulation, judge scores are real LLM output on real hand-authored text · full analysis in <code>/notebook/analysis.ipynb</code></footer>
</div></body></html>"""

with open("index.html", "w") as f:
    f.write(page)
print("Wrote dashboard/index.html —", len(page), "bytes")
