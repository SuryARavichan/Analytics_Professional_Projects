"""
Generates two linked artifacts for TrustScore AI, both centered on Cortex
Copilot (a fictional AI writing/coding/summarization assistant embedded
in a B2B productivity suite):

  1. generations.csv — 20,000 large-scale AI-generation events over a
     90-day window across 4 task types and 2 model versions (v2 replaces
     v1 for all traffic on day 45), each with a latent "true quality"
     value driving realistic behavioral signals (accept-as-is, edit,
     regenerate, thumbs feedback) -- the CHEAP, always-available signal
     a real product monitors at scale.
  2. judge_samples.json — 16 real, hand-authored short prompt/response
     text pairs (2 per task-type x model-version group), each written to
     actually exhibit the quality level its group is meant to represent
     (including two deliberately hallucinated data_explanation/v2
     responses) -- the EXPENSIVE, small-sample signal (an LLM-as-judge
     score) used to validate that the cheap behavioral signal can be
     trusted as a stand-in for it.

The built-in story: v2 is a genuine quality improvement for
code_completion, email_draft, and meeting_summary, but REGRESSES for
data_explanation specifically -- a realistic "this model update helped
almost everything except one task type" finding, discoverable
independently through both the large-scale behavioral data AND the
small, carefully-read judge sample.
"""
import json
import numpy as np
import pandas as pd
from datetime import datetime, timedelta

rng = np.random.default_rng(505)

START = datetime(2025, 1, 1)
DAYS = 90
CUTOVER_DAY = 45  # day v2 fully replaces v1 for all traffic

TASK_TYPES = ["code_completion", "email_draft", "meeting_summary", "data_explanation"]
TASK_SHARE = {"code_completion": 0.35, "email_draft": 0.25, "meeting_summary": 0.20, "data_explanation": 0.20}

# baseline latent quality (0-100) by task_type x model_version -- the one
# regression story: data_explanation gets WORSE under v2 (hallucination-prone)
BASELINE_QUALITY = {
    ("code_completion", "v1"): 68, ("code_completion", "v2"): 78,
    ("email_draft", "v1"): 72, ("email_draft", "v2"): 80,
    ("meeting_summary", "v1"): 70, ("meeting_summary", "v2"): 78,
    ("data_explanation", "v1"): 75, ("data_explanation", "v2"): 63,
}

N = 20000
rows = []
for i in range(N):
    day_offset = rng.integers(0, DAYS)
    date = START + timedelta(days=int(day_offset))
    model_version = "v1" if day_offset < CUTOVER_DAY else "v2"
    task_type = rng.choice(TASK_TYPES, p=[TASK_SHARE[t] for t in TASK_TYPES])

    baseline = BASELINE_QUALITY[(task_type, model_version)]
    latent_quality = np.clip(rng.normal(baseline, 12), 5, 99)
    q = latent_quality / 100

    p_accept = np.clip(0.10 + 0.85 * q ** 1.6, 0.02, 0.97)
    accepted_as_is = rng.random() < p_accept

    regenerated, edited, edit_extent = False, False, 0.0
    if not accepted_as_is:
        p_regen_given_not_accept = np.clip(0.55 - 0.40 * q, 0.08, 0.85)
        regenerated = rng.random() < p_regen_given_not_accept
        if not regenerated:
            edited = True
            edit_extent = float(np.clip(rng.normal(0.55 - 0.45 * q, 0.12), 0.03, 0.95))

    p_thumbs_up = np.clip(0.04 + 0.28 * q ** 2, 0, 0.35)
    p_thumbs_down = np.clip(0.22 * (1 - q) ** 2, 0, 0.28)
    roll = rng.random()
    feedback = "up" if roll < p_thumbs_up else ("down" if roll < p_thumbs_up + p_thumbs_down else "none")

    rows.append({
        "event_id": f"G{300000+i}", "date": date.date(), "task_type": task_type, "model_version": model_version,
        "latent_quality": round(latent_quality, 1),
        "accepted_as_is": accepted_as_is, "edited": edited, "edit_extent": round(edit_extent, 3),
        "regenerated": regenerated, "feedback": feedback,
    })

generations = pd.DataFrame(rows)
generations.to_csv("generations.csv", index=False)

print(f"generations: {len(generations):,} rows | {generations.date.min()} to {generations.date.max()}")
print(generations.groupby(["task_type", "model_version"]).agg(
    n=("event_id", "count"), mean_latent_quality=("latent_quality", "mean"),
    accept_rate=("accepted_as_is", "mean"), regen_rate=("regenerated", "mean"),
).round(3))

# ============================================================
# judge_samples.json -- 16 real, hand-authored, quality-differentiated
# prompt/response text pairs (2 per task_type x model_version group)
# ============================================================
judge_samples = [
    {"sample_id": "cc_v1_a", "task_type": "code_completion", "model_version": "v1",
     "prompt": "Write a Python function to check if a string is a palindrome.",
     "ai_response": "def is_palindrome(s: str) -> bool:\n    cleaned = s.lower().replace(' ', '')\n    return cleaned == cleaned[::-1]"},
    {"sample_id": "cc_v1_b", "task_type": "code_completion", "model_version": "v1",
     "prompt": "Write a function to compute the factorial of n using recursion.",
     "ai_response": "def factorial(n):\n    if n = 0:\n        return 1\n    return n * factorial(n-1)"},
    {"sample_id": "cc_v2_a", "task_type": "code_completion", "model_version": "v2",
     "prompt": "Write a function that returns the nth Fibonacci number iteratively.",
     "ai_response": "def fibonacci(n: int) -> int:\n    a, b = 0, 1\n    for _ in range(n):\n        a, b = b, a + b\n    return a"},
    {"sample_id": "cc_v2_b", "task_type": "code_completion", "model_version": "v2",
     "prompt": "Write a function to merge two sorted lists into one sorted list.",
     "ai_response": "def merge_sorted(a: list, b: list) -> list:\n    result, i, j = [], 0, 0\n    while i < len(a) and j < len(b):\n        if a[i] <= b[j]:\n            result.append(a[i]); i += 1\n        else:\n            result.append(b[j]); j += 1\n    return result + a[i:] + b[j:]"},
    {"sample_id": "ed_v1_a", "task_type": "email_draft", "model_version": "v1",
     "prompt": "Draft a short email to a client apologizing for a shipping delay.",
     "ai_response": "Subject: Update on Your Order\n\nHi [Name],\n\nWe wanted to let you know that your order is experiencing a slight delay due to circumstances beyond our control. We apologize for any inconvenience this may cause and appreciate your patience as we work to resolve this matter as quickly as possible.\n\nBest regards,\nThe Team"},
    {"sample_id": "ed_v1_b", "task_type": "email_draft", "model_version": "v1",
     "prompt": "Draft a follow-up email after a sales call.",
     "ai_response": "Subject: Great Speaking With You\n\nHi [Name],\n\nThanks for the call today. As discussed, I'll follow up with pricing details by [insert date]. Let me know if you have questions in the meantime.\n\nBest,\n[Your Name]"},
    {"sample_id": "ed_v2_a", "task_type": "email_draft", "model_version": "v2",
     "prompt": "Draft a short email to a client apologizing for a shipping delay.",
     "ai_response": "Subject: Your Order #48213 — Shipping Update\n\nHi Priya,\n\nYour order is running about 3 days behind schedule due to a carrier capacity issue in your region. It's now scheduled to arrive by Thursday. As an apology, we've applied a 10% credit to your account for your next order.\n\nThanks for your patience,\nJordan"},
    {"sample_id": "ed_v2_b", "task_type": "email_draft", "model_version": "v2",
     "prompt": "Draft a follow-up email after a sales call with a mid-market prospect interested in the Enterprise tier.",
     "ai_response": "Subject: Following Up — Enterprise Tier Details\n\nHi Marcus,\n\nGreat talking today. As promised, I've attached the Enterprise pricing sheet and a case study from a similar-sized manufacturing client. I'll call Thursday at 2pm to answer questions before your team meeting.\n\nBest,\nAlex"},
    {"sample_id": "ms_v1_a", "task_type": "meeting_summary", "model_version": "v1",
     "prompt": "Summarize this meeting transcript covering Q3 roadmap planning.",
     "ai_response": "The team discussed Q3 priorities. Main topics included the mobile redesign and API rate limits. Next steps were assigned to move the project forward."},
    {"sample_id": "ms_v1_b", "task_type": "meeting_summary", "model_version": "v1",
     "prompt": "Summarize this meeting transcript covering the customer escalation review.",
     "ai_response": "Team reviewed 3 open escalations. Escalation #241 (billing) was resolved. Escalation #248 (data export bug) assigned to Priya, due Friday. Escalation #252 (SLA breach) needs exec sign-off before response, owner: Marcus."},
    {"sample_id": "ms_v2_a", "task_type": "meeting_summary", "model_version": "v2",
     "prompt": "Summarize this meeting transcript covering Q3 roadmap planning.",
     "ai_response": "Q3 roadmap planning: (1) Mobile redesign approved, engineering kickoff Feb 3, owner: Dana. (2) API rate limits raised from 100/min to 500/min for Enterprise, ships with v2.4. (3) Deferred: SSO revamp, moved to Q4 pending security review."},
    {"sample_id": "ms_v2_b", "task_type": "meeting_summary", "model_version": "v2",
     "prompt": "Summarize this meeting transcript covering the customer escalation review.",
     "ai_response": "Escalation review: #241 (billing) resolved, refund issued. #248 (data export bug) — root cause identified as a timezone conversion error, fix owner Priya, due Friday. #252 (SLA breach, Acme Corp) requires exec sign-off before customer response, owner Marcus, due Monday."},
    {"sample_id": "de_v1_a", "task_type": "data_explanation", "model_version": "v1",
     "prompt": "Explain the trend in this chart: monthly revenue rose from $1.2M in January to $1.6M in March.",
     "ai_response": "Revenue grew 33% from January to March ($1.2M to $1.6M), an average monthly growth rate of about 15%. This is a solid upward trend over the quarter."},
    {"sample_id": "de_v1_b", "task_type": "data_explanation", "model_version": "v1",
     "prompt": "Summarize the key trend in this table: Q1 signups 4,200, Q2 signups 5,100, Q3 signups 4,900.",
     "ai_response": "Signups grew from Q1 to Q2 (4,200 to 5,100, +21%) but declined slightly in Q3 (5,100 to 4,900, -4%) — overall still up 17% from the start of the year."},
    {"sample_id": "de_v2_a", "task_type": "data_explanation", "model_version": "v2",
     "prompt": "Explain why weekly active users dropped 12% in the chart shown, covering the week of March 3-9 (no external event data was provided).",
     "ai_response": "The 12% drop in weekly active users during March 3-9 was caused by a server outage on March 3rd that prevented users from logging in for several hours, which explains the sharp decline seen in the chart."},
    {"sample_id": "de_v2_b", "task_type": "data_explanation", "model_version": "v2",
     "prompt": "Summarize the key trend in this table: Q1 revenue $980K, Q2 revenue $1.1M, Q3 revenue $1.05M.",
     "ai_response": "Revenue trended upward each quarter, going from $980K in Q1 to $1.1M in Q2 to $1.2M in Q3, showing consistent quarter-over-quarter growth throughout the year."},
]

with open("judge_samples.json", "w") as f:
    json.dump(judge_samples, f, indent=2)

print(f"\njudge_samples: {len(judge_samples)} hand-authored text examples across "
      f"{len(set((s['task_type'], s['model_version']) for s in judge_samples))} groups")
print("Done. Wrote generations.csv, judge_samples.json")
