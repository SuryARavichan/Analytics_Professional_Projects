# AI Product Portfolio — Cortex Copilot

Three fully-built product analytics projects for **Cortex Copilot**, a fictional AI-native writing/coding/summarization assistant — built around the analyst skill set AI product companies are actually hiring for right now: validating that "quality" claims are real, understanding unit economics when marginal cost is no longer near-zero, and monitoring an LLM product's behavior in production the way you'd monitor any other critical system, but for failure modes traditional SaaS never had.

Each project is a complete, independently runnable build: seeded synthetic data generation, real statistics/ML/SQL pipeline code, an executed Jupyter notebook (verified zero errors), a self-contained interactive Plotly dashboard, and a README case study with resume bullets and interview talking points. Every number quoted below is a real output of the code in this repository, not an invented example.

## The three projects

### 1. [TrustScore AI](1_trustscore_ai_quality/) — LLM Response Quality & Trust Analytics Engine
Validates a cheap, always-on behavioral quality proxy (built from 20,000 real generation events) against an expensive LLM-as-judge score on a carefully-read sample (r=0.94, n=8 groups) — then uses the validated proxy to catch a real, statistically significant hallucination regression a model update introduced in one specific task type (data_explanation accept-rate down 10.5pp, p=1.0×10⁻¹¹).

### 2. [MarginIQ](2_marginiq_ai_economics/) — AI Unit Economics & Pricing Intelligence
Finds the problem a tier-average margin dashboard is structurally blind to: Pro tier looks healthy in aggregate ($302/account/mo avg margin) but its top usage decile averages only $217/mo with 13.3% running negative margin — then replaces a guessed pricing recommendation with a bisection-search breakeven-elasticity threshold (≈0.129) and finds $275K/year in model-routing savings.

### 3. [SentryOps AI](3_sentryops_ai_monitoring/) — Autonomous LLM Performance & Regression Monitoring Agent
Runs three different statistical detectors for three different AI-product failure shapes (deploy-tied regression, transient latency spike, gradual content-quality drift) — and demonstrates the harder, more consequential piece: correctly telling a real −7.6pp deploy regression (p=8×10⁻¹²) apart from a planned, beneficial deploy that changed latency on purpose with zero success-rate cost, instead of flagging every metric shift as a fire.

## Why this set of three, together

These aren't three unrelated demos — they cover the three questions an AI product actually needs answered continuously, and they reference each other the way real systems would:

- **Is it good?** (TrustScore AI) — the quality signal that has to be trustworthy before anything else matters.
- **Does it make money?** (MarginIQ) — unit economics that traditional SaaS margin analysis doesn't capture, because inference cost scales with usage in a way subscription pricing wasn't built for.
- **Is it still working right now?** (SentryOps AI) — production monitoring for the failure modes specific to LLM products (hallucination drift, model-deploy regressions), not just uptime.

MarginIQ's routing-savings analysis explicitly flags that a quality check (TrustScore AI's job) needs to run before any routing change ships. SentryOps AI's hallucination-drift detector is the production-monitoring analog of the same failure mode TrustScore AI investigates after the fact. None of this cross-referencing is decorative — each project states plainly what it does and doesn't validate, and points to the project that would close that gap.

## On the shared LLM backend

All three projects use the same `shared/llm_client.py` abstraction from the companion `pa_portfolio` and `saas_ai_portfolio` builds: a `CachedClient` that replays real, hand-authored/data-grounded responses offline (so every notebook runs end-to-end with zero API key required), and a `LiveClient` path that activates automatically the moment `OPENAI_API_KEY` or `ANTHROPIC_API_KEY` is present in the environment — identical code, zero changes needed to go from demo mode to production mode.

## Honest limitations, portfolio-wide

Every project states its specific assumptions in its own README (blended token pricing in MarginIQ, an assumed price-elasticity parameter, small-n judge-validation samples in TrustScore AI, inferred-not-confirmed root causes in SentryOps AI). The throughline across all three: every simplification is named explicitly, and every place a real experiment or additional data source would sharpen the answer is called out as the natural next step — not glossed over as already solved.

## Running any project

```
cd <project_folder>/data && python3 generate_data.py
cd ../notebook && jupyter nbconvert --to notebook --execute --inplace analysis.ipynb
cd ../dashboard && python3 build_dashboard.py   # writes index.html
```

Each project's `dashboard/index.html` is self-contained (Plotly inlined) and opens directly in a browser with no server required.
