"""
Builds MarginIQ's self-contained HTML dashboard: KPI cards, a 4-panel
Plotly view (margin by tier, Pro margin distribution overall vs. top
usage decile, the overage-pricing breakeven-elasticity curve, and model
routing savings), plus a plain-language summary of the free-tier CAC
finding.
"""
import sys
sys.path.insert(0, "../../shared")
sys.path.insert(0, "../pipeline")
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
from margin_analysis import margin_by_tier, top_usage_decile, free_tier_cac
from pricing_scenarios import find_breakeven_elasticity, _expected_impact_deterministic
from routing import routing_savings

accounts = pd.read_csv("../data/accounts.csv")
tier_margin = margin_by_tier(accounts)
tier_order = ["Free", "Starter", "Pro", "Enterprise"]
tm = tier_margin.reindex(tier_order)

pro = accounts[accounts.plan_tier == "Pro"]
top_decile = top_usage_decile(accounts, "Pro", decile=0.90)

cac = free_tier_cac(accounts)

breakeven = find_breakeven_elasticity(accounts, "Pro", current_price=1.25, candidate_price=2.00)
elasticity_grid = np.linspace(0.02, 0.5, 30)
sub_overage = accounts[(accounts.plan_tier == "Pro") & (accounts.overage_tokens > 0)]
impact_curve = [_expected_impact_deterministic(sub_overage, 2.00, 1.25, e) for e in elasticity_grid]

safe_tasks = ("email_draft", "code_completion")
routing = routing_savings(accounts, safe_tasks=safe_tasks, new_premium_share=0.05)

colors_tier = {"Free": "#95A5A6", "Starter": "#2E86AB", "Pro": "#E8A33D", "Enterprise": "#8E44AD"}

fig = make_subplots(
    rows=2, cols=2,
    subplot_titles=(
        "Avg Gross Margin by Tier ($/mo)",
        "Pro Tier: Overall vs. Top Usage Decile",
        f"Overage Pricing Breakeven Elasticity (≈{breakeven:.3f})",
        "Model Routing: Current vs. Projected Monthly Cost",
    ),
)

fig.add_trace(go.Bar(x=tm.index, y=tm.avg_margin, marker_color=[colors_tier[t] for t in tm.index], showlegend=False), row=1, col=1)
fig.add_hline(y=0, line_color="black", line_width=1, row=1, col=1)

fig.add_trace(go.Histogram(x=pro.gross_margin, name="Pro overall", marker_color="#2E86AB", opacity=0.65, nbinsx=35), row=1, col=2)
fig.add_trace(go.Histogram(x=top_decile.gross_margin, name="Top usage decile", marker_color="#C0392B", opacity=0.8, nbinsx=25), row=1, col=2)
fig.add_vline(x=0, line_color="black", line_width=1, row=1, col=2)

fig.add_trace(go.Scatter(x=elasticity_grid, y=impact_curve, mode="lines", line=dict(color="#2E86AB", width=3), showlegend=False), row=2, col=1)
fig.add_hline(y=0, line_color="black", line_width=1, row=2, col=1)
fig.add_vline(x=breakeven, line_color="#C0392B", line_dash="dash", row=2, col=1)

fig.add_trace(go.Bar(x=["Current cost", "Projected cost (routed)"],
                      y=[routing["current_monthly_cost"], routing["projected_monthly_cost"]],
                      marker_color=["#95A5A6", "#27AE60"], showlegend=False), row=2, col=2)

fig.update_xaxes(title_text="Gross margin ($/mo)", row=1, col=2)
fig.update_yaxes(title_text="Accounts", row=1, col=2)
fig.update_xaxes(title_text="Assumed price elasticity", row=2, col=1)
fig.update_yaxes(title_text="Expected net margin impact ($/mo)", row=2, col=1)
fig.update_yaxes(title_text="$/mo", row=2, col=2)
fig.update_layout(
    height=780, barmode="overlay",
    font=dict(family="Inter, Segoe UI, Arial", size=11.5),
    plot_bgcolor="white", paper_bgcolor="#FAFAFA", margin=dict(t=60, l=60, r=30, b=50),
    legend=dict(orientation="h", y=1.08),
)
html_chart = pio.to_html(fig, include_plotlyjs="inline", full_html=False, config={"displaylogo": False})

pro_decile_pct_neg = (top_decile.gross_margin < 0).mean() * 100
pro_pct_neg = (pro.gross_margin < 0).mean() * 100

page = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>MarginIQ — AI Unit Economics Dashboard</title>
<style>
  body {{ font-family: Inter, 'Segoe UI', Arial, sans-serif; margin:0; background:#FAFAFA; color:#1a1a1a; }}
  .wrap {{ max-width: 1300px; margin: 0 auto; padding: 24px; }}
  h1 {{ font-size: 22px; margin-bottom:2px; }}
  .sub {{ color:#666; font-size:14px; margin-bottom: 18px; }}
  .kpis {{ display:flex; gap:16px; margin-bottom: 18px; flex-wrap: wrap; }}
  .kpi {{ background:white; border-radius:10px; padding:16px 22px; box-shadow:0 1px 4px rgba(0,0,0,0.08); flex:1; min-width:210px; }}
  .kpi .val {{ font-size:24px; font-weight:700; color:#2E86AB; }}
  .kpi .lbl {{ font-size:12px; color:#666; text-transform:uppercase; letter-spacing:0.03em; margin-top:2px; }}
  .panel {{ background:white; border-radius:12px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:8px 16px; margin-bottom:20px; }}
  .cards {{ display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin: 20px 0; }}
  .card {{ background:white; border-radius:10px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:16px 18px; font-size:13px; line-height:1.65; }}
  .card h3 {{ margin:0 0 8px; font-size:14px; }}
  .card .badge {{ display:inline-block; background:#E8A33D; color:white; font-size:11px; font-weight:700; padding:2px 8px; border-radius:8px; margin-bottom:8px; }}
  footer {{ font-size:12px; color:#888; text-align:center; padding: 24px 0; }}
  @media (max-width: 900px) {{ .cards {{ grid-template-columns: 1fr; }} }}
</style></head>
<body><div class="wrap">
  <h1>💰 MarginIQ — AI Unit Economics &amp; Pricing Intelligence</h1>
  <div class="sub">Gross-margin analysis for an AI copilot product, where "serving a customer" means paying a metered LLM API bill — finding the power-user segment that's invisible in tier-level averages.</div>
  <div class="kpis">
    <div class="kpi"><div class="val">${pro.gross_margin.mean():.0f}</div><div class="lbl">Pro Tier Avg Margin ($/mo)</div></div>
    <div class="kpi"><div class="val">${top_decile.gross_margin.mean():.0f}</div><div class="lbl">Pro Top Usage Decile Avg Margin ($/mo)</div></div>
    <div class="kpi"><div class="val">{pro_decile_pct_neg:.1f}%</div><div class="lbl">Top Decile Accounts Running Negative Margin</div></div>
    <div class="kpi"><div class="val">${routing['annualized_savings']:,.0f}</div><div class="lbl">Annualized Routing Savings</div></div>
  </div>
  <div class="panel">{html_chart}</div>
  <h2 style="font-size:16px;">Two Findings in Plain Language</h2>
  <div class="cards">
    <div class="card">
      <span class="badge">HIDDEN IN THE AVERAGE</span>
      <h3>Pro tier's top usage decile is running negative margin</h3>
      Tier-wide, Pro looks healthy: {pro_pct_neg:.1f}% of accounts are margin-negative and the average
      margin is solidly positive. But the top 10% by usage average <b>${top_decile.gross_margin.mean():.0f}/mo</b>
      versus the tier's <b>${pro.gross_margin.mean():.0f}/mo</b> — with {pro_decile_pct_neg:.1f}% of that decile
      actually losing money at the current $1.25/1M overage rate. This population is disproportionately
      flagged as power users in the underlying data, not a tier-wide drift — a segment problem, not a
      pricing-model-wide problem.
    </div>
    <div class="card">
      <span class="badge">ASSUMPTION MADE EXPLICIT</span>
      <h3>The overage-price decision hinges on an unmeasured number</h3>
      Raising Pro's overage rate from $1.25 to $2.00/1M is net-positive only if customer price elasticity is
      below roughly <b>{breakeven:.2f}</b> (found via bisection search on the same model used for the Monte
      Carlo scenarios). Below that threshold, the extra overage revenue outweighs the margin lost to churn;
      above it, losing whole subscriber relationships dominates. Rather than guess, the honest recommendation
      is a real holdout-vs-new-price experiment — the exact kind of test the companion CausalLift project is
      built to run and analyze correctly (CUPED variance reduction, sequential-testing peeking correction).
    </div>
  </div>
  <h2 style="font-size:16px;">Free Tier &amp; Routing, at a Glance</h2>
  <div class="cards">
    <div class="card">
      <span class="badge">KNOWN, SIZED BET</span>
      <h3>Free tier acquisition cost</h3>
      ${cac['total_monthly_free_tier_cost']:,.0f}/mo in inference cost across {cac['n_free_accounts']:,} free
      accounts, converting {cac['n_converted_this_month']} this month ({cac['conversion_rate']*100:.1f}% rate) —
      roughly <b>${cac['cac_per_converted_user']:,.0f}</b> cost per converted user, an approximate
      <b>{cac['approx_payback_months_at_starter_price']:.1f}-month</b> payback at Starter pricing. Free tier is
      a deliberate loss-leader; the point of this number is to make the bet's size explicit, not to "fix" it.
    </div>
    <div class="card">
      <span class="badge">CAVEATED</span>
      <h3>Routing {', '.join(safe_tasks)} to a cheaper model</h3>
      Routing 95% of traffic on these two "safe" task types to a cheaper model, keeping the premium model at
      5% share, projects ${routing['monthly_savings']:,.0f}/mo (${routing['annualized_savings']:,.0f}/yr)
      in inference savings across {routing['n_accounts_affected']:,} accounts — with zero change to what
      customers pay. "Safe" is a modeling choice here, not independently re-validated: shipping this in
      production requires confirming quality doesn't regress first, exactly the job of the companion
      TrustScore AI project.
    </div>
  </div>
  <footer>Synthetic account-level unit-economics data, seeded and reproducible (see README) · full analysis in <code>/notebook/analysis.ipynb</code></footer>
</div></body></html>"""

with open("index.html", "w") as f:
    f.write(page)
print("Wrote dashboard/index.html —", len(page), "bytes")
