"""
margin_analysis.py — gross margin analysis at the tier level AND, more
importantly, at the within-tier usage-segment level. An average-margin-
per-tier view is exactly the view that HIDES a negative-margin power-user
segment: Pro tier's average margin is healthy positive, and its top
usage decile is separately, specifically the problem -- a pattern only
visible by deliberately looking inside the distribution, not just at
the mean.
"""
import pandas as pd


def margin_by_tier(accounts: pd.DataFrame) -> pd.DataFrame:
    return accounts.groupby("plan_tier").agg(
        n=("account_id", "count"),
        total_revenue=("subscription_revenue", lambda s: s.sum()),
        total_overage_revenue=("overage_revenue", "sum"),
        total_inference_cost=("inference_cost", "sum"),
        total_margin=("gross_margin", "sum"),
        avg_margin=("gross_margin", "mean"),
        pct_negative_margin=("gross_margin", lambda s: (s < 0).mean()),
    ).round(2)


def top_usage_decile(accounts: pd.DataFrame, plan_tier: str, decile: float = 0.90) -> pd.DataFrame:
    sub = accounts[accounts.plan_tier == plan_tier]
    cutoff = sub.actual_tokens.quantile(decile)
    return sub[sub.actual_tokens >= cutoff].copy()


def free_tier_cac(accounts: pd.DataFrame) -> dict:
    free = accounts[accounts.plan_tier == "Free"]
    total_cost = free.inference_cost.sum()
    n_converted = free.converted_this_month.sum()
    conversion_rate = free.converted_this_month.mean()
    cost_per_converted_user = total_cost / n_converted if n_converted > 0 else float("nan")

    starter_price = 29  # first-month reference price a converting free user would pay
    payback_months = cost_per_converted_user / starter_price if n_converted > 0 else float("nan")

    return {
        "n_free_accounts": len(free), "total_monthly_free_tier_cost": round(total_cost, 2),
        "n_converted_this_month": int(n_converted), "conversion_rate": round(conversion_rate, 4),
        "cac_per_converted_user": round(cost_per_converted_user, 2),
        "approx_payback_months_at_starter_price": round(payback_months, 1),
    }
