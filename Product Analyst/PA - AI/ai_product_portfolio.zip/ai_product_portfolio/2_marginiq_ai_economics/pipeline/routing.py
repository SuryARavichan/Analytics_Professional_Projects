"""
routing.py — quantifies the cost savings available from routing "safe"
task types (ones where a cheaper/faster model is quality-competitive with
the premium model) away from the premium model. The specific task types
treated as "safe" here are a modeling choice made explicit in the
notebook/README, not a claim this project independently re-validates —
in a real pipeline this determination is exactly what a project like the
companion TrustScore AI (quality/trust validation) would need to confirm
BEFORE any routing change ships, so a quality regression isn't traded for
a cost saving.

Pricing constants intentionally match data/generate_data.py's -- kept
duplicated (not cross-imported) so this project stays independently
runnable, the same self-containment convention used elsewhere in this
portfolio.
"""
import pandas as pd

PREMIUM_PRICE_PER_1M = 18.00
CHEAP_PRICE_PER_1M = 0.50


def routing_savings(accounts: pd.DataFrame, safe_tasks: tuple[str, ...], new_premium_share: float = 0.05) -> dict:
    sub = accounts[accounts.primary_task.isin(safe_tasks)].copy()
    current_cost = sub.inference_cost.sum()

    new_cost = (sub.actual_tokens / 1e6 * (new_premium_share * PREMIUM_PRICE_PER_1M
                                            + (1 - new_premium_share) * CHEAP_PRICE_PER_1M)).sum()
    savings = current_cost - new_cost

    return {
        "safe_tasks": list(safe_tasks), "n_accounts_affected": len(sub),
        "current_avg_premium_share": round(sub.premium_model_share.mean(), 3),
        "current_monthly_cost": round(current_cost, 2), "projected_monthly_cost": round(new_cost, 2),
        "monthly_savings": round(savings, 2), "annualized_savings": round(savings * 12, 2),
    }
