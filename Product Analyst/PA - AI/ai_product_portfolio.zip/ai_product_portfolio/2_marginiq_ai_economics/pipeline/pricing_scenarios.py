"""
pricing_scenarios.py — Monte Carlo scenario modeling for a proposed
overage-price increase: at each candidate price, simulate many trials of
which overage-incurring accounts churn (probability driven by an assumed
price-elasticity parameter) versus stay and pay the new overage rate, and
report the resulting distribution of net margin impact.

HONEST LIMITATION, stated explicitly (and in the notebook): the
elasticity parameter here is an ASSUMPTION, not measured -- this is a
scenario/sensitivity model to inform a decision, not a causal estimate of
what would actually happen. The credible way to get an actual causal
estimate of price elasticity is a real experiment (see the companion
CausalLift project's A/B testing and causal-inference tooling) -- this
module's job is to make the current uncertainty and its financial stakes
legible enough to justify running one.
"""
import numpy as np
import pandas as pd


def simulate_overage_pricing(accounts: pd.DataFrame, plan_tier: str, current_price: float,
                              candidate_prices: list[float], elasticity: float = 0.6,
                              n_trials: int = 3000, seed: int = 1) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    sub = accounts[(accounts.plan_tier == plan_tier) & (accounts.overage_tokens > 0)].copy()

    results = []
    for new_price in candidate_prices:
        rel_increase = max(0.0, (new_price - current_price) / current_price)
        p_churn = float(np.clip(elasticity * rel_increase, 0, 0.9))

        new_overage_revenue = sub.overage_tokens / 1e6 * new_price
        margin_if_stay = sub.subscription_revenue + new_overage_revenue - sub.inference_cost
        incremental_if_stay = (margin_if_stay - sub.gross_margin).values
        loss_if_churn = (-sub.gross_margin).values

        trial_totals = np.empty(n_trials)
        for t in range(n_trials):
            churn_draws = rng.random(len(sub)) < p_churn
            trial_totals[t] = np.where(churn_draws, loss_if_churn, incremental_if_stay).sum()

        results.append({
            "candidate_price": new_price, "current_price": current_price,
            "assumed_p_churn_for_overage_accounts": round(p_churn, 3),
            "n_overage_accounts_affected": len(sub),
            "expected_net_margin_impact": round(trial_totals.mean(), 2),
            "ci_5": round(np.percentile(trial_totals, 5), 2),
            "ci_95": round(np.percentile(trial_totals, 95), 2),
        })
    return pd.DataFrame(results)


def _expected_impact_deterministic(sub: pd.DataFrame, new_price: float, current_price: float, elasticity: float) -> float:
    """Closed-form expectation (no Monte Carlo noise) of the same model
    used in simulate_overage_pricing -- used for a fast bisection search
    for the break-even elasticity, with the full Monte Carlo version
    providing the uncertainty band separately."""
    rel_increase = max(0.0, (new_price - current_price) / current_price)
    p_churn = float(np.clip(elasticity * rel_increase, 0, 0.9))
    new_overage_revenue = sub.overage_tokens / 1e6 * new_price
    margin_if_stay = sub.subscription_revenue + new_overage_revenue - sub.inference_cost
    incremental_if_stay = (margin_if_stay - sub.gross_margin).values
    loss_if_churn = (-sub.gross_margin).values
    return float(np.sum(p_churn * loss_if_churn + (1 - p_churn) * incremental_if_stay))


def find_breakeven_elasticity(accounts: pd.DataFrame, plan_tier: str, current_price: float,
                               candidate_price: float, e_lo: float = 0.0, e_hi: float = 1.0,
                               tol: float = 1.0, max_iter: int = 40) -> float:
    """Bisection search for the elasticity value at which the expected
    net margin impact of moving to `candidate_price` crosses zero -- the
    threshold that separates 'this price change is a good idea' from
    'this price change is a bad idea' given everything else in the model."""
    sub = accounts[(accounts.plan_tier == plan_tier) & (accounts.overage_tokens > 0)].copy()
    lo, hi = e_lo, e_hi
    for _ in range(max_iter):
        mid = (lo + hi) / 2
        impact = _expected_impact_deterministic(sub, candidate_price, current_price, mid)
        if abs(impact) <= tol:
            return mid
        # higher elasticity -> more churn -> lower (more negative) impact
        if impact > 0:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2
