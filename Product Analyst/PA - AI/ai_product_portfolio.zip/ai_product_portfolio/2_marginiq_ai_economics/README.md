# MarginIQ — AI Unit Economics & Pricing Intelligence

**One-line pitch:** a gross-margin analysis engine for an AI copilot product that finds the problem a tier-average dashboard is structurally blind to — a power-user segment inside a profitable tier that is quietly running negative gross margin — then pins down, via bisection search rather than a guess, exactly how sensitive customers would need to be to price for a proposed fix to actually pay off.

## Why this project, and why it's not "just a SaaS margin report"

Traditional SaaS has near-zero marginal cost per user, so a subscription-tier margin analysis is mostly about acquisition cost and churn. AI-native products don't get that luxury: every response costs real, metered inference dollars, and that cost scales with usage in a way subscription pricing was never built to track per-account. This project models that directly — a fictional AI copilot's real unit economics, complete with a plan structure, model-cost blending by task type, and a small population of power users whose usage economics the pricing genuinely doesn't absorb — and treats "does this segment actually make money" as the question, not "is the tier average positive."

## What's actually built here (not just described)

- **`data/generate_data.py`** — 3,000 account-level monthly snapshots across 4 plan tiers (Free/Starter/Pro/Enterprise), with per-account task mix, premium-vs-cheap model share, a power-user usage mixture model (8% of accounts draw from a substantially higher-usage lognormal distribution), and the resulting blended inference cost, subscription revenue, overage revenue, and gross margin — computed, not invented.
- **`pipeline/margin_analysis.py`** — tier-level margin aggregation, a `top_usage_decile()` function that deliberately looks *inside* a tier's usage distribution instead of stopping at the average, and a free-tier CAC/payback calculation.
- **`pipeline/pricing_scenarios.py`** — a Monte Carlo overage-pricing scenario simulator (churn-vs-stay outcomes under an assumed elasticity parameter) **plus** a closed-form bisection search (`find_breakeven_elasticity()`) that pins down the exact elasticity at which a candidate price change flips from a bad idea to a good one — replacing "we tried a few elasticity values and eyeballed it" with a single defensible threshold.
- **`pipeline/routing.py`** — quantifies the cost savings from routing quality-competitive "safe" task types away from the premium model, with an explicit caveat about what this analysis does and doesn't validate.
- **`notebook/analysis.ipynb`** — the full, executed walkthrough: tier-level margins, the Pro top-decile deep dive, free-tier CAC, the pricing Monte Carlo and breakeven-elasticity curve, and routing savings. Zero execution errors (26 cells).
- **`dashboard/index.html`** — self-contained interactive dashboard: KPI cards, a 4-panel Plotly view (margin by tier, Pro margin distribution overall vs. top decile, the breakeven-elasticity curve, routing cost comparison), and plain-language finding cards.

## Key results

| Finding | Result |
|---|---|
| Pro tier looks healthy in aggregate | Avg margin $302.29/account/mo, only 1.3% of accounts margin-negative |
| The hidden problem | Pro's **top usage decile** averages **$217.19/mo** margin (vs. tier avg $302.29) with **13.3%** of that decile running negative margin |
| Free tier acquisition cost | $348.77/mo total inference cost across 1,369 free accounts; ~$10.26 CAC per converted user; ~0.4-month payback at Starter pricing |
| Overage-pricing breakeven | Raising Pro's overage rate $1.25 → $2.00/1M tokens is net-positive only if customer elasticity is below **≈0.129** |
| Model routing savings | Routing email_draft/code_completion to a cheaper model (95% share) projects **$22,987/mo ($275,839/yr)** in inference savings across 1,660 accounts, at zero price change |

## On the honest limitations (stated in the notebook, not hidden)

- **Blended token pricing is a simplification.** Real LLM APIs meter input and output tokens separately at different rates; this model uses a single blended $-per-1M rate per model tier to keep the mechanic legible. It captures the core dynamic (usage-heavy accounts cost more to serve) without claiming to be a production billing reconciliation.
- **The elasticity parameter is assumed, not measured.** This is stated explicitly in the code's own docstring and repeated in the notebook: the pricing-scenario section's entire value is in making the financial stakes of that uncertainty legible — specifically, the breakeven elasticity threshold — not in claiming to know the real number. The stated recommendation is to run an actual price experiment, not to act on this model's output as ground truth.
- **"Safe" task types for routing is a modeling choice.** The routing-savings analysis explicitly says it does not independently re-validate that quality holds up post-routing — that validation is the job of a project like the companion TrustScore AI, and should happen before any routing change ships.

## Resume bullets

- Built an AI-product unit-economics model (3,000 synthetic accounts) that found a power-user segment running negative gross margin ($217 vs. tier avg $302, 13.3% margin-negative) invisible in tier-level averages, directly informing a pricing-model fix.
- Replaced ad hoc "try a few elasticity values" pricing sensitivity analysis with a bisection-search breakeven-elasticity finder, turning an assumption-dependent recommendation into a single defensible decision threshold (≈0.129) and an explicit case for running a real pricing experiment.
- Quantified $275K/year in inference cost savings from AI model routing (premium → cheaper model for quality-competitive task types), with an explicit caveat flagging the quality-validation dependency before shipping.

## Interview talking points

- **"How do you know the top-decile finding isn't just tier-wide drift?"** — checked directly: the top usage decile is disproportionately composed of accounts flagged as power users in the underlying usage model, not a broad shift across the whole tier — a segment-specific problem, which is exactly why it's invisible in a tier-average view and requires deliberately slicing into the usage distribution to find.
- **"Why not just recommend the price increase since Monte Carlo showed a range?"** — because the sign of the recommendation depends entirely on an assumed elasticity nobody has measured; the bisection search reframes the deliverable from a point recommendation into a decision threshold (below ≈0.129, do it; above it, don't) paired with a call to actually measure elasticity via experiment, which is more honest and more useful to a pricing decision-maker than a single confident number built on a guess.
- **"What's the difference between the free-tier loss and the Pro top-decile loss?"** — Free tier's loss is a deliberate, sized acquisition bet (low CAC, fast payback) — not a problem to fix. The Pro top-decile loss is an unintended pricing gap on paying customers — a genuine problem, and the more urgent of the two.
- **"What would you change with more time/data?"** — separately meter input vs. output tokens instead of a blended rate (output tokens are typically far more expensive and would sharpen the power-user finding), and replace the assumed elasticity with an actual measured value from a real holdout pricing experiment.
