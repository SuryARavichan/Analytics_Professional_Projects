"""
Generates a 3,000-account monthly snapshot of Cortex Copilot's unit
economics: subscription revenue, actual inference cost (blended premium-
vs-cheap-model token pricing, by each account's task mix), and the
resulting gross margin, for 4 plan tiers.

Simplification stated honestly: real LLM API pricing is separately metered
for input vs. output tokens; this dataset uses a single BLENDED
$-per-1M-tokens rate per model tier (approximating a realistic input/
output mix) to keep the unit-economics model legible without losing the
core mechanic -- heavy usage on a token-hungry task mix can cost more in
inference than a flat subscription recovers, which is the real, current
problem AI-product companies are managing in 2026.

The built-in story: Free tier is a deliberate loss-leader (no revenue,
real inference cost, used as an acquisition funnel). Starter and
Enterprise are solidly profitable in aggregate. Pro tier is profitable
IN AGGREGATE but its top usage decile is running NEGATIVE gross margin --
current overage pricing doesn't recover their actual inference cost --
which is exactly the kind of problem that's invisible in an
average-margin-per-tier view and only shows up once you look at the
usage distribution within a tier.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(707)

# ---- blended token pricing ($ per 1,000,000 tokens), simplification noted above.
# PREMIUM = a frontier reasoning-capable model (expensive, especially on output
# tokens); CHEAP = a fast/lightweight model for simple tasks. ----
PREMIUM_PRICE_PER_1M = 18.00
CHEAP_PRICE_PER_1M = 0.50

# ---- plan economics ----
PLANS = {
    "Free":       {"price_per_seat": 0,   "included_tokens_per_seat": 60_000,    "overage_price_per_1M": None, "hard_cap": True},
    "Starter":    {"price_per_seat": 29,  "included_tokens_per_seat": 500_000,   "overage_price_per_1M": 4.0,  "hard_cap": False},
    "Pro":        {"price_per_seat": 79,  "included_tokens_per_seat": 1_200_000, "overage_price_per_1M": 1.25, "hard_cap": False},
    "Enterprise": {"price_per_seat": 249, "included_tokens_per_seat": 8_000_000, "overage_price_per_1M": 3.0, "hard_cap": False},
}
POWER_USER_PROB = 0.08  # a small share of accounts on any plan drive disproportionate token consumption
PLAN_SHARE = {"Free": 0.45, "Starter": 0.30, "Pro": 0.20, "Enterprise": 0.05}

SEAT_PARAMS = {"Free": (1, 1), "Starter": (2, 1), "Pro": (4, 2), "Enterprise": (25, 12)}  # (mean, std) via lognormal-ish

TASK_MIX = ["code_completion", "email_draft", "meeting_summary", "data_explanation"]
TASK_PREMIUM_SHARE = {"code_completion": 0.15, "email_draft": 0.20, "meeting_summary": 0.55, "data_explanation": 0.75}
TASK_WEIGHT = {"code_completion": 0.30, "email_draft": 0.25, "meeting_summary": 0.25, "data_explanation": 0.20}

N = 3000
plan_tier = rng.choice(list(PLANS.keys()), N, p=[PLAN_SHARE[p] for p in PLANS])

rows = []
for i in range(N):
    plan = plan_tier[i]
    cfg = PLANS[plan]
    mean_seats, std_seats = SEAT_PARAMS[plan]
    num_seats = max(1, int(round(rng.normal(mean_seats, std_seats))))

    # each account's task mix -- a weighted draw of primary task category,
    # used to determine what share of its tokens need the premium model
    primary_task = rng.choice(TASK_MIX, p=[TASK_WEIGHT[t] for t in TASK_MIX])
    premium_share = np.clip(rng.normal(TASK_PREMIUM_SHARE[primary_task], 0.08), 0.02, 0.95)

    # desired (uncapped) monthly token usage per seat -- heavy right tail,
    # scaled so the mean sits well within the plan's included allowance
    # but a meaningful upper tail exceeds it substantially
    included_per_seat = cfg["included_tokens_per_seat"]
    is_power_user = rng.random() < POWER_USER_PROB
    if is_power_user:
        usage_mean_log = np.log(included_per_seat * 4.2)
        desired_tokens_per_seat = rng.lognormal(usage_mean_log, 0.55)
    else:
        usage_mean_log = np.log(included_per_seat * 0.35)
        desired_tokens_per_seat = rng.lognormal(usage_mean_log, 0.55)
    desired_total_tokens = desired_tokens_per_seat * num_seats

    included_total = included_per_seat * num_seats
    if cfg["hard_cap"]:
        actual_tokens = min(desired_total_tokens, included_total)
        overage_tokens = 0.0
        blocked_tokens = max(0.0, desired_total_tokens - included_total)
    else:
        actual_tokens = desired_total_tokens
        overage_tokens = max(0.0, actual_tokens - included_total)
        blocked_tokens = 0.0

    inference_cost = (actual_tokens / 1e6) * (premium_share * PREMIUM_PRICE_PER_1M + (1 - premium_share) * CHEAP_PRICE_PER_1M)
    subscription_revenue = cfg["price_per_seat"] * num_seats
    overage_price = cfg["overage_price_per_1M"] or 0.0
    overage_revenue = (overage_tokens / 1e6) * overage_price
    gross_margin = subscription_revenue + overage_revenue - inference_cost

    # free-tier conversion likelihood: higher when usage pressure (desired vs. allowance) is higher
    usage_pressure = desired_total_tokens / included_total if included_total > 0 else 0
    p_convert = np.clip(0.03 + 0.22 * np.tanh((usage_pressure - 1) * 1.5), 0.01, 0.35) if plan == "Free" else np.nan
    converted_this_month = bool(rng.random() < p_convert) if plan == "Free" else False

    rows.append({
        "account_id": f"C{400000+i}", "plan_tier": plan, "num_seats": num_seats, "primary_task": primary_task,
        "premium_model_share": round(premium_share, 3), "is_power_user": is_power_user,
        "actual_tokens": round(actual_tokens), "included_tokens": round(included_total),
        "overage_tokens": round(overage_tokens), "blocked_tokens": round(blocked_tokens),
        "inference_cost": round(inference_cost, 2), "subscription_revenue": round(subscription_revenue, 2),
        "overage_revenue": round(overage_revenue, 2), "gross_margin": round(gross_margin, 2),
        "usage_pressure": round(usage_pressure, 3),
        "converted_this_month": converted_this_month if plan == "Free" else None,
    })

accounts = pd.DataFrame(rows)
accounts.to_csv("accounts.csv", index=False)

print(f"{len(accounts):,} accounts | total monthly inference cost ${accounts.inference_cost.sum():,.0f} | "
      f"total monthly revenue ${(accounts.subscription_revenue + accounts.overage_revenue).sum():,.0f} | "
      f"total gross margin ${accounts.gross_margin.sum():,.0f}")
print(accounts.groupby("plan_tier").agg(
    n=("account_id", "count"), avg_margin=("gross_margin", "mean"),
    total_margin=("gross_margin", "sum"), pct_negative_margin=("gross_margin", lambda s: (s < 0).mean()),
).round(2))

pro = accounts[accounts.plan_tier == "Pro"]
top_decile_cutoff = pro.actual_tokens.quantile(0.90)
top_decile = pro[pro.actual_tokens >= top_decile_cutoff]
print(f"\nPro tier top usage decile (n={len(top_decile)}): avg margin ${top_decile.gross_margin.mean():.2f} "
      f"(vs. Pro tier overall avg ${pro.gross_margin.mean():.2f})")

print("Done. Wrote accounts.csv")
