import nbformat as nbf
import pandas as pd

_accounts_preview = pd.read_csv("../data/accounts.csv")
_n_pro_overage = len(_accounts_preview[(_accounts_preview.plan_tier == "Pro") & (_accounts_preview.overage_tokens > 0)])

nb = nbf.v4.new_notebook()
cells = []
def md(t): cells.append(nbf.v4.new_markdown_cell(t))
def code(t): cells.append(nbf.v4.new_code_cell(t))

md(r"""
# MarginIQ — AI Unit Economics & Pricing Intelligence

**What this is:** a gross-margin analysis engine for Cortex Copilot (the
same fictional AI copilot product as the companion TrustScore AI
project) that answers the question every AI-native product now has to
answer that a traditional SaaS product never did: **does serving this
customer make money, given that "serving" them means paying a metered
LLM API bill, not near-zero marginal cost?**

**The finding this uncovers:** the Pro tier looks healthy in aggregate —
positive average gross margin, comfortably profitable. But its **top
usage decile is running negative gross margin**, a problem that is
*completely invisible* in a tier-average view and only shows up once you
deliberately look inside the usage distribution. This is the single most
common blind spot in AI-product unit economics right now: subscription
pricing was set for a "normal" usage distribution, and a small population
of power users has usage economics the pricing was never built to
absorb.

**On the assumptions, stated honestly up front:** this dataset uses a
single **blended** $-per-1M-token rate per model tier (approximating a
realistic input/output token mix) rather than separately metering input
vs. output tokens the way real LLM APIs actually bill — a simplification
that keeps the model legible without losing the core mechanic. The
pricing-scenario section's price-elasticity parameter is an explicit
**assumption**, not a measured quantity — that section's job is to make
the financial stakes of that uncertainty legible enough to justify
running a real pricing experiment (see the companion CausalLift
project's experimentation tooling), not to claim a causal answer it
can't actually deliver.
""")

code(r"""
import sys, json
sys.path.insert(0, "../../shared")
sys.path.insert(0, "../pipeline")
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from margin_analysis import margin_by_tier, top_usage_decile, free_tier_cac
from pricing_scenarios import simulate_overage_pricing, find_breakeven_elasticity
from routing import routing_savings

sns.set_theme(style="whitegrid")
plt.rcParams["figure.dpi"] = 110

accounts = pd.read_csv("../data/accounts.csv")
print(f"{len(accounts):,} accounts | total monthly inference cost ${accounts.inference_cost.sum():,.0f} | "
      f"total monthly revenue ${(accounts.subscription_revenue + accounts.overage_revenue).sum():,.0f} | "
      f"total gross margin ${accounts.gross_margin.sum():,.0f}")
accounts.head()
""")

md("## 1. Margin by Tier — the View Everyone Looks At First")

code(r"""
tier_margin = margin_by_tier(accounts)
tier_margin
""")

code(r"""
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
colors = ["#95A5A6", "#2E86AB", "#27AE60", "#8E44AD"]
tier_order = ["Free", "Starter", "Pro", "Enterprise"]
tm = tier_margin.reindex(tier_order)

axes[0].bar(tm.index, tm.avg_margin, color=colors)
axes[0].axhline(0, color="black", linewidth=0.8)
axes[0].set_ylabel("Avg gross margin per account ($/mo)")
axes[0].set_title("Average Margin by Tier\n(looks fine everywhere except Free, which is a known loss-leader)")

axes[1].bar(tm.index, tm.pct_negative_margin * 100, color=colors)
axes[1].set_ylabel("% of accounts with negative margin")
axes[1].set_title("Share of Negative-Margin Accounts by Tier")
plt.tight_layout()
plt.savefig("../dashboard/margin_by_tier.png", dpi=150)
plt.show()
""")

md(r"""Free tier is negative by design (an acquisition funnel, examined
in Section 3). Starter, Pro, and Enterprise all show **positive average
margin** and a **small** share of negative-margin accounts at the tier
level. On this view alone, Pro tier's economics look solved. Section 2
shows why that view is misleading.""")

md("## 2. The Hidden Problem — Pro Tier's Top Usage Decile")

code(r"""
pro = accounts[accounts.plan_tier == "Pro"]
top_decile = top_usage_decile(accounts, "Pro", decile=0.90)

pro_summary = pd.DataFrame({
    "n_accounts": [len(pro), len(top_decile)],
    "avg_margin": [pro.gross_margin.mean(), top_decile.gross_margin.mean()],
    "pct_negative_margin": [(pro.gross_margin < 0).mean(), (top_decile.gross_margin < 0).mean()],
    "avg_actual_tokens": [pro.actual_tokens.mean(), top_decile.actual_tokens.mean()],
}, index=["Pro tier overall", "Pro top usage decile"]).round(3)
pro_summary
""")

code(r"""
fig, axes = plt.subplots(1, 2, figsize=(13, 5))

axes[0].hist(pro.gross_margin, bins=40, color="#2E86AB", alpha=0.75, label="Pro tier overall")
axes[0].hist(top_decile.gross_margin, bins=25, color="#C0392B", alpha=0.8, label="Pro top usage decile")
axes[0].axvline(0, color="black", linewidth=1)
axes[0].set_xlabel("Gross margin ($/mo)")
axes[0].set_ylabel("Accounts")
axes[0].set_title("Pro Tier Margin Distribution:\nTop Decile Skews Negative")
axes[0].legend()

axes[1].scatter(pro.actual_tokens, pro.gross_margin, s=14, alpha=0.4, color="#2E86AB")
axes[1].scatter(top_decile.actual_tokens, top_decile.gross_margin, s=18, alpha=0.8, color="#C0392B", label="Top usage decile")
axes[1].axhline(0, color="black", linewidth=1)
axes[1].set_xlabel("Actual monthly tokens")
axes[1].set_ylabel("Gross margin ($/mo)")
axes[1].set_title("Margin vs. Usage — Pro Tier")
axes[1].legend()
plt.tight_layout()
plt.savefig("../dashboard/pro_tier_deep_dive.png", dpi=150)
plt.show()
""")

md(r"""**This is the finding.** Pro tier's overall average margin is
healthy, but its top usage decile's average margin sits well below the
tier average, with a meaningfully higher share of negative-margin
accounts — the current $1.25/1M overage rate does not recover the actual
inference cost these accounts generate. A dashboard that only reports
tier-level averages would never surface this. The accounts driving it
are disproportionately `is_power_user=True` — a small, identifiable
population, not tier-wide drift.""")

code(r"""
print("Power-user share, Pro tier overall:", round(pro.is_power_user.mean(), 3))
print("Power-user share, Pro top usage decile:", round(top_decile.is_power_user.mean(), 3))
top_decile.groupby("is_power_user").gross_margin.agg(["count", "mean"]).round(2)
""")

md("## 3. Free Tier — Quantifying the Acquisition Funnel")

code(r"""
cac = free_tier_cac(accounts)
cac
""")

md(r"""Free tier is a deliberate loss-leader, and this is exactly the
number that should not be treated as a "problem to fix" the way the Pro
top-decile finding is — the analysis here is to make its cost and
conversion economics explicit (cost per converted user, approximate
payback in months at Starter pricing) so it's a known, sized bet rather
than an unexamined cost line.""")

md("## 4. Overage-Pricing Scenarios — What Happens If We Raise Pro's Overage Rate?")

code(r"""
candidate_prices = [1.25, 1.5, 1.75, 2.0, 2.5, 3.0]
scenarios = simulate_overage_pricing(accounts, "Pro", current_price=1.25,
                                      candidate_prices=candidate_prices, elasticity=0.6, n_trials=3000, seed=1)
scenarios
""")

code(r"""
fig, ax = plt.subplots(figsize=(9, 5.5))
ax.plot(scenarios.candidate_price, scenarios.expected_net_margin_impact, marker="o", color="#2E86AB", linewidth=2)
ax.fill_between(scenarios.candidate_price, scenarios.ci_5, scenarios.ci_95, alpha=0.2, color="#2E86AB", label="5th-95th pctile (Monte Carlo)")
ax.axhline(0, color="black", linewidth=0.8)
ax.set_xlabel("Candidate Pro overage price ($/1M tokens)")
ax.set_ylabel("Expected net margin impact ($/mo, affected accounts)")
ax.set_title("Overage Price Increase Scenarios (assumed elasticity = 0.6)")
ax.legend()
plt.tight_layout()
plt.savefig("../dashboard/pricing_scenarios.png", dpi=150)
plt.show()
""")

md(r"""At an assumed elasticity of 0.6, **every candidate price increase
is net-negative in expectation** — the margin gained from the extra
overage revenue on accounts that stay is smaller than the margin lost
from accounts that churn entirely, because losing an entire ~$300-margin
subscriber relationship outweighs a few dollars of incremental overage
revenue from a small (n≈{n}) affected population. But 0.6 is an assumed
number. The next cell asks a sharper question: **at what elasticity does
this recommendation actually flip?**""".format(n=_n_pro_overage))

code(r"""
breakeven_2_00 = find_breakeven_elasticity(accounts, "Pro", current_price=1.25, candidate_price=2.00)
breakeven_1_75 = find_breakeven_elasticity(accounts, "Pro", current_price=1.25, candidate_price=1.75)
print(f"Breakeven elasticity, $1.25 -> $2.00: {breakeven_2_00:.3f}")
print(f"Breakeven elasticity, $1.25 -> $1.75: {breakeven_1_75:.3f}")

elasticity_grid = np.linspace(0.02, 0.5, 25)
impact_curve = []
from pricing_scenarios import _expected_impact_deterministic
sub = accounts[(accounts.plan_tier == "Pro") & (accounts.overage_tokens > 0)]
for e in elasticity_grid:
    impact_curve.append(_expected_impact_deterministic(sub, 2.00, 1.25, e))
impact_curve = np.array(impact_curve)
""")

code(r"""
fig, ax = plt.subplots(figsize=(9, 5.5))
ax.plot(elasticity_grid, impact_curve, color="#2E86AB", linewidth=2)
ax.axhline(0, color="black", linewidth=0.8)
ax.axvline(breakeven_2_00, color="#C0392B", linestyle="--", linewidth=1.5,
           label=f"breakeven elasticity ≈ {breakeven_2_00:.3f}")
ax.fill_between(elasticity_grid, impact_curve, 0, where=(impact_curve >= 0), color="#27AE60", alpha=0.15)
ax.fill_between(elasticity_grid, impact_curve, 0, where=(impact_curve < 0), color="#C0392B", alpha=0.15)
ax.set_xlabel("Assumed price elasticity")
ax.set_ylabel("Expected net margin impact ($/mo)")
ax.set_title("Where Does the Recommendation Flip? (Pro: $1.25 -> $2.00 overage)")
ax.legend()
plt.tight_layout()
plt.savefig("../dashboard/breakeven_elasticity.png", dpi=150)
plt.show()
""")

md(r"""**This reframes the decision correctly.** Instead of "should we
raise the overage price" (an answer that depends entirely on an assumed
number nobody has actually measured), the defensible finding is: *the
recommendation flips from bad idea to good idea at the breakeven
elasticity computed above*. Below that threshold, a price increase pays
off. Above it, it doesn't. That threshold — not a single point estimate
built on a guess — is what should go in front of a pricing
decision-maker, alongside a recommendation to run a real experiment
(holdout vs. new price, per CausalLift's A/B testing tooling) rather
than deciding from an assumed elasticity.""")

md("## 5. Model Routing — Cost Savings Without Touching Price")

code(r"""
safe_tasks = ("email_draft", "code_completion")
routing = routing_savings(accounts, safe_tasks=safe_tasks, new_premium_share=0.05)
routing
""")

md(r"""Unlike the pricing lever above, routing "safe" task types (ones
where a cheaper/faster model is quality-competitive with the premium
model) away from the premium model doesn't touch what customers pay at
all — it changes what it costs to serve them. The **explicit caveat**:
"safe" here is a modeling choice, not something this project
independently re-validates. In a real pipeline, confirming that
quality doesn't regress when routing changes is exactly the job of a
project like the companion **TrustScore AI** — that validation has to
happen *before* a routing change ships, so a cost saving isn't
purchased with a quality regression nobody measured.""")

md("## 6. Summary")

code(r"""
print("=== MarginIQ summary ===")
print(f"Total accounts: {len(accounts):,}")
print(f"Total monthly gross margin: ${accounts.gross_margin.sum():,.0f}")
print()
print(f"Pro tier avg margin: ${pro.gross_margin.mean():.2f} | Pro top usage decile avg margin: ${top_decile.gross_margin.mean():.2f}")
print(f"Pro top usage decile % negative margin: {(top_decile.gross_margin < 0).mean()*100:.1f}%  (vs. {(pro.gross_margin < 0).mean()*100:.1f}% tier-wide)")
print()
print(f"Free tier CAC per converted user: ${cac['cac_per_converted_user']:.2f} | approx payback: {cac['approx_payback_months_at_starter_price']:.1f} months")
print()
print(f"Overage pricing breakeven elasticity ($1.25 -> $2.00): {breakeven_2_00:.3f}")
print()
print(f"Routing savings ({', '.join(safe_tasks)}): ${routing['monthly_savings']:,.0f}/mo (${routing['annualized_savings']:,.0f}/yr annualized)")
""")

nb["cells"] = cells
nbf.write(nb, "analysis.ipynb")
print("Notebook written.")
