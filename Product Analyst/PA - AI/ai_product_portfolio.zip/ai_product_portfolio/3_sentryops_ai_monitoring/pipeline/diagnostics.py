"""
diagnostics.py — the fixed diagnostic playbook SentryOps AI's agent runs
the moment ANY detector (deploy regression, latency spike, or
hallucination drift) fires: a breakdown by task_type/model_version for
the incident window, and a comparison against a pre-incident baseline
window. Deterministic and identical every time, so the LLM's job (see
agent.py) is to synthesize evidence that's already been gathered the same
way for every incident -- not to decide what to go look at.
"""
import pandas as pd


def breakdown_by_task_and_version(metrics: pd.DataFrame, start: pd.Timestamp, end: pd.Timestamp) -> pd.DataFrame:
    sub = metrics[(metrics.timestamp >= start) & (metrics.timestamp < end)]
    return sub.groupby(["task_type", "model_version"]).agg(
        n_requests=("n_requests", "sum"),
        success_rate=("n_success", lambda s: s.sum() / sub.loc[s.index, "n_requests"].sum()),
        avg_p95_latency_ms=("latency_p95_ms", "mean"),
        hallucination_flag_rate=("n_hallucination_flagged", lambda s: s.sum() / sub.loc[s.index, "n_requests"].sum()),
    ).round(4).reset_index()


def compare_to_pre_deploy_baseline(metrics: pd.DataFrame, task_type: str, incident_start: pd.Timestamp,
                                    incident_end: pd.Timestamp, baseline_hours: int = 72) -> pd.DataFrame:
    """Compares the incident window to a same-length window immediately
    preceding it, for one task_type, across all three headline metrics --
    the general-purpose "what actually changed" comparison used
    regardless of which detector triggered."""
    baseline_start = incident_start - pd.Timedelta(hours=baseline_hours)
    sub = metrics[metrics.task_type == task_type]

    def _window_stats(df, lo, hi):
        w = df[(df.timestamp >= lo) & (df.timestamp < hi)]
        n = w.n_requests.sum()
        return {
            "n_requests": int(n),
            "success_rate": round(w.n_success.sum() / n, 4) if n else float("nan"),
            "avg_p95_latency_ms": round(w.latency_p95_ms.mean(), 1) if len(w) else float("nan"),
            "hallucination_flag_rate": round(w.n_hallucination_flagged.sum() / n, 4) if n else float("nan"),
        }

    baseline = _window_stats(sub, baseline_start, incident_start)
    incident = _window_stats(sub, incident_start, incident_end)
    out = pd.DataFrame([baseline, incident], index=["baseline", "incident"])
    out.loc["pct_change"] = ((out.loc["incident"] - out.loc["baseline"]) / out.loc["baseline"] * 100).round(2)
    return out
