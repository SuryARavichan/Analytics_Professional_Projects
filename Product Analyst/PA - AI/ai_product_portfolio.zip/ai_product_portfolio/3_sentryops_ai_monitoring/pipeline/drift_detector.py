"""
drift_detector.py — the GRADUAL-DRIFT detector, a different shape from
both the deploy regression (a clean step-change at a known timestamp) and
the latency point anomaly (a sharp, transient spike). A slow-building
hallucination-rate increase never produces a single extreme hour, so a
z-score-on-residual detector like latency_anomaly.py's would miss it
entirely -- this detector instead tracks a rolling daily mean against its
value from `lookback_days` earlier and flags a SUSTAINED upward run.
"""
import numpy as np
import pandas as pd


def rolling_drift_detector(metrics: pd.DataFrame, task_type: str, metric_col: str = "hallucination_flag_rate",
                            roll_days: int = 3, lookback_days: int = 14,
                            rise_threshold_relative: float = 0.30, min_consecutive_days: int = 5) -> pd.DataFrame:
    """Aggregates to a daily weighted average of `metric_col` (weighted by
    n_requests, since a flag RATE should be volume-weighted, not a naive
    mean of hourly rates), computes a `roll_days`-day rolling average, and
    compares it to that same rolling average from `lookback_days` earlier.
    Flags the first day of any run of >= min_consecutive_days where the
    rolling average has risen more than `rise_threshold_relative` (30%
    default) above its value 2 weeks prior -- a sustained, not one-off,
    increase."""
    sub = metrics[metrics.task_type == task_type].copy()
    sub["date"] = sub.timestamp.dt.date
    # volume-weighted: reconstruct flagged-count per hour from the rate column
    # (rather than assuming a matching n_* count column exists for any metric_col)
    sub["_n_flagged"] = sub[metric_col] * sub.n_requests
    daily = sub.groupby("date").agg(n_requests=("n_requests", "sum"), n_flagged=("_n_flagged", "sum"))
    daily["rate"] = daily.n_flagged / daily.n_requests
    daily.index = pd.to_datetime(daily.index)
    daily = daily.sort_index()

    roll = daily["rate"].rolling(roll_days).mean()
    roll_lag = roll.shift(lookback_days)
    rel_change = (roll - roll_lag) / roll_lag

    risen = rel_change >= rise_threshold_relative
    run_id = (risen != risen.shift()).cumsum()
    windows = []
    for _, run in risen.groupby(run_id):
        if run.iloc[0] and len(run) >= min_consecutive_days:
            idx = run.index
            windows.append({
                "task_type": task_type, "metric": metric_col,
                "drift_flagged_start": idx[0], "run_length_days": len(run),
                "baseline_rate": round(roll_lag.loc[idx[0]], 4),
                "current_rate": round(roll.loc[idx[-1]], 4),
                "relative_increase_pct": round(rel_change.loc[idx[-1]] * 100, 1),
            })
    return pd.DataFrame(windows), daily
