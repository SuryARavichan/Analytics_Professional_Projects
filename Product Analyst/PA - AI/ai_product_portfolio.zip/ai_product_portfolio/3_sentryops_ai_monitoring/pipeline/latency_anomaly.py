"""
latency_anomaly.py — the POINT-ANOMALY detector, for sharp/transient
latency spikes (an infra incident shape, not a deploy shape). Same
STL(seasonal decomposition) + z-score-on-residual technique used for
LaunchPulse's point_anomaly_detector, applied here to hourly p95 latency
with period=24 to absorb the strong business-hours seasonality in this
data (see data/generate_data.py's business_hours_multiplier) -- without
removing that daily cycle first, a normal 2pm traffic peak would itself
look like an "anomaly."
"""
import numpy as np
import pandas as pd
from statsmodels.tsa.seasonal import STL


def point_anomaly_detector(hourly_series: pd.Series, z_threshold: float = 3.5, period: int = 24) -> pd.DataFrame:
    """hourly_series: p95 latency (or any hourly metric) indexed by
    DatetimeIndex, for a SINGLE task_type."""
    stl = STL(hourly_series, period=period, robust=True)
    result = stl.fit()
    resid = result.resid
    z = (resid - resid.mean()) / resid.std()

    out = pd.DataFrame({
        "timestamp": hourly_series.index, "actual": hourly_series.values,
        "trend": result.trend.values, "seasonal": result.seasonal.values,
        "residual": resid.values, "z_score": z.values,
    })
    out["is_anomaly"] = out.z_score.abs() >= z_threshold
    out["direction"] = np.where(out.z_score > 0, "spike", "drop")
    return out


def find_anomaly_windows(anomaly_df: pd.DataFrame, min_consecutive_hours: int = 2) -> pd.DataFrame:
    """Collapses individual flagged hours into contiguous incident
    windows -- a monitoring agent should open ONE incident for a 5-hour
    spike, not five."""
    flagged = anomaly_df.is_anomaly
    run_id = (flagged != flagged.shift()).cumsum()
    windows = []
    for _, run in anomaly_df.groupby(run_id):
        if run.is_anomaly.iloc[0] and len(run) >= min_consecutive_hours:
            windows.append({
                "start": run.timestamp.iloc[0], "end": run.timestamp.iloc[-1],
                "duration_hours": len(run), "peak_z_score": run.z_score.abs().max(),
                "peak_actual": run.actual.max(), "direction": run.direction.iloc[0],
            })
    return pd.DataFrame(windows)
