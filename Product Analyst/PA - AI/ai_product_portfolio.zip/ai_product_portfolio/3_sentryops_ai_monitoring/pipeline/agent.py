"""
agent.py — orchestrates SentryOps AI's "perceive -> act -> reason ->
report" loop across THREE different detector types (deploy regression,
latency point-anomaly, hallucination drift):

  PERCEIVE  a flagged signal from one of regression_detector.py /
            latency_anomaly.py / drift_detector.py
  ACT       run the fixed diagnostic playbook (diagnostics.py) --
            deterministic, same evidence-gathering steps every time
  REASON    an LLM call applies an explicit decision rubric to the
            gathered evidence and writes the incident verdict
  REPORT    a structured IncidentReport the dashboard/notebook renders

The rubric is given directly in the system prompt (the same "make the
model apply a rule correctly rather than invent judgment" pattern used in
ShipCall AI's decision agent): a deploy-tied signal is only a genuine
INCIDENT if the deploy-aware regression test is statistically significant
AND the drop is large enough to matter -- a deploy that changes latency
or token usage on purpose, with no significant success-rate regression,
must be reported as a BENIGN / NO ACTION finding, not an incident. This
is what lets the agent correctly dismiss the planned prompt-template
update in this dataset instead of flagging every deploy-adjacent metric
shift as a fire.
"""
from __future__ import annotations
import sys
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent / "shared"))
from llm_client import LLMClient  # noqa: E402
from diagnostics import breakdown_by_task_and_version, compare_to_pre_deploy_baseline  # noqa: E402

SYSTEM_PROMPT = (
    "You are SentryOps AI, an autonomous LLMOps monitoring agent for Cortex Copilot, an AI writing/"
    "coding/summarization assistant. You are given the output of ONE statistical detector (a deploy-"
    "aware success-rate regression test, an STL latency point-anomaly detector, or a rolling "
    "hallucination-rate drift detector) plus a fixed diagnostic breakdown for the same window. Apply "
    "this rubric exactly:\n"
    "1. DEPLOY REGRESSION signals: only classify as INCIDENT if the detector's own `is_regression` "
    "flag is True (statistically significant AND at least 2pp worse). If `is_regression` is False, "
    "you MUST classify as BENIGN / NO ACTION even if other metrics (latency, token usage) changed "
    "substantially -- a deploy can intentionally change secondary metrics without harming the outcome "
    "metric (success rate), and that is not a regression.\n"
    "2. LATENCY POINT ANOMALY signals: classify as INCIDENT (transient) if a contiguous anomaly window "
    "was found; note whether the diagnostic data shows it has already recovered by report time.\n"
    "3. HALLUCINATION DRIFT signals: classify as INCIDENT (sustained) if a sustained rising run was "
    "found; this is a data-quality/product issue, not an infra issue, so root-cause hypotheses should "
    "focus on content/knowledge-source quality, not infrastructure.\n"
    "Write a short incident report for an ML/Platform on-call engineer with: (1) VERDICT (INCIDENT or "
    "BENIGN / NO ACTION), (2) ROOT CAUSE hypothesis, (3) CONFIDENCE (High/Medium/Low) with one-sentence "
    "justification, (4) RECOMMENDED ACTION. Only draw conclusions the evidence actually supports."
)


@dataclass
class IncidentReport:
    incident_id: str
    kind: str  # "deploy_regression" | "latency_spike" | "hallucination_drift"
    task_type: str
    window: tuple
    detection_stats: dict
    diagnostic_breakdown: "pd.DataFrame"
    baseline_comparison: "pd.DataFrame" = None
    narrative: str = ""
    llm_meta: dict = field(default_factory=dict)


def investigate(metrics: pd.DataFrame, incident_id: str, kind: str, task_type: str,
                 start: pd.Timestamp, end: pd.Timestamp, detection_stats: dict,
                 client: LLMClient) -> IncidentReport:
    # ACT: fixed diagnostic playbook
    breakdown = breakdown_by_task_and_version(metrics, start, end)
    baseline_cmp = compare_to_pre_deploy_baseline(metrics, task_type, start, end)

    # REASON: LLM applies the rubric to the gathered evidence
    evidence = (
        f"Signal type: {kind}\n"
        f"Task type: {task_type}\n"
        f"Window: {start} to {end}\n\n"
        f"Detection stats: {detection_stats}\n\n"
        f"Diagnostic breakdown by task_type/model_version for this window:\n{breakdown.to_string(index=False)}\n\n"
        f"Comparison to pre-incident baseline (task_type={task_type}):\n{baseline_cmp.to_string()}\n"
    )
    resp = client.complete(prompt=evidence, system=SYSTEM_PROMPT, prompt_id=incident_id)

    return IncidentReport(
        incident_id=incident_id, kind=kind, task_type=task_type, window=(start, end),
        detection_stats=detection_stats, diagnostic_breakdown=breakdown, baseline_comparison=baseline_cmp,
        narrative=resp.text, llm_meta={"backend": resp.backend, "cached": resp.cached},
    )
