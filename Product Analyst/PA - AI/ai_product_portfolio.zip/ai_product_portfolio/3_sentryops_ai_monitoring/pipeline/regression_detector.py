"""
regression_detector.py — the DEPLOY-AWARE detector. This is deliberately
different from a generic anomaly scan: it is only ever run at a KNOWN
deploy timestamp (from deploys.json), and it only ever tests the outcome
metric that actually defines "regression" for an LLM product -- success
rate -- via the same two-proportion z-test used in the CausalLift project.

Why this matters as its own detector, not just another anomaly check: a
deploy is exactly the moment you have a clean, principled before/after
comparison window (no seasonality confound, a known single cause
candidate) -- and it's exactly the moment a naive "did anything change"
scan produces false positives, because deploys routinely change
secondary metrics (latency, token usage) on purpose. This detector's job
is to answer one focused question per deploy: did the thing that
actually matters (success rate) get worse -- not "did something change."
"""
from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy import stats


@dataclass
class DeployRegressionResult:
    deploy_id: str
    task_type: str
    deploy_timestamp: pd.Timestamp
    window_hours: int
    pre_success_rate: float
    post_success_rate: float
    lift_pp: float
    z: float
    p_value: float
    n_pre: int
    n_post: int
    is_regression: bool


def check_deploy_regression(metrics: pd.DataFrame, deploy: dict, task_type: str,
                             window_hours: int = 72, warmup_hours: int = 2,
                             alpha: float = 0.01, min_regression_pp: float = 2.0) -> DeployRegressionResult:
    """Two-proportion z-test on success rate, comparing `window_hours` of
    traffic immediately BEFORE the deploy to `window_hours` of traffic
    starting `warmup_hours` AFTER it (a short warmup skip avoids counting
    a rollout's brief in-flight-request tail against the new version).

    Flags `is_regression` only when the result is BOTH statistically
    significant (p < alpha, using a stricter-than-0.05 threshold since
    this gates an automated incident) AND practically meaningful (at
    least `min_regression_pp` percentage points worse) -- a real
    regression needs both, the same "statistically significant AND
    harmful enough to matter" standard used for guardrail metrics in the
    ShipCall AI project.
    """
    ts = pd.Timestamp(deploy["timestamp"])
    sub = metrics[metrics.task_type == task_type].sort_values("timestamp")

    pre = sub[(sub.timestamp >= ts - pd.Timedelta(hours=window_hours)) & (sub.timestamp < ts)]
    post = sub[(sub.timestamp >= ts + pd.Timedelta(hours=warmup_hours)) &
               (sub.timestamp < ts + pd.Timedelta(hours=warmup_hours + window_hours))]

    n_pre, n_post = int(pre.n_requests.sum()), int(post.n_requests.sum())
    s_pre, s_post = int(pre.n_success.sum()), int(post.n_success.sum())
    p_pre = s_pre / n_pre if n_pre else float("nan")
    p_post = s_post / n_post if n_post else float("nan")

    p_pool = (s_pre + s_post) / (n_pre + n_post)
    se_pool = np.sqrt(p_pool * (1 - p_pool) * (1 / n_pre + 1 / n_post)) if n_pre and n_post else float("nan")
    z = (p_post - p_pre) / se_pool if se_pool and se_pool > 0 else 0.0
    p_value = 2 * (1 - stats.norm.cdf(abs(z)))
    lift_pp = (p_post - p_pre) * 100

    is_regression = bool((p_value < alpha) and (lift_pp <= -min_regression_pp))

    return DeployRegressionResult(
        deploy_id=deploy["deploy_id"], task_type=task_type, deploy_timestamp=ts,
        window_hours=window_hours, pre_success_rate=round(p_pre, 4), post_success_rate=round(p_post, 4),
        lift_pp=round(lift_pp, 2), z=round(z, 3), p_value=p_value, n_pre=n_pre, n_post=n_post,
        is_regression=is_regression,
    )


def check_all_deploys(metrics: pd.DataFrame, deploys: list[dict]) -> pd.DataFrame:
    results = []
    for deploy in deploys:
        for task_type in deploy["task_types_affected"]:
            r = check_deploy_regression(metrics, deploy, task_type)
            results.append(vars(r))
    return pd.DataFrame(results)
