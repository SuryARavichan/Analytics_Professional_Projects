"""
Builds SentryOps AI's self-contained HTML dashboard: KPI cards, a 4-panel
Plotly view (the two deploy regressions side by side, the cross-task
latency spike, and the hallucination drift), plus the four agent incident
reports rendered as cards -- including the correctly-dismissed benign
deploy, front and center, since that's the finding that best demonstrates
the agent isn't just flagging every metric shift as a fire.
"""
import sys, json
sys.path.insert(0, "../../shared")
sys.path.insert(0, "../pipeline")
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.io as pio
from regression_detector import check_all_deploys
from latency_anomaly import point_anomaly_detector, find_anomaly_windows
from drift_detector import rolling_drift_detector
from agent import investigate
from llm_client import get_client

metrics = pd.read_csv("../data/metrics.csv", parse_dates=["timestamp"])
deploys = json.load(open("../data/deploys.json"))
client = get_client(cache_file="../cached_responses.json")

dep_results = check_all_deploys(metrics, deploys)
r_regression, r_benign = dep_results.iloc[0], dep_results.iloc[1]

latency_windows = {}
for task in metrics.task_type.unique():
    sub = metrics[metrics.task_type == task].set_index("timestamp").sort_index()
    anomalies = point_anomaly_detector(sub["latency_p95_ms"])
    windows = find_anomaly_windows(anomalies)
    if len(windows):
        latency_windows[task] = windows.iloc[0]

drift_windows, daily_halluc = rolling_drift_detector(metrics, "data_explanation")
w_drift = drift_windows.iloc[0]

report_regression = investigate(metrics, "incident_deploy_regression_code_completion", "deploy_regression",
                                 "code_completion", r_regression.deploy_timestamp,
                                 r_regression.deploy_timestamp + pd.Timedelta(hours=74), dict(r_regression), client)
report_benign = investigate(metrics, "incident_benign_deploy_email_draft", "deploy_regression",
                             "email_draft", r_benign.deploy_timestamp,
                             r_benign.deploy_timestamp + pd.Timedelta(hours=74), dict(r_benign), client)
w_latency = latency_windows["code_completion"]
report_latency = investigate(metrics, "incident_latency_spike", "latency_spike", "code_completion",
                              w_latency.start, w_latency.end + pd.Timedelta(hours=1), dict(w_latency), client)
report_drift = investigate(metrics, "incident_hallucination_drift_data_explanation", "hallucination_drift",
                            "data_explanation", pd.Timestamp(w_drift.drift_flagged_start),
                            pd.Timestamp(w_drift.drift_flagged_start) + pd.Timedelta(days=int(w_drift.run_length_days)),
                            dict(w_drift), client)

# ---- 4-panel Plotly figure ----
fig = make_subplots(rows=2, cols=2, subplot_titles=(
    f"code_completion: REGRESSION (p={r_regression.p_value:.1e})",
    f"email_draft: no regression (p={r_benign.p_value:.2f})",
    "Cross-Task Latency Spike (Jan 13)",
    "data_explanation Hallucination Drift",
))

for col, (row, task) in enumerate([(r_regression, "code_completion"), (r_benign, "email_draft")], start=1):
    sub = metrics[metrics.task_type == task].sort_values("timestamp")
    daily = sub.set_index("timestamp").resample("D").apply(
        lambda g: g.n_success.sum() / g.n_requests.sum() if g.n_requests.sum() else np.nan)
    color = "#C0392B" if row.is_regression else "#27AE60"
    fig.add_trace(go.Scatter(x=daily.index, y=daily.values, mode="lines", line=dict(color=color, width=2), showlegend=False), row=1, col=col)
    fig.add_vline(x=row.deploy_timestamp.timestamp() * 1000, line_dash="dash", line_color="#333", row=1, col=col)

sub_lat = metrics[metrics.task_type == "code_completion"].set_index("timestamp").sort_index()
fig.add_trace(go.Scatter(x=sub_lat.index, y=sub_lat.latency_p95_ms, mode="lines", line=dict(color="#2E86AB", width=1), showlegend=False), row=2, col=1)
fig.add_vrect(x0=w_latency.start, x1=w_latency.end, fillcolor="#C0392B", opacity=0.2, line_width=0, row=2, col=1)

fig.add_trace(go.Scatter(x=daily_halluc.index, y=daily_halluc.rate * 100, mode="lines+markers",
                          line=dict(color="#2E86AB", width=2), marker=dict(size=4), showlegend=False), row=2, col=2)
fig.add_vrect(x0=pd.Timestamp(w_drift.drift_flagged_start), x1=daily_halluc.index.max(), fillcolor="#C0392B", opacity=0.12, line_width=0, row=2, col=2)

fig.update_yaxes(title_text="Daily success rate", row=1, col=1)
fig.update_yaxes(title_text="p95 latency (ms)", row=2, col=1)
fig.update_yaxes(title_text="Hallucination flag rate (%)", row=2, col=2)
fig.update_layout(
    height=760,
    font=dict(family="Inter, Segoe UI, Arial", size=11.5),
    plot_bgcolor="white", paper_bgcolor="#FAFAFA", margin=dict(t=60, l=60, r=30, b=50),
)
html_chart = pio.to_html(fig, include_plotlyjs="inline", full_html=False, config={"displaylogo": False})


def card(title, badge, badge_color, narrative):
    lines = narrative.strip().split("\n\n")
    body = "".join(f"<p>{l.replace(chr(10), '<br>')}</p>" for l in lines)
    return f"""<div class="card">
      <span class="badge" style="background:{badge_color}">{badge}</span>
      <h3>{title}</h3>
      {body}
    </div>"""


cards_html = "".join([
    card("code_completion deploy (v2 → v3)", "INCIDENT", "#C0392B", report_regression.narrative),
    card("email_draft deploy (prompt template)", "BENIGN / NO ACTION", "#27AE60", report_benign.narrative),
    card("Cross-task latency spike (Jan 13)", "INCIDENT — transient", "#E8A33D", report_latency.narrative),
    card("data_explanation hallucination drift", "INCIDENT — sustained", "#E8A33D", report_drift.narrative),
])

page = f"""<!doctype html>
<html><head><meta charset="utf-8"><title>SentryOps AI — LLM Monitoring Dashboard</title>
<style>
  body {{ font-family: Inter, 'Segoe UI', Arial, sans-serif; margin:0; background:#FAFAFA; color:#1a1a1a; }}
  .wrap {{ max-width: 1300px; margin: 0 auto; padding: 24px; }}
  h1 {{ font-size: 22px; margin-bottom:2px; }}
  .sub {{ color:#666; font-size:14px; margin-bottom: 18px; }}
  .kpis {{ display:flex; gap:16px; margin-bottom: 18px; flex-wrap: wrap; }}
  .kpi {{ background:white; border-radius:10px; padding:16px 22px; box-shadow:0 1px 4px rgba(0,0,0,0.08); flex:1; min-width:210px; }}
  .kpi .val {{ font-size:24px; font-weight:700; color:#2E86AB; }}
  .kpi .lbl {{ font-size:12px; color:#666; text-transform:uppercase; letter-spacing:0.03em; margin-top:2px; }}
  .panel {{ background:white; border-radius:12px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:8px 16px; margin-bottom:20px; }}
  .cards {{ display:grid; grid-template-columns: 1fr 1fr; gap:16px; margin: 20px 0; }}
  .card {{ background:white; border-radius:10px; box-shadow:0 1px 4px rgba(0,0,0,0.08); padding:16px 18px; font-size:13px; line-height:1.6; }}
  .card h3 {{ margin:0 0 8px; font-size:14px; }}
  .card p {{ margin: 6px 0; }}
  .card .badge {{ display:inline-block; color:white; font-size:11px; font-weight:700; padding:2px 8px; border-radius:8px; margin-bottom:8px; }}
  footer {{ font-size:12px; color:#888; text-align:center; padding: 24px 0; }}
  @media (max-width: 900px) {{ .cards {{ grid-template-columns: 1fr; }} }}
</style></head>
<body><div class="wrap">
  <h1>🛰️ SentryOps AI — Autonomous LLM Performance &amp; Regression Monitoring</h1>
  <div class="sub">Three detectors for three failure shapes (deploy regression, latency point-anomaly, hallucination drift) — and an agent that correctly tells a real regression apart from a planned, beneficial change.</div>
  <div class="kpis">
    <div class="kpi"><div class="val">{r_regression.lift_pp:.1f}pp</div><div class="lbl">code_completion Success-Rate Regression (p={r_regression.p_value:.1e})</div></div>
    <div class="kpi"><div class="val">✓ Correctly Dismissed</div><div class="lbl">email_draft Deploy (p={r_benign.p_value:.2f}, not significant)</div></div>
    <div class="kpi"><div class="val">{w_latency.peak_z_score:.1f}σ</div><div class="lbl">Peak Latency Spike Z-Score</div></div>
    <div class="kpi"><div class="val">+{w_drift.relative_increase_pct:.0f}%</div><div class="lbl">data_explanation Hallucination Drift</div></div>
  </div>
  <div class="panel">{html_chart}</div>
  <h2 style="font-size:16px;">Agent Incident Reports</h2>
  <div class="cards">{cards_html}</div>
  <footer>Synthetic hourly LLM telemetry, seeded and reproducible (see README) · full analysis in <code>/notebook/analysis.ipynb</code></footer>
</div></body></html>"""

with open("index.html", "w") as f:
    f.write(page)
print("Wrote dashboard/index.html —", len(page), "bytes")
