import nbformat as nbf

nb = nbf.v4.new_notebook()
cells = []
def md(t): cells.append(nbf.v4.new_markdown_cell(t))
def code(t): cells.append(nbf.v4.new_code_cell(t))

md(r"""
# SentryOps AI — Autonomous LLM Performance & Regression Monitoring Agent

**What this is:** an LLMOps monitoring system for Cortex Copilot that
uses **three different statistical detectors for three different failure
shapes**, because no single anomaly-detection technique catches every way
an AI product actually breaks:

1. **Deploy-aware regression detector** — a before/after two-proportion
   z-test on success rate, run at known deploy timestamps. Catches a
   clean step-change tied to a specific cause.
2. **STL point-anomaly detector** — seasonal decomposition + z-score on
   the residual, run on hourly p95 latency. Catches a sharp, transient
   spike a step-change test would never trigger on (no deploy involved).
3. **Rolling drift detector** — a trailing-average-vs-2-weeks-ago
   comparison, run on hallucination flag rate. Catches a slow, gradual
   creep that never produces one extreme hour, which the point-anomaly
   detector is structurally blind to.

**The finding that matters most:** one of the two deploys in this dataset
is a **genuine regression** (a model update that hurts code-completion
success rate) and the other is a **planned, beneficial change** (a
prompt-template update that changes latency on purpose but doesn't touch
success rate) — and the agent has to tell them apart correctly, not flag
every deploy-adjacent metric shift as a fire. Getting this distinction
right is what separates a monitoring system engineers trust from one they
learn to ignore.

**On the LLM backend:** same cached/live design as the rest of this
session's AI-augmented projects — see `../shared/llm_client.py`. Every
cached incident narrative below was authored by reading the real,
computed detector output first (the actual z-statistics, p-values, and
diagnostic breakdowns you'll see run in this notebook), not invented
independently of the data.
""")

code(r"""
import sys, json
sys.path.insert(0, "../../shared")
sys.path.insert(0, "../pipeline")
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from regression_detector import check_all_deploys, check_deploy_regression
from latency_anomaly import point_anomaly_detector, find_anomaly_windows
from drift_detector import rolling_drift_detector
from diagnostics import breakdown_by_task_and_version, compare_to_pre_deploy_baseline
from agent import investigate
from llm_client import get_client

sns.set_theme(style="whitegrid")
plt.rcParams["figure.dpi"] = 110

metrics = pd.read_csv("../data/metrics.csv", parse_dates=["timestamp"])
deploys = json.load(open("../data/deploys.json"))
client = get_client(cache_file="../cached_responses.json")

print(f"{len(metrics):,} hourly rows | {metrics.timestamp.min()} to {metrics.timestamp.max()} | "
      f"{metrics.task_type.nunique()} task types | {len(deploys)} deploy events")
metrics.head()
""")

md("## 1. Deploy-Aware Regression Detector — Two Known Deploys, Two Different Verdicts")

code(r"""
dep_results = check_all_deploys(metrics, deploys)
dep_results[["deploy_id", "task_type", "pre_success_rate", "post_success_rate", "lift_pp", "z", "p_value", "is_regression"]]
""")

code(r"""
fig, axes = plt.subplots(1, 2, figsize=(13, 5))
for ax, (_, row) in zip(axes, dep_results.iterrows()):
    sub = metrics[metrics.task_type == row.task_type].sort_values("timestamp")
    daily = sub.set_index("timestamp").resample("D").apply(
        lambda g: g.n_success.sum() / g.n_requests.sum() if g.n_requests.sum() else np.nan
    )
    ax.plot(daily.index, daily.values, color="#2E86AB", linewidth=1.5)
    ax.axvline(row.deploy_timestamp, color="#C0392B", linestyle="--", label="deploy")
    verdict = "REGRESSION" if row.is_regression else "no regression"
    ax.set_title(f"{row.task_type}\n{row.deploy_id} -- {verdict} (p={row.p_value:.1e})")
    ax.set_ylabel("Daily success rate")
    ax.legend()
plt.tight_layout()
plt.savefig("../dashboard/deploy_regressions.png", dpi=150)
plt.show()
""")

md(r"""The `code_completion` deploy (v2 -> v3) shows a clean, statistically
significant step-down in success rate right at the deploy line — a real
regression. The `email_draft` deploy (planned prompt-template update)
shows **no** significant change in success rate at all, even though
(as Section 4 shows) its latency changed substantially. The detector
correctly separates these two cases using the same test.""")

md("## 2. STL Point-Anomaly Detector — the Latency Spike")

code(r"""
latency_windows = {}
for task in metrics.task_type.unique():
    sub = metrics[metrics.task_type == task].set_index("timestamp").sort_index()
    anomalies = point_anomaly_detector(sub["latency_p95_ms"])
    windows = find_anomaly_windows(anomalies)
    if len(windows):
        latency_windows[task] = (anomalies, windows.iloc[0])

pd.DataFrame([{"task_type": t, **w.to_dict()} for t, (_, w) in latency_windows.items()])
""")

code(r"""
fig, axes = plt.subplots(2, 2, figsize=(13, 8), sharex=True)
for ax, task in zip(axes.flat, metrics.task_type.unique()):
    sub = metrics[metrics.task_type == task].set_index("timestamp").sort_index()
    ax.plot(sub.index, sub.latency_p95_ms, color="#2E86AB", linewidth=0.8)
    if task in latency_windows:
        _, w = latency_windows[task]
        ax.axvspan(w.start, w.end, color="#C0392B", alpha=0.25, label=f"flagged (peak z={w.peak_z_score:.1f})")
        ax.legend(fontsize=8)
    ax.set_title(task, fontsize=10)
    ax.set_ylabel("p95 latency (ms)")
plt.tight_layout()
plt.savefig("../dashboard/latency_spike.png", dpi=150)
plt.show()
""")

md(r"""All four task types show a simultaneous, sharp p95 latency spike in
the same few-hour window with no deploy event tied to it — the signature
of a shared infrastructure incident rather than a task-specific or
model-specific problem, and something a deploy-aware detector would never
catch since there's no deploy to anchor a before/after comparison to.""")

md("## 3. Rolling Drift Detector — the Gradual Hallucination-Rate Creep")

code(r"""
drift_windows, daily_halluc = rolling_drift_detector(metrics, "data_explanation")
drift_windows
""")

code(r"""
fig, ax = plt.subplots(figsize=(11, 5.5))
ax.plot(daily_halluc.index, daily_halluc.rate * 100, color="#2E86AB", linewidth=1.5, marker="o", markersize=3)
if len(drift_windows):
    w = drift_windows.iloc[0]
    ax.axvspan(pd.Timestamp(w.drift_flagged_start), daily_halluc.index.max(), color="#C0392B", alpha=0.12, label="sustained rise flagged")
ax.set_ylabel("Daily hallucination flag rate (%)")
ax.set_title("data_explanation Hallucination Flag Rate -- Gradual Drift, Not a Spike")
ax.legend()
plt.tight_layout()
plt.savefig("../dashboard/hallucination_drift.png", dpi=150)
plt.show()
""")

md(r"""No single day here is an outlier large enough for a z-score-based
point detector to catch — the rise is gradual, which is exactly the shape
this detector is built for: a **sustained** trailing-average increase
relative to 2 weeks prior, not a one-off bad hour.""")

md("## 4. Fixed Diagnostic Playbook + Agent Reports")

code(r"""
r_regression = dep_results.iloc[0]
report_regression = investigate(
    metrics, "incident_deploy_regression_code_completion", "deploy_regression", "code_completion",
    r_regression.deploy_timestamp, r_regression.deploy_timestamp + pd.Timedelta(hours=74),
    dict(r_regression), client,
)
print(report_regression.narrative)
""")

code(r"""
r_benign = dep_results.iloc[1]
report_benign = investigate(
    metrics, "incident_benign_deploy_email_draft", "deploy_regression", "email_draft",
    r_benign.deploy_timestamp, r_benign.deploy_timestamp + pd.Timedelta(hours=74),
    dict(r_benign), client,
)
print(report_benign.narrative)
""")

code(r"""
report_benign.baseline_comparison
""")

code(r"""
_, w_latency = latency_windows["code_completion"]
report_latency = investigate(
    metrics, "incident_latency_spike", "latency_spike", "code_completion",
    w_latency.start, w_latency.end + pd.Timedelta(hours=1), dict(w_latency), client,
)
print(report_latency.narrative)
""")

code(r"""
w_drift = drift_windows.iloc[0]
report_drift = investigate(
    metrics, "incident_hallucination_drift_data_explanation", "hallucination_drift", "data_explanation",
    pd.Timestamp(w_drift.drift_flagged_start),
    pd.Timestamp(w_drift.drift_flagged_start) + pd.Timedelta(days=int(w_drift.run_length_days)),
    dict(w_drift), client,
)
print(report_drift.narrative)
""")

md("## 5. Summary — Four Signals, Two Real Incidents, One Correctly Dismissed False Positive")

code(r"""
summary = pd.DataFrame([
    {"incident": "code_completion deploy (v2->v3)", "detector": "deploy regression", "verdict": report_regression.narrative.splitlines()[0]},
    {"incident": "email_draft deploy (prompt template)", "detector": "deploy regression", "verdict": report_benign.narrative.splitlines()[0]},
    {"incident": "cross-task latency spike (Jan 13)", "detector": "STL point anomaly", "verdict": report_latency.narrative.splitlines()[0]},
    {"incident": "data_explanation hallucination drift", "detector": "rolling drift", "verdict": report_drift.narrative.splitlines()[0]},
])
summary
""")

nb["cells"] = cells
nbf.write(nb, "analysis.ipynb")
print("Notebook written.")
