# SentryOps AI — Autonomous LLM Performance & Regression Monitoring Agent

**One-line pitch:** an LLMOps monitoring agent that runs three different statistical detectors for three genuinely different failure shapes (a deploy-tied regression, a transient infra spike, a slow content-quality drift), then correctly tells a real regression apart from a planned, beneficial change instead of flagging every metric shift as a fire — the difference between a monitoring system engineers trust and one they learn to ignore.

## Why this project, and why one detector isn't enough

Most "AI monitoring" demos use a single anomaly-detection technique and imply it catches everything. It doesn't — and this project is built specifically to show why not. A model deploy produces a clean step-change with a known cause and timestamp; an infra incident produces a sharp, transient spike with no deploy behind it; a content-quality problem produces a slow multi-day creep that never produces a single extreme hour. Three different shapes need three different detectors, and this project builds all three, then adds the harder, more consequential piece: an agent that has to decide which of two deploys is an actual incident and which is a false alarm, using the same rigorous test both times.

## What's actually built here (not just described)

- **`data/generate_data.py`** — 4,320 hourly telemetry rows (45 days × 4 task types) for Cortex Copilot, with realistic business-hours/weekday seasonality and four deliberately injected incidents of different shapes: a real deploy regression, a transient cross-task latency spike, a gradual hallucination-rate drift, and a planned prompt-template update that changes latency on purpose with **no** success-rate cost — the false positive this agent has to correctly dismiss.
- **`pipeline/regression_detector.py`** — the deploy-aware detector: a two-proportion z-test on success rate, run only at known deploy timestamps (`deploys.json`), flagging `is_regression` only when a drop is both statistically significant (p<0.01) **and** practically meaningful (≥2pp) — both conditions required, the same standard used for guardrail metrics in the companion ShipCall AI project.
- **`pipeline/latency_anomaly.py`** — STL seasonal decomposition (period=24, absorbing the daily business-hours cycle) + z-score on the residual for hourly p95 latency, with a window-collapsing function so one multi-hour spike becomes one incident, not five.
- **`pipeline/drift_detector.py`** — a rolling, volume-weighted trailing-average comparison against the same window 2 weeks prior, flagging a sustained (not one-off) rise — the detector shape built specifically to catch what the point-anomaly detector structurally can't.
- **`pipeline/diagnostics.py`** — the fixed diagnostic playbook (task/model-version breakdown, pre-incident baseline comparison) run identically for every incident, regardless of which detector triggered it.
- **`pipeline/agent.py`** — the perceive → act → reason → report loop, with an explicit decision rubric in the system prompt: a deploy-tied signal is only an INCIDENT if the regression test's own significance flag says so, full stop — even if other metrics moved substantially.
- **`notebook/analysis.ipynb`** — the full, executed walkthrough: all three detectors run against the real data, the fixed diagnostic playbook, and all four agent incident reports. Zero execution errors (22 cells).
- **`dashboard/index.html`** — self-contained interactive dashboard: KPI cards, a 4-panel Plotly view (both deploys side by side, the latency spike, the hallucination drift), and all four incident reports rendered as cards — including the correctly-dismissed benign deploy.

## Key results

| Signal | Detector | Result | Verdict |
|---|---|---|---|
| `code_completion` deploy (v2→v3) | Deploy-aware regression | Success rate 89.6% → 82.0% (−7.6pp), z=−6.84, p=8.0×10⁻¹² | **INCIDENT** |
| `email_draft` deploy (prompt template) | Deploy-aware regression | Success rate 93.7% → 93.9% (+0.2pp), z=0.23, p=0.82 — latency down 18.8%, as intended | **BENIGN / NO ACTION** |
| Cross-task latency spike (Jan 13) | STL point anomaly | Peak z-score ≈15.7, p95 latency up to ~3.6x seasonal expectation, all 4 task types simultaneously, no deploy tied to it | **INCIDENT (transient)** |
| `data_explanation` hallucination drift | Rolling drift | Flag rate 3.6% → 8.6% (+97.4% relative) over a sustained 13+ day run, no deploy tied to it | **INCIDENT (sustained)** |

## On the honest limitations (stated in the notebook, not hidden)

- **Root-cause hypotheses are inferences from pattern shape, not confirmed causes.** The latency-spike report reasons "simultaneous across all task types with no deploy → likely shared infrastructure," and the drift report reasons "isolated to one task type, no deploy, gradual → likely content/data-quality issue." Both are the most consistent explanation given the evidence gathered here, not a confirmed root cause — this playbook doesn't have direct infra telemetry or knowledge-source audit access, and says so explicitly in each report's confidence rationale.
- **The regression detector's thresholds (p<0.01, ≥2pp) are a deliberate, stated choice**, not derived from a cost-of-false-positive/false-negative optimization — a natural production extension.
- **Fixed diagnostic playbook, not a dynamic tool-selection loop** — every incident gets the same evidence-gathering steps regardless of detector type, the same reliability-over-flexibility scoping choice made in the companion LaunchPulse project.

## Resume bullets

- Built a 3-detector LLMOps monitoring pipeline (deploy-aware regression test, STL point-anomaly detector, rolling drift detector) matched to three distinct AI-product failure shapes, correctly catching a −7.6pp deploy regression (p=8×10⁻¹²), a transient infra latency spike (peak z≈15.7), and a gradual +97% hallucination-rate drift in one task type.
- Designed an incident-triage agent with an explicit statistical-significance rubric that correctly distinguished a genuine model regression from a planned, beneficial deploy (an 18.8% latency improvement with no success-rate cost) — avoiding the false-alarm failure mode that erodes trust in automated monitoring.
- Built a fixed, deterministic diagnostic playbook (task/model-version breakdown, pre-incident baseline comparison) that runs identically regardless of which detector fires, keeping every incident report's evidence base auditable and reproducible.

## Interview talking points

- **"Why three detectors instead of one general anomaly detector?"** — because the failure shapes are genuinely different: a step-change tied to a known cause (a deploy) needs a targeted before/after test, not a general scan; a sharp transient spike needs a seasonally-aware point-anomaly detector; a slow multi-week creep needs a trailing-average comparison, since it never produces a single extreme data point a point detector could catch. Using the wrong tool for the anomaly shape is a common real-world monitoring failure this project is built to avoid.
- **"How do you avoid alert fatigue from false positives?"** — the deploy-aware detector's explicit rubric: only flag a deploy as a regression if the OUTCOME metric (success rate) moved significantly, not if ANY metric moved. This is directly demonstrated with the email_draft deploy, where latency dropped 18.8% on purpose and a naive "big change = bad" detector would have false-alarmed on it.
- **"What's the actual production gap here?"** — direct infrastructure telemetry (to confirm the latency spike's root cause rather than infer it from cross-task simultaneity) and a real content/knowledge-source audit trail (to confirm the hallucination drift's cause rather than infer it from task-isolation and gradualness) — both flagged explicitly as confidence-limiting factors in the agent's own reports.
- **"What would you change with more time/data?"** — tune the regression detector's significance/practical-significance thresholds against a real cost model (false-positive investigation cost vs. false-negative user-impact cost) rather than fixed defaults, and extend the drift detector to more than one metric (e.g. also watching for edit-rate or regenerate-rate drift, not just hallucination flags).
