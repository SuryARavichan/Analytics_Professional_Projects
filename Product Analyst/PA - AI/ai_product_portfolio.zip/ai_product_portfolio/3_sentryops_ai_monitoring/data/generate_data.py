"""
Generates 45 days of HOURLY LLM performance telemetry for Cortex Copilot
across 4 task types, with realistic daily/weekly seasonality (business
hours, weekday-heavy usage) plus four deliberately injected incidents of
DIFFERENT shapes -- because a real LLMOps monitoring system needs
different detectors for different failure modes, not one threshold that
supposedly catches everything:

  1. DEPLOY REGRESSION (day 20): a v2 -> v3 model deploy for
     code_completion drops its success rate ~8pp, and it STAYS down --
     the kind of step-change tied to a known deploy timestamp that a
     before/after two-proportion test catches cleanly.
  2. LATENCY SPIKE (day 12, hours 288-292): a ~5 hour infra incident
     spikes p95 latency 3.5-4x across ALL task types, then fully
     recovers -- a sharp, transient point anomaly, the shape an
     STL+z-score detector is built for.
  3. HALLUCINATION DRIFT (days 28-38): data_explanation's hallucination
     flag rate creeps up gradually over ~10 days and then plateaus
     elevated -- slow enough that no single hour looks anomalous, the
     shape a rolling-trend drift detector is built for and a point
     detector would miss.
  4. BENIGN DEPLOY / FALSE POSITIVE (day 35): a planned prompt-template
     update for email_draft makes it permanently ~18% faster (shorter
     prompts) with NO change to success rate or hallucination rate --
     a real, sizeable metric shift that a naive "any big change is bad"
     detector would flag, but the deploy-aware regression detector
     (which checks the outcome metric, success rate, not latency)
     correctly finds no regression to act on.

`deploys.json` records the two known deploy events (their timestamps and
what changed) exactly as a real deploy-tracking system would expose them
-- this is what makes detector #1 "deploy-aware" rather than a generic
anomaly scan.
"""
import json
import numpy as np
import pandas as pd

rng = np.random.default_rng(2026)

START = pd.Timestamp("2026-01-01 00:00:00")
N_HOURS = 45 * 24  # 1,080 hours
timestamps = pd.date_range(START, periods=N_HOURS, freq="h")

TASK_TYPES = ["code_completion", "email_draft", "meeting_summary", "data_explanation"]
BASE_SUCCESS_RATE = {"code_completion": 0.90, "email_draft": 0.93, "meeting_summary": 0.91, "data_explanation": 0.88}
BASE_LATENCY_P50 = {"code_completion": 800, "email_draft": 650, "meeting_summary": 1200, "data_explanation": 950}
BASE_HALLUC_RATE = {"code_completion": 0.020, "email_draft": 0.015, "meeting_summary": 0.020, "data_explanation": 0.035}
BASE_HOURLY_REQUESTS = {"code_completion": 45, "email_draft": 35, "meeting_summary": 20, "data_explanation": 25}

# ---- incident timing (as day-offsets from START) ----
DEPLOY_REGRESSION_DAY = 20
DEPLOY_REGRESSION_TS = START + pd.Timedelta(days=DEPLOY_REGRESSION_DAY)

LATENCY_SPIKE_START = START + pd.Timedelta(hours=288)   # day 12, hour 0
LATENCY_SPIKE_END = START + pd.Timedelta(hours=293)      # ~5 hours

DRIFT_START = START + pd.Timedelta(days=28)
DRIFT_END = START + pd.Timedelta(days=38)

BENIGN_DEPLOY_DAY = 35
BENIGN_DEPLOY_TS = START + pd.Timedelta(days=BENIGN_DEPLOY_DAY)


def business_hours_multiplier(hour: int) -> float:
    """Gaussian bump centered on 2pm, floor at ~0.35x overnight."""
    return 0.35 + 0.65 * np.exp(-0.5 * ((hour - 14) / 5.0) ** 2)


def weekend_factor(dow: int) -> float:
    return 0.55 if dow >= 5 else 1.0


rows = []
for ts in timestamps:
    hour, dow = ts.hour, ts.dayofweek
    vol_mult = business_hours_multiplier(hour) * weekend_factor(dow)

    for task in TASK_TYPES:
        # ---- volume ----
        n_requests = max(1, int(round(rng.normal(BASE_HOURLY_REQUESTS[task] * vol_mult,
                                                   max(1.0, BASE_HOURLY_REQUESTS[task] * vol_mult * 0.15)))))

        # ---- model version + deploy regression (incident 1) ----
        if task == "code_completion" and ts >= DEPLOY_REGRESSION_TS:
            model_version = "v3"
            success_rate_target = BASE_SUCCESS_RATE[task] - 0.08
        else:
            model_version = "v2"
            success_rate_target = BASE_SUCCESS_RATE[task]
        success_rate_target = float(np.clip(success_rate_target + rng.normal(0, 0.01), 0.05, 0.995))

        # ---- hallucination rate + drift (incident 3) ----
        halluc_target = BASE_HALLUC_RATE[task]
        if task == "data_explanation":
            if DRIFT_START <= ts < DRIFT_END:
                progress = (ts - DRIFT_START) / (DRIFT_END - DRIFT_START)
                halluc_target = BASE_HALLUC_RATE[task] + progress * (0.095 - BASE_HALLUC_RATE[task])
            elif ts >= DRIFT_END:
                halluc_target = 0.095  # plateaus elevated -- a slow-building data-quality problem, not resolved
        halluc_target = float(np.clip(halluc_target + rng.normal(0, 0.003), 0.001, 0.5))

        # ---- latency: base + spike (incident 2) + benign deploy speedup (incident 4) ----
        p50_target = BASE_LATENCY_P50[task]
        if task == "email_draft" and ts >= BENIGN_DEPLOY_TS:
            p50_target *= 0.82  # planned prompt-template update -- shorter prompts, permanently faster
        in_latency_spike = LATENCY_SPIKE_START <= ts < LATENCY_SPIKE_END
        if in_latency_spike:
            p50_target *= 3.6

        p50 = max(50.0, rng.normal(p50_target, p50_target * 0.06))
        p95_ratio = 2.15 if not in_latency_spike else 2.5
        p95 = max(p50 * 1.2, rng.normal(p50 * p95_ratio, p50 * 0.10))

        n_success = int(rng.binomial(n_requests, success_rate_target))
        n_halluc = int(rng.binomial(n_requests, halluc_target))

        rows.append({
            "timestamp": ts, "task_type": task, "model_version": model_version,
            "n_requests": n_requests, "n_success": n_success,
            "success_rate": round(n_success / n_requests, 4),
            "latency_p50_ms": round(p50, 1), "latency_p95_ms": round(p95, 1),
            "n_hallucination_flagged": n_halluc,
            "hallucination_flag_rate": round(n_halluc / n_requests, 4),
        })

metrics = pd.DataFrame(rows)
metrics.to_csv("metrics.csv", index=False)

deploys = [
    {
        "deploy_id": "DEPLOY-2026-01-21-A",
        "timestamp": DEPLOY_REGRESSION_TS.isoformat(),
        "task_types_affected": ["code_completion"],
        "model_version_before": "v2", "model_version_after": "v3",
        "description": "Rollout of v3 code-completion model (larger context window, updated training data cutoff).",
    },
    {
        "deploy_id": "DEPLOY-2026-02-05-A",
        "timestamp": BENIGN_DEPLOY_TS.isoformat(),
        "task_types_affected": ["email_draft"],
        "model_version_before": "v2", "model_version_after": "v2",
        "description": "Planned prompt-template update for email_draft: shortened system prompt and trimmed few-shot examples to reduce latency and token cost. No model change.",
    },
]
json.dump(deploys, open("deploys.json", "w"), indent=2)

print(f"{len(metrics):,} hourly rows | {metrics.timestamp.min()} to {metrics.timestamp.max()} | "
      f"{len(TASK_TYPES)} task types | 2 deploy events")
print(metrics.groupby("task_type").agg(
    avg_success_rate=("success_rate", "mean"), avg_p95_latency=("latency_p95_ms", "mean"),
    avg_halluc_rate=("hallucination_flag_rate", "mean"),
).round(4))
print("Wrote metrics.csv, deploys.json")
