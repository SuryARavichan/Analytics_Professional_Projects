-- =====================================================================
-- CASE 03 — FINTECH PREMIUM-UPGRADE PAGE A/B TEST
-- Dataset : real, unmodified production landing-page experiment log
--           (294,478 rows) -- original source company/vertical undisclosed
--           in the public release, see report for the full provenance
--           note. Presented here in a fintech premium-upgrade framing.
-- Engine  : SQLite3 (table: experiment_log)
-- =====================================================================

-- 1. GROUP x LANDING_PAGE CROSS-TAB — surfaces the assignment mismatch.
--    In a clean randomized rollout every 'control' row should show
--    'old_page' and every 'treatment' row should show 'new_page'. Any
--    row that breaks that pattern is a tracking/assignment error and
--    must not be counted toward either arm's result.
SELECT
  "group",
  landing_page,
  COUNT(*) AS n_rows
FROM experiment_log
GROUP BY "group", landing_page
ORDER BY "group", landing_page;

-- 2. MISMATCH COUNT — rows where the assigned group does not match the
--    page actually served (control shown new_page, or treatment shown
--    old_page). This is the exact row count to strip before analysis.
SELECT
  COUNT(*) AS mismatched_rows
FROM experiment_log
WHERE ("group" = 'control'   AND landing_page = 'new_page')
   OR ("group" = 'treatment' AND landing_page = 'old_page');

-- 3. FILTERED GROUP-LEVEL CONVERSION COUNTS + RATES.
--    Mismatched rows excluded; keeps only control+old_page and
--    treatment+new_page — the two intended experiment arms.
SELECT
  "group",
  COUNT(*)                                            AS n_users,
  SUM(converted)                                       AS n_converted,
  ROUND(100.0 * SUM(converted) / COUNT(*), 3)          AS conversion_rate_pct
FROM experiment_log
WHERE (("group" = 'control'   AND landing_page = 'old_page')
    OR ("group" = 'treatment' AND landing_page = 'new_page'))
GROUP BY "group"
ORDER BY "group";

-- 4. DAY-BY-DAY CONVERSION RATE BY GROUP (mismatches excluded) —
--    the input for the novelty/primacy-effect check: is the gap (if
--    any) between control and treatment stable across the run, or
--    does it fade/grow as the test matures?
SELECT
  DATE(timestamp)                                      AS exposure_date,
  "group",
  COUNT(*)                                              AS n_users,
  SUM(converted)                                        AS n_converted,
  ROUND(100.0 * SUM(converted) / COUNT(*), 3)           AS conversion_rate_pct
FROM experiment_log
WHERE (("group" = 'control'   AND landing_page = 'old_page')
    OR ("group" = 'treatment' AND landing_page = 'new_page'))
GROUP BY DATE(timestamp), "group"
ORDER BY exposure_date, "group";

-- 5. DUPLICATE user_id CHECK — same user exposed / logged more than
--    once. A user counted twice biases the per-user denominator and
--    can double-count a single conversion event.
SELECT
  COUNT(*) AS user_ids_appearing_more_than_once
FROM (
  SELECT user_id
  FROM experiment_log
  GROUP BY user_id
  HAVING COUNT(*) > 1
);
