"""
CASE 03 — Fintech Premium-Upgrade Page A/B Test
Real, unmodified production landing-page experiment log (294,478 rows).
Loads into SQLite, runs experiment_analysis.sql, cleans the data
(assignment mismatches + duplicate users), then runs the full
experimentation-analysis stack: two-proportion z-test with Wilson CIs,
a Sample Ratio Mismatch (SRM) chi-square check, and a first-half vs.
second-half novelty/primacy check.
"""
import sqlite3
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from scipy import stats
from statsmodels.stats.proportion import proportions_ztest, proportion_confint

plt.rcParams["font.family"] = "DejaVu Sans"
BLUE = "#2a78d6"; ORANGE = "#eb6834"; AQUA = "#1baf7a"; RED = "#e34948"; GOOD = "#0ca30c"
INK = "#0b0b0b"; INK2 = "#52514e"; MUTED = "#898781"; GRID = "#e1e0d9"; SURFACE = "#fcfcfb"

# =====================================================================
# LOAD
# =====================================================================
df = pd.read_csv("../data/ab_data.csv")
n_raw = len(df)

conn = sqlite3.connect(":memory:")
df.to_sql("experiment_log", conn, index=False, if_exists="replace")

with open("experiment_analysis.sql") as f:
    sql_lines = f.readlines()
# strip full-line SQL comments before splitting on ';' so semicolons
# inside prose comments don't break the split
sql_text = "\n".join(ln for ln in sql_lines if not ln.strip().startswith("--"))
queries = [q.strip() for q in sql_text.split(";") if q.strip() and "SELECT" in q.upper()]
labels = [
    "01_group_x_landing_page_crosstab",
    "02_mismatch_count",
    "03_filtered_group_conversion",
    "04_daily_conversion_by_group",
    "05_duplicate_user_id_count",
]
sql_results = {}
for label, q in zip(labels, queries):
    res = pd.read_sql_query(q, conn)
    sql_results[label] = res.to_dict(orient="records")
    print("\n===", label, "===")
    print(res.to_string(index=False))

# =====================================================================
# DATA-QUALITY DIAGNOSTICS (before any headline result)
# =====================================================================
mismatch_mask = ((df["group"] == "control") & (df["landing_page"] == "new_page")) | \
                ((df["group"] == "treatment") & (df["landing_page"] == "old_page"))
n_mismatched = int(mismatch_mask.sum())

# Duplicate user_id check on the RAW table (matches query 5 in the .sql
# file) — then reconcile it against the mismatch problem: is a
# duplicated user_id a *separate* data-quality issue, or the same
# assignment bug showing up twice for one user (once correctly, once
# incorrectly)?
raw_dup_ids = set(df.loc[df["user_id"].duplicated(keep=False), "user_id"])
mismatch_ids = set(df.loc[mismatch_mask, "user_id"])
n_dup_users_raw = len(raw_dup_ids)
n_dup_users_explained_by_mismatch = len(raw_dup_ids & mismatch_ids)
n_dup_users_residual = len(raw_dup_ids - mismatch_ids)

filtered = df[~mismatch_mask].copy()
n_after_mismatch_filter = len(filtered)

# Duplicate user_id check, AFTER mismatch removal — the residual
# problem left once the assignment-tracking bug is filtered out
dup_mask_before_dedup = filtered["user_id"].duplicated(keep=False)
n_dup_rows = int(dup_mask_before_dedup.sum())
n_dup_users = int(filtered.loc[dup_mask_before_dedup, "user_id"].nunique())

filtered["timestamp"] = pd.to_datetime(filtered["timestamp"])
filtered = filtered.sort_values("timestamp")
clean = filtered.drop_duplicates(subset="user_id", keep="first").copy()
n_dropped_dupe_rows = n_after_mismatch_filter - len(clean)
n_clean = len(clean)

group_counts = clean.groupby("group").size()
n_control = int(group_counts.get("control", 0))
n_treatment = int(group_counts.get("treatment", 0))

print("\n--- DATA-QUALITY SUMMARY ---")
print(f"Raw rows: {n_raw:,}")
print(f"Group/landing_page mismatched rows removed: {n_mismatched:,}")
print(f"Rows remaining after mismatch filter: {n_after_mismatch_filter:,}")
print(f"Duplicate user_id count (raw table): {n_dup_users_raw} distinct user_id")
print(f"  -> explained by the mismatch bug (same user, one correct + one incorrect row): {n_dup_users_explained_by_mismatch}")
print(f"  -> residual duplicates unrelated to mismatch: {n_dup_users_residual}")
print(f"Duplicate user_id rows found (post-mismatch-filter): {n_dup_rows} ({n_dup_users} distinct user_id)")
print(f"Duplicate rows dropped (kept first exposure by timestamp): {n_dropped_dupe_rows}")
print(f"Final clean sample: control={n_control:,}  treatment={n_treatment:,}  total={n_clean:,}")

# =====================================================================
# CORE EXPERIMENT ANALYSIS — two-proportion z-test on CLEAN data
# =====================================================================
control = clean[clean["group"] == "control"]
treatment = clean[clean["group"] == "treatment"]
x_control, n_c = int(control["converted"].sum()), len(control)
x_treatment, n_t = int(treatment["converted"].sum()), len(treatment)
p_control = x_control / n_c
p_treatment = x_treatment / n_t

z_stat, p_z = proportions_ztest([x_treatment, x_control], [n_t, n_c])
ci_control = proportion_confint(x_control, n_c, alpha=0.05, method="wilson")
ci_treatment = proportion_confint(x_treatment, n_t, alpha=0.05, method="wilson")
abs_lift_pp = (p_treatment - p_control) * 100
rel_lift_pct = 100 * (p_treatment - p_control) / p_control
is_significant = bool(p_z < 0.05)

# =====================================================================
# SAMPLE RATIO MISMATCH (SRM) CHECK — is the clean 50/50 split actually
# consistent with the intended 50/50 randomization?
# =====================================================================
expected_each = n_clean / 2.0
srm_chi2, srm_p = stats.chisquare([n_control, n_treatment], f_exp=[expected_each, expected_each])
srm_flag = bool(srm_p < 0.01)  # standard SRM alert threshold used in practice

# =====================================================================
# NOVELTY / PRIMACY CHECK — first half vs. second half of the run
# =====================================================================
clean["exposure_date"] = clean["timestamp"].dt.date
daily = (clean.groupby(["exposure_date", "group"])
              .agg(n_users=("converted", "size"), n_converted=("converted", "sum"))
              .reset_index())
daily["conversion_rate"] = daily["n_converted"] / daily["n_users"]

all_dates = sorted(clean["exposure_date"].unique())
mid = len(all_dates) // 2
first_half_dates = set(all_dates[:mid])
second_half_dates = set(all_dates[mid:])

def half_stats(dates_set):
    sub = clean[clean["exposure_date"].isin(dates_set)]
    c = sub[sub["group"] == "control"]
    t = sub[sub["group"] == "treatment"]
    pc = c["converted"].mean()
    pt = t["converted"].mean()
    lift = 100 * (pt - pc) / pc if pc > 0 else float("nan")
    return {
        "n_control": int(len(c)), "n_treatment": int(len(t)),
        "p_control": round(float(pc), 4), "p_treatment": round(float(pt), 4),
        "rel_lift_pct": round(float(lift), 2),
    }

first_half = half_stats(first_half_dates)
second_half = half_stats(second_half_dates)

# =====================================================================
# SAVE RESULTS
# =====================================================================
results = {
    "n_raw_rows": n_raw,
    "n_mismatched_rows": n_mismatched,
    "n_after_mismatch_filter": n_after_mismatch_filter,
    "n_duplicate_users_raw": n_dup_users_raw,
    "n_duplicate_users_explained_by_mismatch": n_dup_users_explained_by_mismatch,
    "n_duplicate_users_residual": n_dup_users_residual,
    "n_duplicate_rows_found_post_filter": n_dup_rows,
    "n_duplicate_users_found_post_filter": n_dup_users,
    "n_duplicate_rows_dropped": n_dropped_dupe_rows,
    "n_clean_total": n_clean,
    "n_control": n_c,
    "n_treatment": n_t,
    "x_control": x_control,
    "x_treatment": x_treatment,
    "p_control": round(float(p_control), 4),
    "p_treatment": round(float(p_treatment), 4),
    "ci_control": [round(float(c), 4) for c in ci_control],
    "ci_treatment": [round(float(c), 4) for c in ci_treatment],
    "abs_lift_pp": round(float(abs_lift_pp), 3),
    "rel_lift_pct": round(float(rel_lift_pct), 2),
    "z_stat": round(float(z_stat), 3),
    "p_value": float(p_z),
    "is_significant_at_05": is_significant,
    "srm": {
        "observed_control": n_control, "observed_treatment": n_treatment,
        "expected_each": expected_each,
        "chi2": round(float(srm_chi2), 4), "p_value": float(srm_p),
        "srm_detected": srm_flag,
    },
    "novelty_check": {
        "first_half_dates": [str(d) for d in sorted(first_half_dates)],
        "second_half_dates": [str(d) for d in sorted(second_half_dates)],
        "first_half": first_half,
        "second_half": second_half,
    },
    "daily_trend": daily.assign(exposure_date=daily["exposure_date"].astype(str)).to_dict(orient="records"),
    "sql_results": sql_results,
}

with open("experiment_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("\n--- CORE RESULT ---")
print(f"Control:   n={n_c:,}  converted={x_control:,}  rate={p_control*100:.3f}%  95% CI [{ci_control[0]*100:.3f}%, {ci_control[1]*100:.3f}%]")
print(f"Treatment: n={n_t:,}  converted={x_treatment:,}  rate={p_treatment*100:.3f}%  95% CI [{ci_treatment[0]*100:.3f}%, {ci_treatment[1]*100:.3f}%]")
print(f"Absolute lift: {abs_lift_pp:.3f} pp   Relative lift: {rel_lift_pct:.2f}%")
print(f"z = {z_stat:.3f}   p = {p_z:.4f}   significant at 0.05: {is_significant}")
print(f"SRM check: control={n_control:,} treatment={n_treatment:,} expected={expected_each:,.0f} each  chi2={srm_chi2:.3f}  p={srm_p:.4f}  SRM detected: {srm_flag}")
print(f"Novelty check — first half lift: {first_half['rel_lift_pct']}%   second half lift: {second_half['rel_lift_pct']}%")

# =====================================================================
# CHART 1 — Conversion rate by group with 95% CI error bars
# =====================================================================
fig, ax = plt.subplots(figsize=(6.2, 4.0), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
cats = ["Control\n(old page)", "Treatment\n(new page)"]
vals = [p_control * 100, p_treatment * 100]
errs_low = [(p_control - ci_control[0]) * 100, (p_treatment - ci_treatment[0]) * 100]
errs_high = [(ci_control[1] - p_control) * 100, (ci_treatment[1] - p_treatment) * 100]
bar_colors = [MUTED, BLUE]
bars = ax.bar(cats, vals, color=bar_colors, width=0.5, zorder=3,
               yerr=[errs_low, errs_high], capsize=6, ecolor=INK2, error_kw={"linewidth": 1.3})
for b, v in zip(bars, vals):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.35, f"{v:.2f}%", ha="center", fontsize=11, color=INK, fontweight="bold")
title = f"No significant difference (p = {p_z:.2f})" if not is_significant else f"Treatment converts {rel_lift_pct:+.1f}% (p = {p_z:.3f})"
ax.set_ylabel("Premium-upgrade conversion rate", fontsize=10, color=INK2)
ax.set_title(title, fontsize=12, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_ylim(0, max(vals) * 1.35)
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0, labelsize=10.5, colors=INK2)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)
plt.tight_layout()
plt.savefig("chart_conversion_by_group.png", facecolor=SURFACE)
plt.close()

# =====================================================================
# CHART 2 — Daily conversion rate by group (novelty-effect visual)
# =====================================================================
pivot = daily.pivot(index="exposure_date", columns="group", values="conversion_rate").sort_index()
fig, ax = plt.subplots(figsize=(7.0, 4.0), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
ax.plot(pivot.index, pivot["control"] * 100, color=MUTED, linewidth=2.2, marker="o", markersize=4.5, label="Control (old page)", zorder=3)
ax.plot(pivot.index, pivot["treatment"] * 100, color=BLUE, linewidth=2.2, marker="o", markersize=4.5, label="Treatment (new page)", zorder=3)
mid_date = all_dates[mid]
ax.axvline(pd.Timestamp(mid_date), color=INK2, linewidth=1.0, linestyle="--", alpha=0.6, zorder=2)
ax.set_title("Daily conversion rate stays noisy but flat across the run", fontsize=12.5, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_ylabel("Conversion rate", fontsize=10, color=INK2)
ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0, labelsize=8.5, colors=INK2, rotation=45)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)
ax.legend(frameon=False, fontsize=9.5, loc="upper right")
plt.tight_layout()
plt.savefig("chart_daily_trend.png", facecolor=SURFACE)
plt.close()

# =====================================================================
# CHART 3 — SRM check: observed vs expected 50/50 sample sizes
# =====================================================================
fig, ax = plt.subplots(figsize=(6.2, 3.8), dpi=200)
fig.patch.set_facecolor(SURFACE); ax.set_facecolor(SURFACE)
labels_srm = ["Control", "Treatment"]
observed = [n_control, n_treatment]
expected = [expected_each, expected_each]
x = np.arange(len(labels_srm))
width = 0.32
bars_obs = ax.bar(x - width / 2, observed, width, color=BLUE, zorder=3, label="Observed")
bars_exp = ax.bar(x + width / 2, expected, width, color=MUTED, zorder=3, label="Expected (50/50)")
for b in list(bars_obs) + list(bars_exp):
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + n_clean * 0.006, f"{b.get_height():,.0f}", ha="center", fontsize=9, color=INK)
srm_title = f"Sample split matches 50/50 (SRM p = {srm_p:.2f}, no SRM)" if not srm_flag else f"Sample Ratio Mismatch detected (p = {srm_p:.4f})"
ax.set_title(srm_title, fontsize=12, color=INK, loc="left", pad=12, fontweight="bold")
ax.set_xticks(x); ax.set_xticklabels(labels_srm, fontsize=10.5, color=INK2)
ax.set_ylabel("Clean users in arm", fontsize=9.5, color=INK2)
ax.set_ylim(0, max(observed + expected) * 1.25)
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.7, zorder=0)
ax.legend(frameon=False, fontsize=9.5, loc="upper right")
plt.tight_layout()
plt.savefig("chart_srm_check.png", facecolor=SURFACE)
plt.close()

print("\nCharts saved.")
