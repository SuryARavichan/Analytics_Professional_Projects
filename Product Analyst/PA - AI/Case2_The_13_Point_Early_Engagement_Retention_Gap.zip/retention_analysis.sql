-- ============================================================================
-- CASE 02 — Streaming / Media Cohort Retention Analysis
-- Dataset: MovieLens ml-latest-small (GroupLens Research)
-- Table:   ratings(userId, movieId, rating, timestamp)   -- timestamp = Unix epoch seconds
--
-- A user's "acquisition cohort" is the calendar month of their first-ever
-- rating. "Month N" (months-since-first-rating) is the Nth calendar month
-- after that, computed as a pure year/month difference so it lines up with
-- how a subscription product would define "month since signup."
-- A user is "retained" in month N if they have at least one rating whose
-- timestamp falls in that relative month.
-- ============================================================================


-- ----------------------------------------------------------------------------
-- Query 1: per-user acquisition cohort and data "runway"
-- runway_months = how many full calendar months exist between a user's
-- first rating and the last rating in the whole dataset. This is what lets
-- us later exclude cohorts too young to honestly report a 6-month rate
-- (right-censoring: a cohort with only 2 months of calendar data hasn't
-- had the chance to show up as retained OR churned at month 6).
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
bounds AS (
    SELECT MAX(timestamp) AS max_ts FROM ratings
)
SELECT
    fr.userId,
    strftime('%Y-%m', datetime(fr.first_ts, 'unixepoch')) AS cohort_month,
    (CAST(strftime('%Y', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
       - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
    + (CAST(strftime('%m', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
       - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) AS runway_months
FROM first_rating fr, bounds b
ORDER BY cohort_month, fr.userId;


-- ----------------------------------------------------------------------------
-- Query 2: monthly cohort sizes and runway
-- One row per acquisition month: how many users first showed up that
-- month, and the runway (in months) that whole cohort shares.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
bounds AS (
    SELECT MAX(timestamp) AS max_ts FROM ratings
),
user_cohort AS (
    SELECT
        fr.userId,
        strftime('%Y-%m', datetime(fr.first_ts, 'unixepoch')) AS cohort_month,
        (CAST(strftime('%Y', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) AS runway_months
    FROM first_rating fr, bounds b
)
SELECT
    cohort_month,
    COUNT(*) AS cohort_size,
    MIN(runway_months) AS runway_months
FROM user_cohort
GROUP BY cohort_month
ORDER BY cohort_month;


-- ----------------------------------------------------------------------------
-- Query 3: the full cohort retention table (all monthly cohorts)
-- Rows = acquisition cohort month, columns = months-since-first-rating
-- (0 through 6). Grid-joins every cohort against offsets 0..6 so a month
-- with zero returning users still reports an explicit 0% rather than a
-- missing row. This is the master table the heatmap and curve charts read
-- from (after filtering, in Python, to cohorts with enough size + runway
-- to be trustworthy — see Query 5).
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
user_cohort AS (
    SELECT userId, first_ts,
           strftime('%Y-%m', datetime(first_ts, 'unixepoch')) AS cohort_month
    FROM first_rating
),
cohort_size AS (
    SELECT cohort_month, COUNT(*) AS cohort_size
    FROM user_cohort
    GROUP BY cohort_month
),
rating_offsets AS (
    SELECT DISTINCT
        r.userId,
        (CAST(strftime('%Y', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(uc.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(uc.first_ts, 'unixepoch')) AS INTEGER)) AS month_offset
    FROM ratings r
    JOIN user_cohort uc ON uc.userId = r.userId
),
offsets(n) AS (
    SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
    UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
),
grid AS (
    SELECT uc.userId, uc.cohort_month, o.n AS month_offset
    FROM user_cohort uc
    CROSS JOIN offsets o
),
activity AS (
    SELECT
        g.cohort_month,
        g.month_offset,
        SUM(CASE WHEN ro.month_offset IS NOT NULL THEN 1 ELSE 0 END) AS active_users
    FROM grid g
    LEFT JOIN rating_offsets ro
      ON ro.userId = g.userId AND ro.month_offset = g.month_offset
    GROUP BY g.cohort_month, g.month_offset
)
SELECT
    a.cohort_month,
    cs.cohort_size,
    a.month_offset,
    a.active_users,
    ROUND(100.0 * a.active_users / cs.cohort_size, 2) AS retention_pct
FROM activity a
JOIN cohort_size cs ON cs.cohort_month = a.cohort_month
ORDER BY a.cohort_month, a.month_offset;


-- ----------------------------------------------------------------------------
-- Query 4: eligibility flag per cohort
-- A cohort is "reliable" for reporting up to a 6-month retention rate only
-- if it has (a) a minimum viable sample size and (b) at least 6 months of
-- calendar runway since its first user showed up. Cohorts failing either
-- test are excluded from the curve/heatmap rather than silently plotted
-- with a misleadingly low or missing month-6 value.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
bounds AS (
    SELECT MAX(timestamp) AS max_ts FROM ratings
),
user_cohort AS (
    SELECT
        fr.userId,
        strftime('%Y-%m', datetime(fr.first_ts, 'unixepoch')) AS cohort_month,
        (CAST(strftime('%Y', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) AS runway_months
    FROM first_rating fr, bounds b
),
cohort_stats AS (
    SELECT cohort_month, COUNT(*) AS cohort_size, MIN(runway_months) AS runway_months
    FROM user_cohort
    GROUP BY cohort_month
)
SELECT
    cohort_month,
    cohort_size,
    runway_months,
    CASE WHEN cohort_size >= 8 AND runway_months >= 6 THEN 1 ELSE 0 END AS is_reliable
FROM cohort_stats
ORDER BY cohort_month;


-- ----------------------------------------------------------------------------
-- Query 5: population-level retention curve
-- Pools every "reliable" cohort (cohort_size >= 8 users AND runway_months
-- >= 6, per Query 4) into one users-weighted retention-by-month curve.
-- Pooling only reliable cohorts means month 6 is never diluted by a
-- cohort that has not yet lived 6 months.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
bounds AS (
    SELECT MAX(timestamp) AS max_ts FROM ratings
),
user_cohort AS (
    SELECT
        fr.userId, fr.first_ts,
        strftime('%Y-%m', datetime(fr.first_ts, 'unixepoch')) AS cohort_month,
        (CAST(strftime('%Y', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) AS runway_months
    FROM first_rating fr, bounds b
),
cohort_stats AS (
    SELECT cohort_month, COUNT(*) AS cohort_size, MIN(runway_months) AS runway_months
    FROM user_cohort
    GROUP BY cohort_month
),
reliable AS (
    SELECT cohort_month FROM cohort_stats WHERE cohort_size >= 8 AND runway_months >= 6
),
rating_offsets AS (
    SELECT DISTINCT
        r.userId, uc.cohort_month,
        (CAST(strftime('%Y', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(uc.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(uc.first_ts, 'unixepoch')) AS INTEGER)) AS month_offset
    FROM ratings r
    JOIN user_cohort uc ON uc.userId = r.userId
    WHERE uc.cohort_month IN (SELECT cohort_month FROM reliable)
),
offsets(n) AS (
    SELECT 0 UNION ALL SELECT 1 UNION ALL SELECT 2 UNION ALL SELECT 3
    UNION ALL SELECT 4 UNION ALL SELECT 5 UNION ALL SELECT 6
),
grid AS (
    SELECT uc.userId, o.n AS month_offset
    FROM user_cohort uc
    JOIN reliable rc ON rc.cohort_month = uc.cohort_month
    CROSS JOIN offsets o
),
activity AS (
    SELECT
        g.month_offset,
        COUNT(DISTINCT g.userId) AS cohort_users,
        SUM(CASE WHEN ro.month_offset IS NOT NULL THEN 1 ELSE 0 END) AS active_users
    FROM grid g
    LEFT JOIN rating_offsets ro
      ON ro.userId = g.userId AND ro.month_offset = g.month_offset
    GROUP BY g.month_offset
)
SELECT
    month_offset,
    cohort_users AS users_in_reliable_cohorts,
    active_users,
    ROUND(100.0 * active_users / cohort_users, 2) AS retention_pct
FROM activity
ORDER BY month_offset;


-- ----------------------------------------------------------------------------
-- Query 6: early-engagement-breadth proxy
-- MovieLens ratings alone carry no genre field, so genre diversity cannot
-- be computed directly. As a documented, honest substitute: count the
-- distinct movieId values a user rated within their first 30 days. A user
-- who samples many different titles quickly is exhibiting the same kind
-- of "breadth of early exploration" behavior genre diversity would try to
-- capture -- this is a proxy, not a genre measure.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
)
SELECT
    fr.userId,
    COUNT(DISTINCT r.movieId) AS early_breadth
FROM first_rating fr
JOIN ratings r
  ON r.userId = fr.userId
 AND r.timestamp BETWEEN fr.first_ts AND fr.first_ts + 30 * 24 * 60 * 60
GROUP BY fr.userId
ORDER BY early_breadth DESC;


-- ----------------------------------------------------------------------------
-- Query 7: breadth-segment assignment (terciles)
-- Splits users into "low" (bottom third), "mid" (middle third, excluded
-- from the segment comparison), and "high" (top third) by early_breadth
-- using SQLite's NTILE window function.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
breadth AS (
    SELECT
        fr.userId,
        COUNT(DISTINCT r.movieId) AS early_breadth
    FROM first_rating fr
    JOIN ratings r
      ON r.userId = fr.userId
     AND r.timestamp BETWEEN fr.first_ts AND fr.first_ts + 30 * 24 * 60 * 60
    GROUP BY fr.userId
),
terciled AS (
    SELECT
        userId, early_breadth,
        NTILE(3) OVER (ORDER BY early_breadth) AS tercile
    FROM breadth
)
SELECT
    userId,
    early_breadth,
    CASE WHEN tercile = 1 THEN 'low' WHEN tercile = 3 THEN 'high' ELSE 'mid' END AS breadth_segment
FROM terciled
ORDER BY early_breadth;


-- ----------------------------------------------------------------------------
-- Query 8: month-3 retention, high-breadth vs low-breadth segment
-- Compares the "high" and "low" breadth terciles from Query 7 on their
-- month-3 retention rate. Restricted to users with runway_months >= 3
-- (Query 1) so the comparison never counts a too-recent user's absence at
-- month 3 as churn when the data simply hasn't reached that month yet.
-- Feeds the two-proportion z-test in run_analysis.py.
-- ----------------------------------------------------------------------------
WITH first_rating AS (
    SELECT userId, MIN(timestamp) AS first_ts
    FROM ratings
    GROUP BY userId
),
bounds AS (
    SELECT MAX(timestamp) AS max_ts FROM ratings
),
user_cohort AS (
    SELECT
        fr.userId, fr.first_ts,
        (CAST(strftime('%Y', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(b.max_ts, 'unixepoch')) AS INTEGER)
           - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) AS runway_months
    FROM first_rating fr, bounds b
),
breadth AS (
    SELECT
        fr.userId,
        COUNT(DISTINCT r.movieId) AS early_breadth
    FROM first_rating fr
    JOIN ratings r
      ON r.userId = fr.userId
     AND r.timestamp BETWEEN fr.first_ts AND fr.first_ts + 30 * 24 * 60 * 60
    GROUP BY fr.userId
),
terciled AS (
    SELECT userId, early_breadth, NTILE(3) OVER (ORDER BY early_breadth) AS tercile
    FROM breadth
),
segment AS (
    SELECT userId, CASE WHEN tercile = 1 THEN 'low' ELSE 'high' END AS breadth_segment
    FROM terciled
    WHERE tercile IN (1, 3)
),
active_m3 AS (
    SELECT DISTINCT r.userId
    FROM ratings r
    JOIN user_cohort uc ON uc.userId = r.userId
    JOIN first_rating fr ON fr.userId = r.userId
    WHERE (CAST(strftime('%Y', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
             - CAST(strftime('%Y', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) * 12
        + (CAST(strftime('%m', datetime(r.timestamp, 'unixepoch')) AS INTEGER)
             - CAST(strftime('%m', datetime(fr.first_ts, 'unixepoch')) AS INTEGER)) = 3
)
SELECT
    s.breadth_segment,
    COUNT(*) AS n_users,
    SUM(CASE WHEN am.userId IS NOT NULL THEN 1 ELSE 0 END) AS active_month3,
    ROUND(100.0 * SUM(CASE WHEN am.userId IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 2) AS retention_pct
FROM segment s
JOIN user_cohort uc ON uc.userId = s.userId AND uc.runway_months >= 3
LEFT JOIN active_m3 am ON am.userId = s.userId
GROUP BY s.breadth_segment
ORDER BY s.breadth_segment;
