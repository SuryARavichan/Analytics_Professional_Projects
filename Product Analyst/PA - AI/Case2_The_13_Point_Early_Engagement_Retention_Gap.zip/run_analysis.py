"""
CASE 02 -- Streaming / Media Cohort Retention Analysis
Loads the real MovieLens ml-latest-small ratings log into SQLite, runs the
analysis queries in retention_analysis.sql, runs a two-proportion z-test on
the early-engagement-breadth segments, and produces the 3 chart images +
retention_results.json used by build_report.py.
"""
import sqlite3
import json
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from statsmodels.stats.proportion import proportions_ztest, proportion_confint

plt.rcParams["font.family"] = "DejaVu Sans"

# ---- palette (dataviz skill reference palette, matches rest of portfolio) ----
BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
RED = "#e34948"
GOOD = "#0ca30c"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
SURFACE = "#fcfcfb"

MIN_COHORT_SIZE = 8   # minimum users in a monthly cohort to trust its retention %
MIN_RUNWAY_MONTHS = 6  # minimum calendar months of data a cohort needs for an honest 6-month rate

# ---------------------------------------------------------------
# Load data into SQLite
# ---------------------------------------------------------------
df = pd.read_csv("../data/movielens_ratings.csv")

conn = sqlite3.connect(":memory:")
df.to_sql("ratings", conn, index=False, if_exists="replace")
conn.execute("CREATE INDEX idx_user ON ratings(userId)")
conn.execute("CREATE INDEX idx_ts ON ratings(timestamp)")

with open("retention_analysis.sql") as f:
    sql_text = f.read()

# split on ';' but keep only real query blocks (each contains a final SELECT)
queries = [q.strip() for q in sql_text.split(";") if q.strip() and "SELECT" in q.upper()]
assert len(queries) == 8, f"expected 8 queries, found {len(queries)}"

labels = [
    "01_user_cohort_and_runway",
    "02_monthly_cohort_sizes",
    "03_full_cohort_retention_table",
    "04_cohort_reliability_flags",
    "05_population_retention_curve",
    "06_early_breadth_proxy",
    "07_breadth_segment_assignment",
    "08_segment_month3_retention",
]

results_raw = {}
for label, q in zip(labels, queries):
    res = pd.read_sql_query(q, conn)
    results_raw[label] = res
    print("\n===", label, f"({len(res)} rows) ===")
    print(res.head(12).to_string(index=False))

# ---------------------------------------------------------------
# Assemble the reliable-cohort heatmap table (Query 3 filtered by Query 4)
# ---------------------------------------------------------------
reliability = results_raw["04_cohort_reliability_flags"]
reliable_cohorts = reliability.loc[reliability["is_reliable"] == 1, "cohort_month"].tolist()
print(f"\nReliable cohorts (n>={MIN_COHORT_SIZE}, runway>={MIN_RUNWAY_MONTHS}mo): {len(reliable_cohorts)}")
print(reliable_cohorts)

full_table = results_raw["03_full_cohort_retention_table"]
heatmap_df = full_table[full_table["cohort_month"].isin(reliable_cohorts)].copy()
heatmap_pivot = heatmap_df.pivot(index="cohort_month", columns="month_offset", values="retention_pct")
heatmap_pivot = heatmap_pivot.reindex(columns=range(0, 7)).sort_index()
cohort_sizes_map = reliability.set_index("cohort_month")["cohort_size"].to_dict()

# ---------------------------------------------------------------
# Population retention curve (Query 5)
# ---------------------------------------------------------------
pop_curve = results_raw["05_population_retention_curve"].set_index("month_offset")["retention_pct"]

# ---------------------------------------------------------------
# Segment test: high vs low early-breadth, month-3 retention (Query 8)
# ---------------------------------------------------------------
seg = results_raw["08_segment_month3_retention"].set_index("breadth_segment")
n_high, x_high = int(seg.loc["high", "n_users"]), int(seg.loc["high", "active_month3"])
n_low, x_low = int(seg.loc["low", "n_users"]), int(seg.loc["low", "active_month3"])
p_high, p_low = x_high / n_high, x_low / n_low

z_stat, p_value = proportions_ztest([x_high, x_low], [n_high, n_low])
ci_high = proportion_confint(x_high, n_high, alpha=0.05, method="wilson")
ci_low = proportion_confint(x_low, n_low, alpha=0.05, method="wilson")
gap_pp = (p_high - p_low) * 100
lift_x = p_high / p_low if p_low > 0 else float("nan")

print(f"\nSegment test -- month-3 retention:")
print(f"  high breadth: {x_high}/{n_high} = {p_high*100:.2f}%  (95% CI {ci_high[0]*100:.2f}-{ci_high[1]*100:.2f}%)")
print(f"  low breadth:  {x_low}/{n_low} = {p_low*100:.2f}%  (95% CI {ci_low[0]*100:.2f}-{ci_low[1]*100:.2f}%)")
print(f"  gap: {gap_pp:.2f} pp, {lift_x:.2f}x, z={z_stat:.3f}, p={p_value:.6g}")

# Full segment retention curves (0-6) for the segment chart, built the same
# way as Query 5 but restricted to each breadth segment -- computed here in
# pandas from the base tables already pulled from SQLite (equivalent logic
# to retention_analysis.sql, applied per segment for the chart).
breadth_assignment = results_raw["07_breadth_segment_assignment"]
cohort_runway = results_raw["01_user_cohort_and_runway"][["userId", "runway_months"]]
first_ts = df.groupby("userId")["timestamp"].min().rename("first_ts").reset_index()
merged = df.merge(first_ts, on="userId")
merged["month_offset"] = (
    (pd.to_datetime(merged["timestamp"], unit="s").dt.to_period("M")
     - pd.to_datetime(merged["first_ts"], unit="s").dt.to_period("M")).apply(lambda x: x.n)
)

seg_curves = {}
for seg_name in ["low", "high"]:
    seg_users = breadth_assignment.loc[breadth_assignment["breadth_segment"] == seg_name, "userId"]
    seg_users_df = pd.DataFrame({"userId": seg_users}).merge(cohort_runway, on="userId")
    curve = {}
    for off in range(0, 7):
        elig = seg_users_df[seg_users_df["runway_months"] >= off]
        active_ids = set(merged.loc[merged["month_offset"] == off, "userId"])
        n_elig = len(elig)
        n_active = elig["userId"].isin(active_ids).sum()
        curve[off] = round(100 * n_active / n_elig, 2) if n_elig > 0 else None
    seg_curves[seg_name] = curve
    print(f"  {seg_name}-breadth curve (n={len(seg_users_df)}): {curve}")

# ---------------------------------------------------------------
# CHART 1 -- Retention curve: population + representative cohorts
# ---------------------------------------------------------------
representative = [c for c in ["1996-06", "1999-10", "2015-11"] if c in heatmap_pivot.index]

fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)

months = list(range(0, 7))
ax.plot(months, [pop_curve.get(m, np.nan) for m in months], color=INK, linewidth=3.2,
        marker="o", markersize=7, zorder=5, label=f"All reliable cohorts (n={int(reliability.loc[reliability['is_reliable']==1,'cohort_size'].sum())})")

rep_colors = [BLUE, ORANGE, AQUA]
for cname, col in zip(representative, rep_colors):
    row = heatmap_pivot.loc[cname]
    ax.plot(months, [row.get(m, np.nan) for m in months], color=col, linewidth=1.8,
            marker="o", markersize=4.5, alpha=0.85, zorder=3,
            label=f"Cohort {cname} (n={cohort_sizes_map.get(cname, 0)})")

for m in months:
    v = pop_curve.get(m, np.nan)
    if not np.isnan(v):
        ax.annotate(f"{v:.0f}%", (m, v), textcoords="offset points", xytext=(0, 11),
                    ha="center", fontsize=9.5, color=INK, fontweight="bold")

ax.set_xlim(-0.3, 6.3)
ax.set_ylim(0, 108)
ax.set_xticks(months)
ax.set_xlabel("Months since first rating", fontsize=10, color=INK2)
ax.set_title("Retention drops sharply after month 0, then flattens",
              fontsize=13, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)
ax.spines[["left", "bottom"]].set_color(GRID)
ax.tick_params(axis="both", length=0, labelsize=9.5, colors=INK2)
ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
ax.legend(frameon=False, fontsize=8.8, loc="upper right", labelcolor=INK2)
plt.tight_layout()
plt.savefig("chart_retention_curve.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------
# CHART 2 -- Cohort retention heatmap
# ---------------------------------------------------------------
hm_data = heatmap_pivot.values.astype(float)
n_rows, n_cols = hm_data.shape

fig, ax = plt.subplots(figsize=(8.2, 0.55 * n_rows + 1.6), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)

masked = np.ma.masked_invalid(hm_data)
cmap = plt.get_cmap("YlGnBu").copy()
cmap.set_bad(color="#f0efe9")
im = ax.imshow(masked, cmap=cmap, vmin=0, vmax=100, aspect="auto")

ax.set_xticks(range(n_cols))
ax.set_xticklabels([f"Month {m}" for m in heatmap_pivot.columns], fontsize=9, color=INK2)
ax.set_yticks(range(n_rows))
ylabels = [f"{c}  (n={cohort_sizes_map.get(c, 0)})" for c in heatmap_pivot.index]
ax.set_yticklabels(ylabels, fontsize=9, color=INK2)
ax.tick_params(length=0)

for i in range(n_rows):
    for j in range(n_cols):
        v = hm_data[i, j]
        if np.isnan(v):
            ax.text(j, i, "n/a", ha="center", va="center", fontsize=7.8, color=MUTED)
        else:
            txt_color = "white" if v > 55 else INK
            ax.text(j, i, f"{v:.0f}%", ha="center", va="center", fontsize=8.6,
                     color=txt_color, fontweight="bold")

ax.set_title("Cohort retention heatmap -- reliable monthly cohorts",
              fontsize=13, color=INK, loc="left", pad=14, fontweight="bold")
for spine in ax.spines.values():
    spine.set_visible(False)
cbar = fig.colorbar(im, ax=ax, fraction=0.035, pad=0.02)
cbar.ax.tick_params(labelsize=8, colors=INK2, length=0)
cbar.outline.set_visible(False)
cbar.set_label("% of cohort active", fontsize=8.5, color=INK2)
plt.tight_layout()
plt.savefig("chart_cohort_heatmap.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------
# CHART 3 -- Segment retention: high vs low early-breadth
# ---------------------------------------------------------------
fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)

ax.plot(months, [seg_curves["high"][m] for m in months], color=BLUE, linewidth=3,
        marker="o", markersize=7, zorder=4, label=f"High early breadth (n={n_high})")
ax.plot(months, [seg_curves["low"][m] for m in months], color=MUTED, linewidth=3,
        marker="o", markersize=7, zorder=4, label=f"Low early breadth (n={n_low})")

ax.annotate("100% (both)", (0, 100), textcoords="offset points", xytext=(0, 12),
            ha="center", fontsize=9, color=INK, fontweight="bold")
for m in months[1:]:
    hi_xytext = (12, 10) if m == 1 else (0, 14)
    hi_ha = "left" if m == 1 else "center"
    ax.annotate(f"{seg_curves['high'][m]:.0f}%", (m, seg_curves["high"][m]),
                textcoords="offset points", xytext=hi_xytext, ha=hi_ha, fontsize=9, color=BLUE, fontweight="bold")
    ax.annotate(f"{seg_curves['low'][m]:.0f}%", (m, seg_curves["low"][m]),
                textcoords="offset points", xytext=(0, -18), ha="center", fontsize=9, color=MUTED, fontweight="bold")

ax.axvline(3, color=RED, linestyle="--", linewidth=1, alpha=0.6, zorder=2)
ax.text(3.1, 90, "month 3\n(tested)", fontsize=8, color=RED, va="top")

ax.set_xlim(-0.3, 6.3)
ax.set_ylim(-14, 112)
ax.set_xticks(months)
ax.set_xlabel("Months since first rating", fontsize=10, color=INK2)
ax.set_title(f"High-breadth users retain {lift_x:.1f}x longer than low-breadth users",
              fontsize=13, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right"]].set_visible(False)
ax.spines[["left", "bottom"]].set_color(GRID)
ax.tick_params(axis="both", length=0, labelsize=9.5, colors=INK2)
ax.yaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
ax.legend(frameon=False, fontsize=9, loc="upper right", labelcolor=INK2)
plt.tight_layout()
plt.savefig("chart_segment_retention.png", facecolor=SURFACE)
plt.close()

# ---------------------------------------------------------------
# Save results JSON
# ---------------------------------------------------------------
results = {
    "dataset": {
        "source": "MovieLens ml-latest-small (GroupLens Research)",
        "n_ratings": int(len(df)),
        "n_users": int(df["userId"].nunique()),
        "date_range": [
            str(pd.to_datetime(df["timestamp"].min(), unit="s").date()),
            str(pd.to_datetime(df["timestamp"].max(), unit="s").date()),
        ],
    },
    "cohort_eligibility_rule": {
        "min_cohort_size": MIN_COHORT_SIZE,
        "min_runway_months": MIN_RUNWAY_MONTHS,
        "total_monthly_cohorts": int(len(reliability)),
        "reliable_monthly_cohorts": int(len(reliable_cohorts)),
        "reliable_cohort_list": reliable_cohorts,
    },
    "population_retention_curve_pct": {str(k): (None if pd.isna(v) else v) for k, v in pop_curve.to_dict().items()},
    "cohort_heatmap_pct": {
        cohort: {str(m): (None if pd.isna(v) else v) for m, v in row.items()}
        for cohort, row in heatmap_pivot.iterrows()
    },
    "cohort_sizes": cohort_sizes_map,
    "breadth_proxy": {
        "definition": "distinct movieId count rated within a user's first 30 days (proxy for early engagement breadth -- no genre field exists in the ratings data)",
        "tercile_low_n": int(len(breadth_assignment[breadth_assignment['breadth_segment']=='low'])),
        "tercile_mid_n": int(len(breadth_assignment[breadth_assignment['breadth_segment']=='mid'])),
        "tercile_high_n": int(len(breadth_assignment[breadth_assignment['breadth_segment']=='high'])),
    },
    "segment_month3_test": {
        "n_high": n_high, "x_high": x_high, "p_high_pct": round(p_high * 100, 2),
        "ci_high_pct": [round(ci_high[0] * 100, 2), round(ci_high[1] * 100, 2)],
        "n_low": n_low, "x_low": x_low, "p_low_pct": round(p_low * 100, 2),
        "ci_low_pct": [round(ci_low[0] * 100, 2), round(ci_low[1] * 100, 2)],
        "gap_pp": round(gap_pp, 2),
        "lift_x": round(lift_x, 2),
        "z_stat": round(float(z_stat), 3),
        "p_value": float(p_value),
        "significant_at_05": bool(p_value < 0.05),
    },
    "segment_retention_curves_pct": seg_curves,
}

with open("retention_results.json", "w") as f:
    json.dump(results, f, indent=2)

print("\nCharts + retention_results.json saved.")
print(f"Month-1 population retention: {pop_curve.get(1):.1f}%")
print(f"Month-3 population retention: {pop_curve.get(3):.1f}%")
print(f"High vs low breadth month-3 gap: {gap_pp:.1f} pp ({lift_x:.2f}x), z={z_stat:.2f}, p={p_value:.2e}")
