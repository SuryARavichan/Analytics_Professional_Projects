-- =====================================================================
-- CASE 01 — MARKETPLACE PURCHASE-TO-DELIVERY FUNNEL ANALYSIS
-- Dataset: Olist Brazilian E-Commerce Public Dataset (99,441 real orders, 2016-2018)
-- Source : https://www.kaggle.com/datasets/olistbr/brazilian-ecommerce
-- Engine : SQLite3 (tables: orders, customers, payments, reviews)
-- =====================================================================

-- 1. Overall funnel stage counts: Purchased -> Approved -> Shipped -> Delivered,
--    plus canceled/unavailable as explicit leak categories.
SELECT
  COUNT(*)                                                              AS purchased,
  SUM(CASE WHEN order_approved_at IS NOT NULL THEN 1 ELSE 0 END)        AS approved,
  SUM(CASE WHEN order_delivered_carrier_date IS NOT NULL THEN 1 ELSE 0 END) AS shipped,
  SUM(CASE WHEN order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END) AS delivered,
  SUM(CASE WHEN order_status = 'canceled' THEN 1 ELSE 0 END)            AS canceled,
  SUM(CASE WHEN order_status = 'unavailable' THEN 1 ELSE 0 END)         AS unavailable
FROM orders;

-- 2. Funnel breakdown by customer_state (top 10 states by order volume):
--    delivered-rate per state.
SELECT
  c.customer_state                                                      AS state,
  COUNT(*)                                                              AS total_orders,
  SUM(CASE WHEN o.order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END) AS delivered_orders,
  ROUND(100.0 * SUM(CASE WHEN o.order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 2) AS delivered_rate_pct
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
GROUP BY c.customer_state
ORDER BY total_orders DESC
LIMIT 10;

-- 3. Funnel breakdown by payment_type (each order's first/primary payment row):
--    delivered-rate per payment type.
WITH main_payment AS (
  SELECT order_id, payment_type
  FROM payments
  WHERE payment_sequential = 1
)
SELECT
  mp.payment_type                                                       AS payment_type,
  COUNT(*)                                                              AS total_orders,
  SUM(CASE WHEN o.order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END) AS delivered_orders,
  ROUND(100.0 * SUM(CASE WHEN o.order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END) / COUNT(*), 2) AS delivered_rate_pct
FROM orders o
JOIN main_payment mp ON o.order_id = mp.order_id
GROUP BY mp.payment_type
ORDER BY total_orders DESC;

-- 4. Average delivery time (purchase -> delivered), in days, for delivered orders.
SELECT
  ROUND(AVG(julianday(order_delivered_customer_date) - julianday(order_purchase_timestamp)), 2) AS avg_delivery_days
FROM orders
WHERE order_delivered_customer_date IS NOT NULL;

-- 5. Delivery timing vs. customer satisfaction: average review_score for orders
--    delivered late (after order_estimated_delivery_date) vs. on-time/early.
SELECT
  CASE
    WHEN o.order_delivered_customer_date > o.order_estimated_delivery_date THEN 'late'
    ELSE 'on_time_or_early'
  END                                                                    AS delivery_timing,
  COUNT(*)                                                               AS n_orders,
  ROUND(AVG(r.review_score), 3)                                          AS avg_review_score
FROM orders o
JOIN reviews r ON o.order_id = r.order_id
WHERE o.order_delivered_customer_date IS NOT NULL
GROUP BY delivery_timing;

-- 6. Revenue at risk: total payment_value tied to orders that never reached
--    "delivered" status.
WITH order_payment_totals AS (
  SELECT order_id, SUM(payment_value) AS order_payment_value
  FROM payments
  GROUP BY order_id
)
SELECT
  COUNT(DISTINCT o.order_id)                                             AS orders_not_delivered,
  ROUND(SUM(opt.order_payment_value), 2)                                 AS revenue_at_risk
FROM orders o
JOIN order_payment_totals opt ON o.order_id = opt.order_id
WHERE o.order_delivered_customer_date IS NULL;

-- 7. Order-level extract: payment_group (voucher = the worst-performing
--    payment_type from query 3, vs. all other payment types) x delivered flag.
--    Feeds the chi-square test of independence (run in Python via scipy).
WITH main_payment AS (
  SELECT order_id, payment_type FROM payments WHERE payment_sequential = 1
)
SELECT
  o.order_id,
  CASE WHEN mp.payment_type = 'voucher' THEN 'voucher' ELSE 'other' END  AS payment_group,
  CASE WHEN o.order_delivered_customer_date IS NOT NULL THEN 1 ELSE 0 END AS delivered
FROM orders o
JOIN main_payment mp ON o.order_id = mp.order_id
WHERE mp.payment_type != 'not_defined';

-- 8. Order-level extract: days_late (delivered date minus estimated date --
--    negative means early) vs. review_score, for delivered orders with a review on file.
--    Feeds the Pearson correlation test (run in Python via scipy).
SELECT
  julianday(o.order_delivered_customer_date) - julianday(o.order_estimated_delivery_date) AS days_late,
  r.review_score                                                         AS review_score
FROM orders o
JOIN reviews r ON o.order_id = r.order_id
WHERE o.order_delivered_customer_date IS NOT NULL;
