"""
CASE 01 — Marketplace Purchase-to-Delivery Funnel Analysis
Loads the real Olist Brazilian E-Commerce dataset into SQLite, runs the
analysis queries in funnel_analysis.sql, runs the statistical tests
(chi-square, correlation), and produces 3 charts + a results JSON for
the report.
"""
import sqlite3
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import json
from scipy.stats import chi2_contingency, pearsonr

plt.rcParams["font.family"] = "DejaVu Sans"

# ---- palette (dataviz skill reference palette / portfolio convention) ----
BLUE = "#2a78d6"
ORANGE = "#eb6834"
AQUA = "#1baf7a"
RED = "#e34948"
GOOD = "#0ca30c"
INK = "#0b0b0b"
INK2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
SURFACE = "#fcfcfb"

# ---------------------------------------------------------------
# Load CSVs into an in-memory SQLite DB
# ---------------------------------------------------------------
orders = pd.read_csv("../data/olist_orders_dataset.csv")
customers = pd.read_csv("../data/olist_customers_dataset.csv")
payments = pd.read_csv("../data/olist_order_payments_dataset.csv")
reviews = pd.read_csv("../data/olist_order_reviews_dataset.csv")
# order_items isn't needed for any query below (order value comes from
# payments), loaded anyway so the DB mirrors every file the case ships with.
order_items = pd.read_csv("../data/olist_order_items_dataset.csv")

conn = sqlite3.connect(":memory:")
orders.to_sql("orders", conn, index=False, if_exists="replace")
customers.to_sql("customers", conn, index=False, if_exists="replace")
payments.to_sql("payments", conn, index=False, if_exists="replace")
reviews.to_sql("reviews", conn, index=False, if_exists="replace")
order_items.to_sql("order_items", conn, index=False, if_exists="replace")

# ---------------------------------------------------------------
# Run every query in funnel_analysis.sql (the source of truth)
# ---------------------------------------------------------------
with open("funnel_analysis.sql") as f:
    sql_text = f.read()

# split on ';' but keep queries with leading comments / CTEs (all contain SELECT)
queries = [q.strip() for q in sql_text.split(";") if q.strip() and "SELECT" in q.upper()]

labels = [
    "01_overall_funnel_stage_counts",
    "02_funnel_by_state",
    "03_funnel_by_payment_type",
    "04_avg_delivery_days",
    "05_review_score_by_delivery_timing",
    "06_revenue_at_risk",
    "07_payment_group_x_delivered",   # order-level, feeds chi-square
    "08_days_late_x_review_score",    # order-level, feeds correlation
]

results = {}
for label, q in zip(labels, queries):
    res = pd.read_sql_query(q, conn)
    results[label] = res.to_dict(orient="records")
    print("\n===", label, "===")
    if len(res) > 12:
        print(res.head(5).to_string(index=False), f"\n... ({len(res)} rows total)")
    else:
        print(res.to_string(index=False))

# ---------------------------------------------------------------
# Statistical rigor
# ---------------------------------------------------------------
# Chi-square test of independence: the worst-performing payment_type
# (voucher, identified from query 3) vs. all other payment types,
# on delivered vs. not-delivered.
df7 = pd.DataFrame(results["07_payment_group_x_delivered"])
contingency = pd.crosstab(df7["payment_group"], df7["delivered"])
chi2_stat, chi2_p, chi2_dof, chi2_expected = chi2_contingency(contingency)
print("\n=== Chi-square: payment_group (voucher vs other) x delivered ===")
print(contingency)
print(f"chi2 = {chi2_stat:.4f}, p = {chi2_p:.6e}, dof = {chi2_dof}")

# Pearson correlation: delivery delay (days late; negative = early) vs.
# review_score, among delivered orders with a review on file.
df8 = pd.DataFrame(results["08_days_late_x_review_score"]).dropna()
pearson_r, pearson_p = pearsonr(df8["days_late"], df8["review_score"])
print(f"\nPearson r (days_late vs review_score) = {pearson_r:.4f}, p = {pearson_p:.6e}, n = {len(df8)}")

# ---------------------------------------------------------------
# Derived headline metrics
# ---------------------------------------------------------------
stage = results["01_overall_funnel_stage_counts"][0]
purchased = stage["purchased"]
approved = stage["approved"]
shipped = stage["shipped"]
delivered = stage["delivered"]
canceled = stage["canceled"]
unavailable = stage["unavailable"]
overall_delivered_rate = round(100.0 * delivered / purchased, 2)

pay3 = pd.DataFrame(results["03_funnel_by_payment_type"])
pay3_valid = pay3[pay3["payment_type"] != "not_defined"].sort_values("delivered_rate_pct")
worst_payment = pay3_valid.iloc[0]
worst_payment_type = worst_payment["payment_type"]
worst_payment_rate = worst_payment["delivered_rate_pct"]
rest_rate = round(
    100.0 * (delivered - worst_payment["delivered_orders"]) / (purchased - worst_payment["total_orders"]), 2
)

state2 = pd.DataFrame(results["02_funnel_by_state"])

timing5 = pd.DataFrame(results["05_review_score_by_delivery_timing"])
late_row = timing5[timing5["delivery_timing"] == "late"].iloc[0]
ontime_row = timing5[timing5["delivery_timing"] == "on_time_or_early"].iloc[0]

revenue_at_risk = results["06_revenue_at_risk"][0]["revenue_at_risk"]
orders_not_delivered = results["06_revenue_at_risk"][0]["orders_not_delivered"]

avg_delivery_days = results["04_avg_delivery_days"][0]["avg_delivery_days"]

summary = {
    "purchased": int(purchased),
    "approved": int(approved),
    "shipped": int(shipped),
    "delivered": int(delivered),
    "canceled": int(canceled),
    "unavailable": int(unavailable),
    "overall_delivered_rate_pct": overall_delivered_rate,
    "worst_payment_type": worst_payment_type,
    "worst_payment_delivered_rate_pct": float(worst_payment_rate),
    "rest_payment_delivered_rate_pct": float(rest_rate),
    "avg_delivery_days": float(avg_delivery_days),
    "late_review_score": float(late_row["avg_review_score"]),
    "late_n_orders": int(late_row["n_orders"]),
    "ontime_review_score": float(ontime_row["avg_review_score"]),
    "ontime_n_orders": int(ontime_row["n_orders"]),
    "revenue_at_risk": float(revenue_at_risk),
    "orders_not_delivered": int(orders_not_delivered),
    "chi_square": {
        "test": "chi-square test of independence: payment_group (voucher vs. other) x delivered (yes/no)",
        "statistic": float(chi2_stat),
        "p_value": float(chi2_p),
        "dof": int(chi2_dof),
        "significant_at_0.05": bool(chi2_p < 0.05),
        "contingency_table": contingency.to_dict(),
    },
    "correlation": {
        "test": "Pearson correlation: delivery delay in days (days_late) vs. review_score, delivered orders only",
        "r": float(pearson_r),
        "p_value": float(pearson_p),
        "n": int(len(df8)),
        "significant_at_0.05": bool(pearson_p < 0.05),
    },
}
results["summary"] = summary

# Queries 7 and 8 are order-level extracts (~99K and ~97K rows) that exist to
# feed the statistical tests above, not to sit in the results file — swap
# them for their row counts so funnel_results.json stays a compact metrics
# file rather than a second copy of the raw data.
results["07_payment_group_x_delivered"] = {"n_rows": len(df7)}
results["08_days_late_x_review_score"] = {"n_rows": len(df8)}

with open("funnel_results.json", "w") as f:
    json.dump(results, f, indent=2)

# =================================================================
# CHART 1 — Funnel overview (waterfall-style bar chart with leak labels)
# =================================================================
stages = ["Purchased", "Approved", "Shipped", "Delivered"]
counts = [purchased, approved, shipped, delivered]
colors = [BLUE, BLUE, BLUE, AQUA]

fig, ax = plt.subplots(figsize=(8.2, 4.6), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)
bars = ax.bar(stages, counts, color=colors, width=0.55, zorder=3)

for b, v in zip(bars, counts):
    ax.text(b.get_x() + b.get_width() / 2, v + purchased * 0.015, f"{v:,}",
            ha="center", va="bottom", fontsize=11, color=INK, fontweight="bold")

# leak annotations between consecutive stages
for i in range(len(stages) - 1):
    drop = counts[i] - counts[i + 1]
    drop_pct = 100.0 * drop / counts[i]
    x_mid = (bars[i].get_x() + bars[i].get_width() + bars[i + 1].get_x()) / 2
    y_mid = max(counts[i], counts[i + 1]) * 0.55
    ax.annotate(
        f"-{drop:,}\n(-{drop_pct:.1f}%)",
        xy=(x_mid, y_mid), ha="center", va="center", fontsize=9.5, color=RED, fontweight="bold",
        bbox=dict(boxstyle="round,pad=0.3", facecolor="white", edgecolor=RED, linewidth=1.0),
    )

ax.set_ylim(0, purchased * 1.15)
ax.set_title("Purchase-to-delivery funnel: where orders leak out",
             fontsize=13.5, color=INK, loc="left", pad=14, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0, labelsize=11, colors=INK2)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"{int(x):,}"))
ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
plt.tight_layout()
plt.savefig("chart_funnel_overview.png", facecolor=SURFACE)
plt.close()

# =================================================================
# CHART 2 — Delivered-rate by payment type (worst segment highlighted)
# =================================================================
d3 = pay3_valid.sort_values("delivered_rate_pct", ascending=True).copy()
bar_colors = [RED if pt == worst_payment_type else MUTED for pt in d3["payment_type"]]
label_map = {"credit_card": "Credit card", "boleto": "Boleto", "voucher": "Voucher", "debit_card": "Debit card"}
d3["label"] = d3["payment_type"].map(lambda p: label_map.get(p, p))

fig, ax = plt.subplots(figsize=(8.2, 3.6), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)
bars = ax.barh(d3["label"], d3["delivered_rate_pct"], color=bar_colors, height=0.55, zorder=3)
for b, v, n in zip(bars, d3["delivered_rate_pct"], d3["total_orders"]):
    ax.text(v + 0.4, b.get_y() + b.get_height() / 2, f"{v:.1f}%  (n={n:,})",
            va="center", fontsize=10, color=INK)
ax.set_xlim(85, 100)
ax.set_title(f"Delivered-order rate by payment type — {label_map.get(worst_payment_type, worst_payment_type)} leaks the most",
             fontsize=13, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="y", length=0, labelsize=10.5, colors=INK2)
ax.tick_params(axis="x", length=0, labelsize=9, colors=MUTED)
ax.xaxis.set_major_formatter(mticker.PercentFormatter(decimals=0))
ax.grid(axis="x", color=GRID, linewidth=0.8, zorder=0)
plt.tight_layout()
plt.savefig("chart_leak_by_segment.png", facecolor=SURFACE)
plt.close()

# =================================================================
# CHART 3 — Average review score: early/on-time vs. late delivery
# =================================================================
cats = ["Delivered on-time\nor early", "Delivered late"]
vals = [ontime_row["avg_review_score"], late_row["avg_review_score"]]
ns = [ontime_row["n_orders"], late_row["n_orders"]]
fig, ax = plt.subplots(figsize=(6.6, 4.0), dpi=200)
fig.patch.set_facecolor(SURFACE)
ax.set_facecolor(SURFACE)
bars = ax.bar(cats, vals, color=[AQUA, RED], width=0.5, zorder=3)
for b, v, n in zip(bars, vals, ns):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.08, f"{v:.2f} / 5\n(n={n:,})",
            ha="center", fontsize=10.5, color=INK, fontweight="bold")
ax.set_ylim(0, 5.5)
ax.set_title("Late deliveries collapse customer satisfaction",
             fontsize=13, color=INK, loc="left", pad=12, fontweight="bold")
ax.spines[["top", "right", "left"]].set_visible(False)
ax.spines["bottom"].set_color(GRID)
ax.tick_params(axis="x", length=0, labelsize=10.5, colors=INK2)
ax.tick_params(axis="y", length=0, labelsize=9, colors=MUTED)
ax.set_ylabel("Avg. review score (1-5)", fontsize=9.5, color=MUTED)
ax.grid(axis="y", color=GRID, linewidth=0.8, zorder=0)
plt.tight_layout()
plt.savefig("chart_delay_vs_review.png", facecolor=SURFACE)
plt.close()

print("\n--- Headline metrics ---")
print(f"Overall delivered rate: {overall_delivered_rate}%")
print(f"Worst payment segment: {worst_payment_type} @ {worst_payment_rate}% (rest: {rest_rate}%)")
print(f"Chi-square: chi2={chi2_stat:.3f}, p={chi2_p:.3e}, significant={chi2_p < 0.05}")
print(f"Correlation: r={pearson_r:.3f}, p={pearson_p:.3e}, significant={pearson_p < 0.05}")
print(f"Revenue at risk: ${revenue_at_risk:,.2f} across {orders_not_delivered:,} never-delivered orders")
print("Charts saved. funnel_results.json written.")
